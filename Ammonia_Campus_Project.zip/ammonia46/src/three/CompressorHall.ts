import * as THREE from 'three';
import { SyngasCompressorK301_3D } from './SyngasCompressorK301_3D';
import { EQUIPMENT_COMP_300 } from '../diagram2d/data_comp_300';
import { EQUIPMENT_K301 } from '../diagram2d/data_k301';
import { EQUIPMENT_SYNTH_400 } from '../diagram2d/data_synth_400';
import { EQUIPMENT_UREA_500 } from '../diagram2d/data_urea_500';
import { MASTER_EQUIPMENT_DATA } from './PlantDiagramData';
import {
  CampusMats, makeLabelSprite, canvasPlane, drawWrapped, pipePath,
  trimGroundSlabs, measureVisible,
} from './CampusKit';

/**
 * قسم الضاغطات (Section 3) — طابق علوي بارتفاع 10.5م مع 3 سلالم.
 * كل ضاغطة مبنية من بيانات مخططات العرض الثنائي (PFD) والثلاثي الأبعاد:
 *   K-303 (غاز طبيعي) • K-302 (هواء عمليات) • K-301 (غاز التخليق — النموذج ثلاثي الأبعاد الكامل)
 *   K-401 (تثليج الأمونيا) • K-501 (ثاني أكسيد الكربون - اليوريا)
 */

export interface StairZone {
  id: string;
  minX: number; maxX: number; minZ: number; maxZ: number;
  startY: number; endY: number;
  /** +1: الارتفاع يزداد مع زيادة x — -1: يزداد مع نقصان x */
  dir: 1 | -1;
}

interface PartSpec { tag: string; label: string; }
interface TrainSpec {
  key: string;
  tag: string;
  titleAr: string;
  accent: string;
  driver: PartSpec;
  casings: PartSpec[];
  coolers: PartSpec[];
  seps: PartSpec[];
  extras?: { tag: string; label: string; kind: 'stack' | 'filter' | 'drum' }[];
  board: { rows: [string, string][]; desc: string; src: string };
}

const DECK_H = 10.5;
export const HALL_WIDTH = 50;
const STAIR_LEN = 14;
export const STAIR_RUN = STAIR_LEN;

const g = (d: Record<string, any>, k: string) => d[k] || {};

function buildSpecs(): TrainSpec[] {
  const c300 = EQUIPMENT_COMP_300;
  const s400 = EQUIPMENT_SYNTH_400;
  const u500 = EQUIPMENT_UREA_500;
  const k302 = g(c300, 'K-302'), k303 = g(c300, 'K-303'), k401 = g(s400, 'K-401'), k501 = g(u500, 'K-501');
  const m401 = MASTER_EQUIPMENT_DATA.find((e) => e.tag === 'K-401');
  const nm = (d: Record<string, any>, k: string, fb: string) => g(d, k).nameAr || fb;

  return [
    {
      key: 'K-303', tag: 'K-303', titleAr: 'ضاغط الغاز الطبيعي', accent: '#f59e0b',
      driver: { tag: 'K-303T', label: nm(c300, 'K-303-TURB', 'توربين بخاري K-303T') },
      casings: [{ tag: 'K-303', label: 'جسم الضاغط (طرد 40 kg/cm²G)' }],
      coolers: [{ tag: 'E-308', label: nm(c300, 'E-308', 'مبرد خط التدوير') }],
      seps: [{ tag: 'V-111', label: nm(c300, 'V-111', 'فاصل الغاز الطبيعي') }],
      board: {
        rows: [
          ['ضغط السحب', k303.pressIn || '19.0 kg/cm²A'],
          ['ضغط الطرد', k303.pressOut || '40.0 kg/cm²G'],
          ['حرارة السحب / الطرد', `${k303.tempIn || '40 °C'}  →  ${k303.tempOut || '117 °C'}`],
          ['المُحرّك', 'توربين بخاري K-303T (39 → 3.5 kg/cm²A)'],
        ],
        desc: k303.descAr || '', src: 'DWG 6112P 100-300-00',
      },
    },
    {
      key: 'K-302', tag: 'K-302', titleAr: 'ضاغط هواء العمليات', accent: '#38bdf8',
      driver: { tag: 'K-302T', label: nm(c300, 'K-302-TURB', 'توربين بخاري K-302T') },
      casings: [
        { tag: 'K-302 C1', label: nm(c300, 'K-302-C1', 'الجسم الأول — المرحلة 1 و 2') },
        { tag: 'K-302 C2', label: nm(c300, 'K-302-C2', 'الجسم الثاني — المرحلة 3 و 4') },
      ],
      coolers: [
        { tag: 'E-305', label: nm(c300, 'E-305', 'مبرد المرحلة 1') },
        { tag: 'E-306', label: nm(c300, 'E-306', 'مبرد المرحلة 2') },
        { tag: 'E-307', label: nm(c300, 'E-307', 'مبرد المرحلة 3') },
      ],
      seps: [
        { tag: 'V-308', label: nm(c300, 'V-308', 'فاصل سحب الهواء') },
        { tag: 'V-305', label: nm(c300, 'V-305', 'فاصل المرحلة 1') },
        { tag: 'V-306', label: nm(c300, 'V-306', 'فاصل المرحلة 2') },
        { tag: 'V-307', label: nm(c300, 'V-307', 'فاصل المرحلة 3') },
      ],
      extras: [
        { tag: 'H-301', label: nm(c300, 'H-301', 'مدخنة سحب الهواء وكاتم الصوت'), kind: 'stack' },
        { tag: 'F-301', label: nm(c300, 'F-301', 'مرشح سحب الهواء'), kind: 'filter' },
      ],
      board: {
        rows: [
          ['ضغط السحب', k302.pressIn || '1.00 (جوّي)'],
          ['ضغط الطرد', k302.pressOut || '34.0 kg/cm²G'],
          ['حرارة السحب / الطرد', `${k302.tempIn || '41 °C'}  →  ${k302.tempOut || '167 °C'}`],
          ['المُحرّك', 'توربين بخاري K-302T (39 → 3.5 kg/cm²A)'],
        ],
        desc: k302.descAr || '', src: 'DWG 6112P 100-300-00',
      },
    },
    {
      key: 'K-301', tag: 'K-301', titleAr: 'ضاغط غاز التخليق (3 أجسام + توربين)', accent: '#a78bfa',
      driver: { tag: 'K-301T', label: 'توربين بخاري K-301T' },
      casings: [], coolers: [], seps: [],
      board: {
        rows: [
          ['المراحل', '4 مراحل — LP / MP / HP + Recycle'],
          ['ضغط السحب', '25.0 kg/cm²G'],
          ['ضغط الطرد النهائي', '239.0 kg/cm²G (Make-up)'],
          ['المُحرّك', 'توربين بخاري K-301T + مكثف سطحي'],
        ],
        desc: g(EQUIPMENT_K301, 'K-301').descAr || '', src: 'DWG 6112P 100-301-00',
      },
    },
    {
      key: 'K-401', tag: 'K-401', titleAr: 'ضاغط التثليج (الأمونيا)', accent: '#34d399',
      driver: { tag: 'K-401T', label: nm(s400, 'K-401T', 'التوربين البخاري KT-401') },
      casings: [
        { tag: 'K-401 LP', label: 'جسم الضغط المنخفض/المتوسط' },
        { tag: 'K-401 HP', label: 'جسم الضغط العالي (طرد → E-412)' },
      ],
      coolers: [],
      seps: [
        { tag: 'V-405', label: nm(s400, 'V-405', 'فاصل السحب - المرحلة 1 (-32°م)') },
        { tag: 'V-406', label: nm(s400, 'V-406', 'فاصل السحب - المرحلة 2 (-10°م)') },
        { tag: 'V-407', label: nm(s400, 'V-407', 'فاصل السحب - المرحلة 3 (+8°م)') },
      ],
      extras: [{ tag: 'E-412', label: 'مكثف الأمونيا (القسم 4) ← خط الطرد', kind: 'drum' }],
      board: {
        rows: [
          ['ضغط السحب (3 مراحل)', k401.pressIn || '0.1 / 2.5 / 4.6 kg/cm²G'],
          ['ضغط الطرد', `${(m401?.operatingPress || '').split(' ')[0] || '18.0'} kg/cm²G (3D) — ${k401.pressOut || '17.0 kg/cm²G'} (PFD)`],
          ['حرارة الطرد', `${(m401?.operatingTemp || '').split(' ')[0] || '180°C'} (3D) — ${k401.tempOut || '105.6 °C'} (PFD)`],
          ['القدرة', k401.duty || '~4,200 kW'],
        ],
        desc: k401.descAr || '', src: 'DWG 6112P 100-400-00',
      },
    },
    {
      key: 'K-501', tag: 'K-501', titleAr: 'ضاغط غاز CO₂ (قسم اليوريا)', accent: '#fb7185',
      driver: { tag: 'K-501T', label: nm(u500, 'K-501T', 'توربين ضاغط CO₂') },
      casings: [
        { tag: 'K-501 C1', label: 'الجسم الأول — المرحلة 1 و 2' },
        { tag: 'K-501 C2', label: 'الجسم الثاني — المرحلة 3 و 4' },
      ],
      coolers: [
        { tag: 'E-511', label: nm(u500, 'E-511', 'مبرد المرحلة 1') },
        { tag: 'E-512', label: nm(u500, 'E-512', 'مبرد المرحلة 2') },
        { tag: 'E-513', label: nm(u500, 'E-513', 'مبرد المرحلة 3') },
      ],
      seps: [
        { tag: 'V-509', label: nm(u500, 'V-509', 'وعاء سحب CO₂') },
        { tag: 'V-510', label: nm(u500, 'V-510', 'فاصل المرحلة 1') },
        { tag: 'V-511', label: nm(u500, 'V-511', 'فاصل المرحلة 2') },
        { tag: 'V-512', label: nm(u500, 'V-512', 'فاصل المرحلة 3') },
        { tag: 'V-514', label: nm(u500, 'V-514', 'وعاء الطرد') },
      ],
      board: {
        rows: [
          ['المراحل', '4 مراحل ضغط + 3 مبردات بينية'],
          ['ضغط السحب', String(k501.pressIn || '—')],
          ['ضغط الطرد', String(k501.pressOut || '—')],
          ['القدرة', String(k501.duty || '11,200 kW')],
        ],
        desc: k501.descAr || '', src: 'DWG 6112P 100-500-00',
      },
    },
  ];
}

export class CompressorHall {
  public group = new THREE.Group();
  public k301?: SyngasCompressorK301_3D;
  public stairs: StairZone[] = [];
  public deckHalf = { x: HALL_WIDTH / 2, z: 100 };
  public length = 0;
  public bayCenters: { key: string; tag: string; z: number; len: number }[] = [];
  public equipmentSpots: { tag: string; ar: string; x: number; y: number; z: number }[] = [];

  private mats: CampusMats;
  private labelStore: THREE.Sprite[];
  private pipeMat: THREE.MeshStandardMaterial;
  private blueMat: THREE.MeshStandardMaterial;
  private vesselMat: THREE.MeshStandardMaterial;
  private shellMat: THREE.MeshStandardMaterial;

  /** inner = اتجاه الشارع الرئيسي بالنسبة للـ x المحلي (+1 أو -1) */
  constructor(mats: CampusMats, labelStore: THREE.Sprite[], private inner: 1 | -1) {
    this.mats = mats;
    this.labelStore = labelStore;
    this.group.name = 'Section3_Compressor_Hall';
    this.pipeMat = new THREE.MeshStandardMaterial({ color: 0x5c6773, roughness: 0.5, metalness: 0.8 });
    this.blueMat = new THREE.MeshStandardMaterial({ color: 0x1d4ed8, roughness: 0.4, metalness: 0.6 });
    this.vesselMat = new THREE.MeshStandardMaterial({ color: 0xb8c2cc, roughness: 0.35, metalness: 0.85 });
    this.shellMat = new THREE.MeshStandardMaterial({ color: 0x8895a3, roughness: 0.4, metalness: 0.8 });

    const specs = buildSpecs();
    // 1) prepare K-301 (measure to size its bay)
    let k301Len = 56;
    this.k301 = new SyngasCompressorK301_3D();
    this.k301.group.scale.setScalar(0.62);
    trimGroundSlabs(this.k301.group);
    let kb = measureVisible(this.k301.group);
    let ks = kb.getSize(new THREE.Vector3());
    if (ks.z > ks.x * 1.1) {            // align the machine axis with the other trains (along X)
      this.k301.group.rotation.y = Math.PI / 2;
      kb = measureVisible(this.k301.group);
      ks = kb.getSize(new THREE.Vector3());
    }
    if (ks.x > HALL_WIDTH - 16) {
      this.k301.group.scale.multiplyScalar((HALL_WIDTH - 16) / ks.x);
      kb = measureVisible(this.k301.group);
      ks = kb.getSize(new THREE.Vector3());
    }
    k301Len = Math.max(50, ks.z + 10);

    // 2) bay layout
    const BAY = 46;
    const lens = specs.map((s) => (s.key === 'K-301' ? k301Len : BAY));
    const total = lens.reduce((a, b) => a + b, 0);
    this.length = total;
    this.deckHalf.z = total / 2;

    this.buildStructure(total);
    let cursor = -total / 2;
    specs.forEach((spec, i) => {
      const zc = cursor + lens[i] / 2;
      this.bayCenters.push({ key: spec.key, tag: spec.tag, z: zc, len: lens[i] });
      if (spec.key === 'K-301') this.placeK301(spec, zc, kb);
      else this.buildTrain(spec, zc);
      this.buildBayBoard(spec, zc);
      this.buildBaySign(spec, zc, lens[i]);
      cursor += lens[i];
    });

    // 3 staircases: start / middle / end of hall (inner side)
    const zs = [-total / 2 + 8, 0, total / 2 - 8];
    zs.forEach((z, i) => this.buildStair(z, i + 1));
  }

  // ---------------------------------------------------------------------
  private buildStructure(total: number) {
    const W = HALL_WIDTH, H = DECK_H, m = this.mats;
    const grp = new THREE.Group();
    // columns
    const cols = [-W / 2 + 1.5, -W / 6, W / 6, W / 2 - 1.5];
    for (const cx of cols) {
      for (let cz = -total / 2 + 3; cz <= total / 2 - 3 + 0.1; cz += 11.5) {
        const pier = new THREE.Mesh(new THREE.BoxGeometry(2.6, 1.3, 2.6), m.concretePlinth);
        pier.position.set(cx, 0.65, cz);
        grp.add(pier);
        const col = new THREE.Mesh(new THREE.BoxGeometry(1.1, H - 0.4, 1.1), m.carbonSteel);
        col.position.set(cx, H / 2 + 0.3, cz);
        grp.add(col);
      }
    }
    // longitudinal girders + cross beams
    cols.forEach((cx) => {
      const gd = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.5, total), m.carbonSteel);
      gd.position.set(cx, H - 0.95, 0);
      grp.add(gd);
    });
    for (let cz = -total / 2 + 3; cz <= total / 2 - 3 + 0.1; cz += 11.5) {
      const bm = new THREE.Mesh(new THREE.BoxGeometry(W, 0.9, 0.7), m.carbonSteel);
      bm.position.set(0, H - 0.85, cz);
      grp.add(bm);
    }
    // deck
    const deck = new THREE.Mesh(new THREE.BoxGeometry(W, 0.45, total), m.gratingDeck);
    deck.position.set(0, H - 0.22, 0);
    grp.add(deck);
    // safety yellow floor walkway strip along the street side
    const walk = new THREE.Mesh(new THREE.PlaneGeometry(5.5, total - 2), new THREE.MeshStandardMaterial({ color: 0x3f4852, roughness: 0.7 }));
    walk.rotation.x = -Math.PI / 2;
    walk.position.set(this.inner * (W / 2 - 3.2), H + 0.02, 0);
    grp.add(walk);
    [-1, 1].forEach((s) => {
      const line = new THREE.Mesh(new THREE.PlaneGeometry(0.25, total - 2), new THREE.MeshBasicMaterial({ color: 0xfacc15 }));
      line.rotation.x = -Math.PI / 2;
      line.position.set(this.inner * (W / 2 - 3.2) + s * 2.7, H + 0.03, 0);
      grp.add(line);
    });
    // railings (instanced posts)
    const postGeo = new THREE.CylinderGeometry(0.07, 0.07, 1.3, 6);
    const stairZs = [-total / 2 + 8, 0, total / 2 - 8];
    const postPos: THREE.Vector3[] = [];
    for (let z = -total / 2; z <= total / 2 + 0.01; z += 3) {
      postPos.push(new THREE.Vector3(-this.inner * W / 2, H + 0.65, z));
      if (!stairZs.some((sz) => Math.abs(sz - z) < 3.4)) postPos.push(new THREE.Vector3(this.inner * W / 2, H + 0.65, z));
    }
    for (let x = -W / 2; x <= W / 2 + 0.01; x += 3) {
      postPos.push(new THREE.Vector3(x, H + 0.65, -total / 2));
      postPos.push(new THREE.Vector3(x, H + 0.65, total / 2));
    }
    const posts = new THREE.InstancedMesh(postGeo, m.safetyYellow, postPos.length);
    const dummy = new THREE.Object3D();
    postPos.forEach((p, i) => { dummy.position.copy(p); dummy.updateMatrix(); posts.setMatrixAt(i, dummy.matrix); });
    grp.add(posts);
    const railOuter = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, total), m.safetyYellow);
    railOuter.position.set(-this.inner * W / 2, H + 1.25, 0);
    grp.add(railOuter);
    [-1, 1].forEach((s) => {
      const rEnd = new THREE.Mesh(new THREE.BoxGeometry(W, 0.08, 0.08), m.safetyYellow);
      rEnd.position.set(0, H + 1.25, s * total / 2);
      grp.add(rEnd);
    });
    // inner side rail segments between stairs
    const bounds = [-total / 2, ...stairZs.flatMap((z) => [z - 3, z + 3]), total / 2];
    for (let i = 0; i < bounds.length; i += 2) {
      const a = bounds[i], b = bounds[i + 1];
      if (b - a < 0.5) continue;
      const r = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, b - a), m.safetyYellow);
      r.position.set(this.inner * W / 2, H + 1.25, (a + b) / 2);
      grp.add(r);
    }
    // below-deck cable/pipe rack and condensate trench labels
    const rack = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.25, total), m.carbonSteel);
    rack.position.set(-this.inner * (W / 2 - 4), 5.0, 0);
    grp.add(rack);
    this.group.add(grp);
  }

  private buildStair(z: number, n: number) {
    const H = DECK_H, m = this.mats;
    const s = this.inner;
    const dock = s * HALL_WIDTH / 2;
    const sg = new THREE.Group();
    sg.name = `Staircase_${n}`;
    const steps = 30;
    const stepD = STAIR_LEN / steps, stepR = H / steps;
    const slope = Math.atan2(-H, s * STAIR_LEN);
    [-1.8, 1.8].forEach((w) => {
      const L = Math.hypot(STAIR_LEN, H);
      const beam = new THREE.Mesh(new THREE.BoxGeometry(L, 0.4, 0.2), m.carbonSteel);
      beam.position.set(dock + s * STAIR_LEN / 2, H / 2, z + w);
      beam.rotation.z = slope;
      sg.add(beam);
      const rail = new THREE.Mesh(new THREE.BoxGeometry(L, 0.1, 0.1), m.safetyYellow);
      rail.position.set(dock + s * STAIR_LEN / 2, H / 2 + 1.1, z + w);
      rail.rotation.z = slope;
      sg.add(rail);
    });
    for (let i = 0; i < steps; i++) {
      const t = new THREE.Mesh(new THREE.BoxGeometry(stepD * 1.15, 0.08, 3.4), m.gratingDeck);
      t.position.set(dock + s * (STAIR_LEN - (i + 0.5) * stepD), (i + 0.5) * stepR, z);
      sg.add(t);
    }
    const land = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.3, 3.8), m.gratingDeck);
    land.position.set(dock - s * 0.2, H - 0.15, z);
    sg.add(land);
    // stair sign
    const sp = makeLabelSprite(`STAIR ${n}`, `درج رقم ${n} → طابق الضاغطات`, '#facc15', 1.6);
    sp.position.set(dock + s * (STAIR_LEN + 1.5), 3.4, z);
    sg.add(sp);
    this.labelStore.push(sp);
    this.group.add(sg);

    const x0 = dock, x1 = dock + s * STAIR_LEN;
    this.stairs.push({
      id: `stair_${n}`,
      minX: Math.min(x0, x1), maxX: Math.max(x0, x1),
      minZ: z - 2.4, maxZ: z + 2.4,
      startY: 0, endY: H,
      dir: (s > 0 ? -1 : 1) as 1 | -1,
    });
  }

  // ---------------------------------------------------------------------
  // Machine train builder
  // ---------------------------------------------------------------------
  private buildTrain(spec: TrainSpec, zc: number) {
    const m = this.mats;
    const t = new THREE.Group();
    t.name = spec.key;
    t.position.set(0, DECK_H, zc);
    const outer = -this.inner;       // نحو الجهة الخارجية
    const X = (v: number) => outer * v; // v>0 → outward side

    // skid plinth
    const plinth = new THREE.Mesh(new THREE.BoxGeometry(34, 0.9, 9), m.concretePlinth);
    plinth.position.set(X(4), 0.45, 0);
    t.add(plinth);
    // base frame
    const frame = new THREE.Mesh(new THREE.BoxGeometry(32, 0.35, 7), m.carbonSteel);
    frame.position.set(X(4), 1.05, 0);
    t.add(frame);

    // driver — steam turbine
    const tx = X(19);
    const turb = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 2.3, 6.2, 28), m.alloySteel);
    turb.rotation.z = Math.PI / 2;
    turb.position.set(tx, 3.1, 0);
    t.add(turb);
    const chest = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.7, 2.8), m.carbonSteel);
    chest.position.set(tx, 5.6, 0);
    t.add(chest);
    pipePath(t, [new THREE.Vector3(tx, 6.4, 0), new THREE.Vector3(tx, 9.0, 0), new THREE.Vector3(tx, 9.0, -11)], 0.38, this.pipeMat);
    const exh = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.6, 3.2), m.carbonSteel);
    exh.position.set(tx + X(0.0), 0.2, 0);
    t.add(exh);
    [-1, 1].forEach((s) => {
      const bearing = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 0.95, 1.4, 16), m.carbonSteel);
      bearing.rotation.z = Math.PI / 2;
      bearing.position.set(tx + s * 3.9, 3.1, 0);
      t.add(bearing);
    });
    this.addPartLabel(t, spec, spec.driver.tag, spec.driver.label, tx, 8.2, 0);

    // coupling guard
    const guardX = tx + X(-4.6);
    const guard = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.15, 1.8, 20), m.safetyYellow);
    guard.rotation.z = Math.PI / 2;
    guard.position.set(guardX, 3.1, 0);
    t.add(guard);

    // casings
    const casingX: number[] = [];
    spec.casings.forEach((c, i) => {
      const cx = X(10.5 - i * 8.6);
      casingX.push(cx);
      const body = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.2, 6.2, 28), i % 2 ? this.blueMat : m.safetyBlue);
      body.rotation.z = Math.PI / 2;
      body.position.set(cx, 3.1, 0);
      t.add(body);
      const split = new THREE.Mesh(new THREE.BoxGeometry(6.0, 0.2, 4.6), m.alloySteel);
      split.position.set(cx, 3.1, 0);
      t.add(split);
      [-1, 1].forEach((s) => {
        const hb = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 1.2, 16), m.carbonSteel);
        hb.rotation.z = Math.PI / 2;
        hb.position.set(cx + s * 3.6, 3.1, 0);
        t.add(hb);
      });
      // suction (cold) + discharge (hot) nozzles
      const suc = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.7, 2.6, 16), m.alloySteel);
      suc.position.set(cx - 1.5, 5.8, 0);
      t.add(suc);
      const dis = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 2.6, 16), m.hotDischarge);
      dis.position.set(cx + 1.5, 5.8, 0);
      t.add(dis);
      [suc, dis].forEach((n) => {
        const fl = new THREE.Mesh(new THREE.CylinderGeometry(0.98, 0.98, 0.22, 16), m.carbonSteel);
        fl.position.set(n.position.x, 7.1, 0);
        t.add(fl);
      });
      this.addPartLabel(t, spec, c.tag, c.label, cx, 9.6, i % 2 ? 4 : -4);
    });

    // lube oil console behind the train
    const lube = new THREE.Mesh(new THREE.BoxGeometry(5.5, 2.0, 2.6), m.carbonSteel);
    lube.position.set(X(4), 1.9, -6.2);
    t.add(lube);
    const lubeTank = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.9, 1.6, 16), m.safetyYellow);
    lubeTank.position.set(X(4) + 2.0, 3.8, -6.2);
    t.add(lubeTank);
    this.addPartLabel(t, spec, 'LUBE OIL', 'منظومة زيت التزييت وزيت الأختام', X(4), 5.8, -6.2, 1.5);

    // coolers (horizontal shell & tube)
    const cOffX = (i: number) => X(-4 + Math.floor(i / 2) * 11.5);
    spec.coolers.forEach((c, i) => {
      const side = i % 2 === 0 ? 1 : -1;
      const z = side * 9.2;
      const cx = cOffX(i);
      const shell = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.2, 8.0, 22), this.shellMat);
      shell.rotation.z = Math.PI / 2;
      shell.position.set(cx, 2.4, z);
      t.add(shell);
      [-1, 1].forEach((s) => {
        const head = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.3, 0.9, 22), m.safetyBlue);
        head.rotation.z = Math.PI / 2;
        head.position.set(cx + s * 4.3, 2.4, z);
        t.add(head);
        const saddle = new THREE.Mesh(new THREE.BoxGeometry(0.6, 1.2, 2.2), m.concretePlinth);
        saddle.position.set(cx + s * 2.6, 0.6, z);
        t.add(saddle);
      });
      const nz = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 1.4, 12), m.alloySteel);
      nz.position.set(cx, 3.9, z);
      t.add(nz);
      this.addPartLabel(t, spec, c.tag, c.label, cx, 5.8, z);
    });

    // separators (vertical KO drums)
    const sepSideZ = (i: number) => (i % 2 === 0 ? 1 : -1);
    spec.seps.forEach((s, i) => {
      const side = sepSideZ(i);
      const col = Math.floor(i / 2);
      const sx = X(-4 + col * 11.5);
      const sz = side * 15.0;
      const body = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.2, 6.0, 22), this.vesselMat);
      body.position.set(sx, 4.2, sz);
      t.add(body);
      [1, -1].forEach((hy) => {
        const hd = new THREE.Mesh(new THREE.SphereGeometry(1.2, 18, 10, 0, Math.PI * 2, 0, Math.PI / 2), this.vesselMat);
        hd.scale.set(1, 0.45, 1);
        hd.position.set(sx, 4.2 + hy * 3.0, sz);
        if (hy < 0) hd.rotation.x = Math.PI;
        t.add(hd);
      });
      const skirt = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.25, 1.2, 18), m.carbonSteel);
      skirt.position.set(sx, 0.6, sz);
      t.add(skirt);
      const lvl = new THREE.Mesh(new THREE.BoxGeometry(0.15, 3.2, 0.15), m.safetyYellow);
      lvl.position.set(sx, 4.2, sz + side * 1.45);
      t.add(lvl);
      this.addPartLabel(t, spec, s.tag, s.label, sx, 8.6, sz);
      // KO drum → casing suction line
      if (casingX.length) {
        const per = Math.max(1, Math.ceil(spec.seps.length / casingX.length));
        const ci = Math.min(casingX.length - 1, Math.floor(i / per));
        const sucX = casingX[ci] - 1.5;
        pipePath(t, [
          new THREE.Vector3(sx, 7.3, sz),
          new THREE.Vector3(sx, 8.3, sz),
          new THREE.Vector3(sx, 8.3, side * 3.2),
          new THREE.Vector3(sucX, 8.3, side * 3.2),
          new THREE.Vector3(sucX, 7.2, 0),
        ], 0.26, this.pipeMat);
      }
    });

    // hot discharge line from the last casing
    if (casingX.length) {
      const disX = casingX[casingX.length - 1] + 1.5;
      pipePath(t, [
        new THREE.Vector3(disX, 7.2, 0),
        new THREE.Vector3(disX, 10.8, 0),
        new THREE.Vector3(disX, 10.8, 21),
      ], 0.34, m.hotDischarge);
    }

    // extras (H-301 stack, F-301 filter, E-412 line)
    (spec.extras || []).forEach((e, i) => {
      if (e.kind === 'stack') {
        const x = X(-12), z = -18 + i * 0;
        const stack = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.8, 15, 20), this.vesselMat);
        stack.position.set(x, 7.5, z);
        t.add(stack);
        for (let k = 0; k < 6; k++) {
          const lv = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.12, 0.5), m.carbonSteel);
          lv.position.set(x, 3 + k * 1.6, z + 1.7);
          t.add(lv);
        }
        this.addPartLabel(t, spec, e.tag, e.label, x, 16.8, z, 2.0);
      } else if (e.kind === 'filter') {
        const x = X(-12), z = -12.5;
        const f = new THREE.Mesh(new THREE.BoxGeometry(4.6, 3.6, 4.0), m.carbonSteel);
        f.position.set(x, 1.8, z);
        t.add(f);
        for (let k = -1; k <= 1; k++) {
          const cell = new THREE.Mesh(new THREE.BoxGeometry(1.2, 2.6, 0.12), new THREE.MeshStandardMaterial({ color: 0x9aa7b4, roughness: 0.9 }));
          cell.position.set(x + k * 1.4, 1.9, z + 2.05);
          t.add(cell);
        }
        this.addPartLabel(t, spec, e.tag, e.label, x, 5.3, z);
      } else {
        const sp = makeLabelSprite(e.tag, e.label, spec.accent, 2.0);
        sp.position.set(X(-6), 11.2, 18);
        t.add(sp);
        this.labelStore.push(sp);
      }
    });

    this.group.add(t);
  }

  private addPartLabel(parent: THREE.Group, spec: TrainSpec, tag: string, labelAr: string, x: number, y: number, z: number, h = 1.7) {
    const sp = makeLabelSprite(tag, labelAr.length > 44 ? labelAr.slice(0, 42) + '…' : labelAr, spec.accent, h);
    sp.position.set(x, y, z);
    parent.add(sp);
    this.labelStore.push(sp);
    this.equipmentSpots.push({ tag, ar: labelAr, x, y: y + DECK_H, z: z + (parent.position.z) });
  }

  private placeK301(spec: TrainSpec, zc: number, kb: THREE.Box3) {
    if (!this.k301) return;
    const holder = new THREE.Group();
    holder.position.set(0, DECK_H, zc);
    holder.name = 'K-301';
    // center module footprint at the holder origin, base at y=0
    const c = kb.getCenter(new THREE.Vector3());
    this.k301.group.position.set(-c.x - this.inner * 4, -kb.min.y, -c.z);
    // plinth below
    const plinth = new THREE.Mesh(new THREE.BoxGeometry(HALL_WIDTH - 4, 0.5, this.bayCenters[this.bayCenters.length - 1].len - 3), this.mats.concretePlinth);
    plinth.position.set(0, 0.0, 0);
    holder.add(plinth);
    holder.add(this.k301.group);
    this.group.add(holder);
  }

  private buildBayBoard(spec: TrainSpec, zc: number) {
    const s = this.inner;
    const W = 11, H = 7.2;
    const accent = spec.accent;
    const board = canvasPlane(W, H, 1100, 720, (ctx, w, h) => {
      ctx.fillStyle = '#07121f'; ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = accent; ctx.lineWidth = 10; ctx.strokeRect(8, 8, w - 16, h - 16);
      ctx.fillStyle = accent; ctx.fillRect(8, 8, w - 16, 120);
      ctx.fillStyle = '#04101c';
      ctx.textAlign = 'center';
      ctx.font = 'bold 74px monospace';
      ctx.fillText(spec.tag, w / 2 - 280, 98);
      ctx.font = 'bold 44px "Segoe UI", Tahoma, sans-serif';
      ctx.fillText(spec.titleAr, w / 2 + 160, 92);
      ctx.direction = 'rtl';
      ctx.textAlign = 'right';
      let y = 188;
      spec.board.rows.forEach(([k, v]) => {
        ctx.fillStyle = '#94a3b8'; ctx.font = '600 32px "Segoe UI", Tahoma, sans-serif';
        ctx.fillText(k, w - 40, y);
        ctx.fillStyle = '#f8fafc'; ctx.font = 'bold 32px "Segoe UI", Tahoma, sans-serif';
        ctx.direction = 'ltr'; ctx.textAlign = 'left';
        ctx.fillText(v.length > 44 ? v.slice(0, 43) + '…' : v, 40, y);
        ctx.direction = 'rtl'; ctx.textAlign = 'right';
        y += 52;
      });
      ctx.strokeStyle = 'rgba(148,163,184,0.4)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(40, y - 24); ctx.lineTo(w - 40, y - 24); ctx.stroke();
      ctx.fillStyle = '#cbd5e1'; ctx.font = '27px "Segoe UI", Tahoma, sans-serif';
      y = drawWrapped(ctx, spec.board.desc, w - 40, y + 14, w - 90, 38, 7);
      ctx.direction = 'ltr'; ctx.textAlign = 'left';
      ctx.fillStyle = '#64748b'; ctx.font = '24px monospace';
      ctx.fillText(spec.board.src, 40, h - 30);
    });
    board.rotation.y = s > 0 ? Math.PI / 2 : -Math.PI / 2;
    board.position.set(s * (HALL_WIDTH / 2 - 6.8), DECK_H + 4.6, zc + (spec.key === 'K-301' ? 0 : 0));
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.3, 8.6, W + 0.8), this.mats.carbonSteel);
    frame.position.set(board.position.x - s * 0.18, DECK_H + 4.3, zc);
    frame.scale.set(1, 1, 1);
    this.group.add(frame);
    [-1, 1].forEach((k) => {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.35, 1.2, 0.35), this.mats.carbonSteel);
      post.position.set(board.position.x - s * 0.2, DECK_H + 0.6, zc + k * (W / 2 - 0.3));
      this.group.add(post);
    });
    this.group.add(board);
  }

  private buildBaySign(spec: TrainSpec, zc: number, len: number) {
    const sp = makeLabelSprite(spec.tag, spec.titleAr, spec.accent, 3.2);
    sp.position.set(this.inner * (HALL_WIDTH / 2 + 0.5), DECK_H + 14.5, zc);
    this.group.add(sp);
    this.labelStore.push(sp);
    void len;
  }
}

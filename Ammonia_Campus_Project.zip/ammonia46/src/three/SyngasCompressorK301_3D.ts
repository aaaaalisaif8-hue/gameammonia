import * as THREE from 'three';
import { EquipmentInfo, MASTER_EQUIPMENT_DATA } from './PlantDiagramData';
import {
  createCarbonSteelTexture,
  createIndustrialCarbonSteelPipeTexture,
  createCarbonSteelBumpTexture,
  createAluminumCladdingTexture,
  createCladdingBumpTexture,
  createThermalInsulationBandTexture
} from './TextureGenerator';

/**
 * Colossal 3D Digital Twin of Section 3: Synthesis Gas Compressor Complex (Unit 300 / K-301 Train)
 * Engineered to match the exact aesthetic, palette, expansive footprint, width, and fidelity of Section 200 & Section 400:
 * - Grand Industrial Slab & Roadways (380m x 280m) with Drainage Trenches and 70m High-Mast Floodlight Towers
 * - Elevated Concrete Tabletop Mezzanine (Deck at Y = 8.5m) with Overhead Traveling Maintenance Bridge Crane
 * - K-301T HP Extraction/Condensing Steam Turbine Driver (18.5 MW, 10,000 RPM, 105 kg/cm²G Steam -> 38 kg/cm²G Extraction)
 * - K-301 LP Casing (Stages 1 & 2 Barrel Centrifugal Compressor with End Closure Forgings & Bolting)
 * - K-301 HP Casing (Stages 3 & 4 Barrel Centrifugal Compressor + Integrated Recycle Impeller Wheel)
 * - North Equipment Yard (Z = -60m): Knock-Out Separator Drums V-301 (25 bar), V-302 (52 bar), V-303 (105 bar), V-310 (220 bar)
 * - South Equipment Yard (Z = +60m): Shell & Tube Coolers E-301, E-302, E-303, E-315
 * - West Skid: Complete Lube Oil & Dry Gas Seal Console (LO/SO Console) with Dual AC Pumps, Turbine Pump, Coolers & Filters
 * - Fast-Acting Anti-Surge Bypass Stations (FV-301, FV-302, FV-303)
 * - Grade-Level Surface Condenser Package under K-301T Exhaust
 * - Multi-Tier Overhead Heavy Structural Steel Piperacks with Pure Orthogonal Routing & Zero Clashing
 * - Thickened Industrial Piping (PIPE_SCALE = 1.75) with Stucco Aluminum Cladding, SS304 Straps, Lobster Elbows & Flange Boxes
 * - ASME Fluid Identification Bands & Glowing Neon Dynamic Particle Flow Streams
 * - High-Visibility DCS Industrial Telemetry HUD Cards with Arabic & English Engineering Nomenclature
 */
export class SyngasCompressorK301_3D {
  public group: THREE.Group;
  public interactiveMeshes: THREE.Object3D[] = [];
  public claddingMeshes: THREE.Mesh[] = [];
  public onSelectCallback?: (info: EquipmentInfo) => void;

  private rotatingShafts: THREE.Object3D[] = [];
  public isCladdingTranslucent: boolean = false;

  // Photorealistic Materials palette matching Section 200 and Section 400
  private matCarbonSteel!: THREE.MeshStandardMaterial;
  private matCarbonSteelDark!: THREE.MeshStandardMaterial;
  private matAlloySteel!: THREE.MeshStandardMaterial;
  private matPolishedChrome!: THREE.MeshStandardMaterial;
  private matCompressorBlue!: THREE.MeshStandardMaterial;
  private matTurbineCasing!: THREE.MeshStandardMaterial;
  private matConcretePad!: THREE.MeshStandardMaterial;
  private matTrenchGrate!: THREE.MeshStandardMaterial;
  private matYellowSafety!: THREE.MeshStandardMaterial;
  private matCatwalkSteel!: THREE.MeshStandardMaterial;
  private matFlange!: THREE.MeshStandardMaterial;
  private matStudBolt!: THREE.MeshStandardMaterial;
  private matValveBlue!: THREE.MeshStandardMaterial;
  private matValveGreen!: THREE.MeshStandardMaterial;
  private matValveAmber!: THREE.MeshStandardMaterial;
  private matValvePurple!: THREE.MeshStandardMaterial;
  public matAluminumCladding!: THREE.MeshStandardMaterial;
  public matCladdingStraps!: THREE.MeshStandardMaterial;
  public matFlangeInsulationBox!: THREE.MeshStandardMaterial;
  public matLobsterElbow!: THREE.MeshStandardMaterial;
  private matSteamGlow!: THREE.MeshStandardMaterial;

  constructor() {
    this.group = new THREE.Group();
    this.group.name = 'SyngasCompressorK301_3D_Twin';

    this.initMaterials();
    this.buildFoundationsAndStructures();
    // Gantry crane removed to keep piping and machinery view completely unobstructed
    this.buildCompressorMachineTrain();
    this.buildSurfaceCondenserPackage();
    this.buildInterstageSeparators();
    this.buildInterstageCoolers();
    this.buildLubeAndSealOilConsole();
    this.buildProcessPipingNetwork();
    this.buildEquipmentBadgesAndSigns();
    this.buildPipelineStageNumberBadges();
    this.buildDcsInfoScreens();
  }

  private initMaterials() {
    const csDiff = createCarbonSteelTexture();
    const pipeDiff = createIndustrialCarbonSteelPipeTexture();
    const pipeBump = createCarbonSteelBumpTexture();
    const cladTex = createAluminumCladdingTexture();
    cladTex.repeat.set(1, 2);
    const cladBump = createCladdingBumpTexture();
    cladBump.repeat.set(1, 2);

    this.matCarbonSteel = new THREE.MeshStandardMaterial({
      map: pipeDiff,
      bumpMap: pipeBump,
      bumpScale: 0.04,
      roughness: 0.32,
      metalness: 0.88,
      name: 'k301_carbon_steel'
    });

    this.matCarbonSteelDark = new THREE.MeshStandardMaterial({
      color: 0x222831,
      roughness: 0.38,
      metalness: 0.85,
      name: 'k301_cs_dark'
    });

    this.matAlloySteel = new THREE.MeshStandardMaterial({
      map: pipeDiff,
      bumpMap: pipeBump,
      bumpScale: 0.03,
      roughness: 0.26,
      metalness: 0.92,
      name: 'k301_alloy_steel'
    });

    this.matPolishedChrome = new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      roughness: 0.1,
      metalness: 0.97,
      name: 'k301_chrome_rotor'
    });

    // Authentic Industrial Machinery Blue for Heavy Centrifugal Compressors (Nuovo Pignone / GE style)
    this.matCompressorBlue = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.28,
      metalness: 0.82,
      name: 'k301_casing_blue'
    });

    this.matTurbineCasing = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.3,
      metalness: 0.9,
      name: 'k301_turbine_steel'
    });

    // Dark industrial concrete slab matching Section 2 & 4
    this.matConcretePad = new THREE.MeshStandardMaterial({
      color: 0x2b3542,
      roughness: 0.9,
      metalness: 0.1,
      name: 'k301_concrete'
    });

    this.matTrenchGrate = new THREE.MeshStandardMaterial({
      color: 0x16202c,
      roughness: 0.7,
      metalness: 0.65,
      name: 'k301_grate'
    });

    this.matYellowSafety = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.3,
      metalness: 0.4,
      name: 'k301_yellow'
    });

    this.matCatwalkSteel = new THREE.MeshStandardMaterial({
      color: 0x1b2430,
      roughness: 0.55,
      metalness: 0.8,
      name: 'k301_catwalk'
    });

    this.matFlange = new THREE.MeshStandardMaterial({
      color: 0x475569,
      roughness: 0.28,
      metalness: 0.9,
      name: 'k301_flange'
    });

    this.matStudBolt = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.2,
      metalness: 0.95,
      name: 'k301_bolt'
    });

    this.matValveBlue = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.3,
      metalness: 0.6,
      name: 'k301_valve_blue'
    });

    this.matValveGreen = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      roughness: 0.3,
      metalness: 0.6,
      name: 'k301_valve_green'
    });

    this.matValveAmber = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      roughness: 0.3,
      metalness: 0.6,
      name: 'k301_valve_amber'
    });

    this.matValvePurple = new THREE.MeshStandardMaterial({
      color: 0x8b5cf6,
      roughness: 0.3,
      metalness: 0.6,
      name: 'k301_valve_purple'
    });

    this.matAluminumCladding = new THREE.MeshStandardMaterial({
      map: cladTex,
      bumpMap: cladBump,
      bumpScale: 0.012,
      roughness: 0.45,
      metalness: 0.65,
      name: 'k301_aluminum_cladding'
    });

    this.matCladdingStraps = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.35,
      metalness: 0.75,
      name: 'k301_straps'
    });

    this.matFlangeInsulationBox = new THREE.MeshStandardMaterial({
      map: cladTex,
      bumpMap: cladBump,
      bumpScale: 0.012,
      roughness: 0.45,
      metalness: 0.65,
      name: 'k301_flange_box'
    });

    this.matLobsterElbow = new THREE.MeshStandardMaterial({
      map: cladTex,
      bumpMap: cladBump,
      bumpScale: 0.012,
      roughness: 0.45,
      metalness: 0.65,
      name: 'k301_lobster_elbow'
    });

    this.matSteamGlow = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.6,
      roughness: 0.2,
      metalness: 0.8
    });
  }

  // 1. Reinforced Concrete Foundation Yard & Elevated Table-Top Mezzanine Structure
  private buildFoundationsAndStructures() {
    // Grand Industrial Slab (380m x 280m) matching Section 2 & 4 scale
    const slabGeo = new THREE.BoxGeometry(380, 1.8, 280);
    const slab = new THREE.Mesh(slabGeo, this.matConcretePad);
    slab.position.set(0, -0.9, 0);
    slab.receiveShadow = true;
    this.group.add(slab);

    // Perimeter Asphalt Access Roads
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x131820, roughness: 0.95, metalness: 0.05 });
    const roadN = new THREE.Mesh(new THREE.BoxGeometry(410, 0.15, 24), roadMat);
    roadN.position.set(0, -0.9, -135);
    this.group.add(roadN);

    const roadS = new THREE.Mesh(new THREE.BoxGeometry(410, 0.15, 24), roadMat);
    roadS.position.set(0, -0.9, 135);
    this.group.add(roadS);

    const roadE = new THREE.Mesh(new THREE.BoxGeometry(24, 0.15, 300), roadMat);
    roadE.position.set(195, -0.9, 0);
    this.group.add(roadE);

    const roadW = new THREE.Mesh(new THREE.BoxGeometry(24, 0.15, 300), roadMat);
    roadW.position.set(-195, -0.9, 0);
    this.group.add(roadW);

    // Yellow Safety Curbs
    const curbGeoL = new THREE.BoxGeometry(1.2, 0.45, 280);
    const curbL = new THREE.Mesh(curbGeoL, this.matYellowSafety);
    curbL.position.set(-179.4, 0.22, 0);
    this.group.add(curbL);

    const curbR = new THREE.Mesh(curbGeoL, this.matYellowSafety);
    curbR.position.set(179.4, 0.22, 0);
    this.group.add(curbR);

    // Concrete Drainage Trenches with Cast Iron Grates
    [-90, -45, 0, 45, 90].forEach((zPos) => {
      const trench = new THREE.Mesh(new THREE.BoxGeometry(360, 0.12, 2.5), this.matTrenchGrate);
      trench.position.set(0, 0.06, zPos);
      this.group.add(trench);
    });

    // Elevated Table-Top Concrete Compressor Mezzanine (Length 110m, Width 32m, Deck at Y = 8.5m)
    const tableTop = new THREE.Group();
    tableTop.position.set(0, 0, 0);

    // 16 Heavy Concrete Support Piers (4.2m x 4.2m x 8.5m) with Beveled Chamfers
    for (let cx of [-45, -30, -15, 0, 15, 30, 45]) {
      for (let cz of [-12, 12]) {
        const colGeo = new THREE.BoxGeometry(4.2, 8.5, 4.2);
        const col = new THREE.Mesh(colGeo, this.matConcretePad);
        col.position.set(cx, 4.25, cz);
        col.castShadow = true;
        col.receiveShadow = true;
        tableTop.add(col);

        // Column Foundation Footing
        const foot = new THREE.Mesh(new THREE.BoxGeometry(6.0, 1.2, 6.0), this.matConcretePad);
        foot.position.set(cx, 0.6, cz);
        tableTop.add(foot);
      }
    }

    // Heavy Elevated Table-Top Concrete Deck (Thickness 2.5m at Y = 8.5m)
    // Split into North Deck & South Deck to create an open central pipe trench (Z = -4m to +4m)
    const slabDeckN = new THREE.Mesh(new THREE.BoxGeometry(116.0, 2.5, 13.0), this.matConcretePad);
    slabDeckN.position.set(0, 9.75, -10.5);
    slabDeckN.receiveShadow = true;
    tableTop.add(slabDeckN);

    const slabDeckS = new THREE.Mesh(new THREE.BoxGeometry(116.0, 2.5, 13.0), this.matConcretePad);
    slabDeckS.position.set(0, 9.75, 10.5);
    slabDeckS.receiveShadow = true;
    tableTop.add(slabDeckS);

    // Cross Support Girders at structural column positions (X = -45, -30, -15, 0, 15, 30, 45)
    for (let cx of [-45, -30, -15, 0, 15, 30, 45]) {
      const girder = new THREE.Mesh(new THREE.BoxGeometry(3.6, 2.5, 8.0), this.matConcretePad);
      girder.position.set(cx, 9.75, 0);
      tableTop.add(girder);
    }

    // Mezzanine Perimeter Safety Handrails (Yellow Industrial Safety Standard)
    const railMat = this.matYellowSafety;
    const railN = new THREE.Mesh(new THREE.BoxGeometry(116.0, 1.3, 0.15), railMat);
    railN.position.set(0, 11.65, -16.9);
    tableTop.add(railN);

    const railS = new THREE.Mesh(new THREE.BoxGeometry(116.0, 1.3, 0.15), railMat);
    railS.position.set(0, 11.65, 16.9);
    tableTop.add(railS);

    const railE = new THREE.Mesh(new THREE.BoxGeometry(0.15, 1.3, 34.0), railMat);
    railE.position.set(57.9, 11.65, 0);
    tableTop.add(railE);

    const railW = new THREE.Mesh(new THREE.BoxGeometry(0.15, 1.3, 34.0), railMat);
    railW.position.set(-57.9, 11.65, 0);
    tableTop.add(railW);

    // Twin Access Staircases (East and West ends) with Intermediate Landings
    [-59.5, 59.5].forEach((sx) => {
      const stairGroup = new THREE.Group();
      stairGroup.position.set(sx, 0, 0);
      const steps = 26;
      for (let s = 0; s < steps; s++) {
        const sy = (s / steps) * 11.0;
        const sz = (s / steps) * 20.0 - 10.0;
        const step = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.35, 1.1), this.matCatwalkSteel);
        step.position.set(0, sy, sz);
        stairGroup.add(step);
      }
      // Stair Handrail
      const sRail = new THREE.Mesh(new THREE.BoxGeometry(0.15, 1.2, 22.0), this.matYellowSafety);
      sRail.position.set(1.9, 6.0, 0);
      sRail.rotation.x = Math.atan2(11.0, 20.0);
      stairGroup.add(sRail);

      tableTop.add(stairGroup);
    });

    this.group.add(tableTop);

    // 6 High-Mast Industrial Floodlight Towers (70m Height) matching Section 2 & 4
    [
      { x: -160, z: -105 },
      { x: 0, z: -105 },
      { x: 160, z: -105 },
      { x: -160, z: 105 },
      { x: 0, z: 105 },
      { x: 160, z: 105 }
    ].forEach((mast) => {
      const mastGeo = new THREE.CylinderGeometry(0.9, 2.2, 70.0, 16);
      const mastMesh = new THREE.Mesh(mastGeo, this.matCarbonSteel);
      mastMesh.position.set(mast.x, 35.0, mast.z);
      this.group.add(mastMesh);

      const mastBase = new THREE.Mesh(new THREE.BoxGeometry(5.2, 1.8, 5.2), this.matConcretePad);
      mastBase.position.set(mast.x, 0.9, mast.z);
      this.group.add(mastBase);

      const crown = new THREE.Mesh(new THREE.CylinderGeometry(4.4, 4.4, 0.8, 16), this.matCatwalkSteel);
      crown.position.set(mast.x, 70.0, mast.z);
      this.group.add(crown);

      for (let f = 0; f < 8; f++) {
        const angle = (f / 8) * Math.PI * 2;
        const lamp = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.8, 0.8), this.matValveBlue);
        lamp.position.set(mast.x + Math.cos(angle) * 3.8, 70.5, mast.z + Math.sin(angle) * 3.8);
        this.group.add(lamp);
      }
    });
  }

  // 1B. Overhead Heavy Maintenance Traveling Bridge Crane & Structural Portal Columns
  private buildOverheadGantryCrane() {
    const craneGroup = new THREE.Group();
    craneGroup.position.set(0, 0, 0);

    // Crane Runway Beams (Elevated at Y = 28.0m on structural columns along North & South mezzanine)
    [-14.0, 14.0].forEach((cz) => {
      const runwayBeam = new THREE.Mesh(new THREE.BoxGeometry(112.0, 1.6, 1.0), this.matCatwalkSteel);
      runwayBeam.position.set(0, 27.5, cz);
      craneGroup.add(runwayBeam);

      // Support Columns for Crane Runway
      for (let cx of [-45, -22.5, 0, 22.5, 45]) {
        const cCol = new THREE.Mesh(new THREE.BoxGeometry(1.4, 16.5, 1.4), this.matCatwalkSteel);
        cCol.position.set(cx, 19.25, cz);
        craneGroup.add(cCol);
      }
    });

    // Yellow Heavy Overhead Crane Bridge Girder (Positioned over machine train at X = 5.0m)
    const bridgeGirder = new THREE.Mesh(new THREE.BoxGeometry(4.5, 2.4, 30.0), this.matYellowSafety);
    bridgeGirder.position.set(5.0, 29.5, 0);
    craneGroup.add(bridgeGirder);

    // Crane Hoist Trolley & Hook (Lift Capacity: 65 Tons)
    const trolley = new THREE.Mesh(new THREE.BoxGeometry(3.5, 1.4, 3.5), this.matCatwalkSteel);
    trolley.position.set(5.0, 31.0, 2.0);
    craneGroup.add(trolley);

    // Wire Ropes & Heavy Forged Lifting Hook
    const rope = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 12.0, 8), this.matStudBolt);
    rope.position.set(5.0, 24.5, 2.0);
    craneGroup.add(rope);

    const hook = new THREE.Mesh(new THREE.TorusGeometry(0.8, 0.22, 12, 24, Math.PI * 1.5), this.matAlloySteel);
    hook.position.set(5.0, 18.0, 2.0);
    hook.rotation.z = Math.PI;
    craneGroup.add(hook);

    this.group.add(craneGroup);
  }

  // 2. K-301 Steam Turbine & Multi-Stage Centrifugal Compressor Machine Train
  private buildCompressorMachineTrain() {
    const trainGroup = new THREE.Group();
    trainGroup.position.set(0, 11.0, 0); // Sits on top of tabletop mezzanine deck (Y = 11.0m)
    trainGroup.name = 'K-301_Machine_Train';

    // Base Skid Soleplates: Longitudinal North & South Beams leaving central slot (Z = -4m to +4m) open
    const solePlateN = new THREE.Mesh(new THREE.BoxGeometry(96.0, 1.0, 4.0), this.matAlloySteel);
    solePlateN.position.set(0, 0.5, -6.0);
    trainGroup.add(solePlateN);

    const solePlateS = new THREE.Mesh(new THREE.BoxGeometry(96.0, 1.0, 4.0), this.matAlloySteel);
    solePlateS.position.set(0, 0.5, 6.0);
    trainGroup.add(solePlateS);

    // Bearing Housing & Pedestal Mounting Cross-Pads (at X = -43.5, -20.5, 0, 24.5, 44)
    for (let px of [-43.5, -20.5, 0, 24.5, 44]) {
      const pad = new THREE.Mesh(new THREE.BoxGeometry(3.6, 1.0, 8.0), this.matAlloySteel);
      pad.position.set(px, 0.5, 0);
      trainGroup.add(pad);
    }

    // Centerline High-Speed Rotor Shaft (Diameter 0.9m, Length 90.0m)
    const shaftGeo = new THREE.CylinderGeometry(0.45, 0.45, 90.0, 24);
    const shaft = new THREE.Mesh(shaftGeo, this.matPolishedChrome);
    shaft.rotation.z = Math.PI / 2;
    shaft.position.set(0, 4.5, 0);
    trainGroup.add(shaft);
    this.rotatingShafts.push(shaft);

    // ==========================================
    // A. K-301T HP Extraction/Condensing Steam Turbine Driver (X = -32.0m)
    // ==========================================
    const turbGroup = new THREE.Group();
    turbGroup.position.set(-32.0, 0, 0);
    turbGroup.name = 'K-301T_Steam_Turbine';

    // Heavy Pedestal Bearings & Journal Bearing Housings
    [-11.5, 11.5].forEach((bx) => {
      const bBlock = new THREE.Mesh(new THREE.BoxGeometry(2.8, 4.2, 5.2), this.matTurbineCasing);
      bBlock.position.set(bx, 2.5, 0);
      turbGroup.add(bBlock);
    });

    // Stepped High-Pressure Steam Turbine Casing (Length 20.0m, Outer Diameter 5.8m -> 7.4m)
    const tCasingGeo = new THREE.CylinderGeometry(3.7, 2.9, 19.0, 32);
    const tCasing = new THREE.Mesh(tCasingGeo, this.matTurbineCasing);
    tCasing.rotation.z = Math.PI / 2;
    tCasing.position.set(0, 4.5, 0);
    turbGroup.add(tCasing);

    // Horizontal Split-Line Flange Bolting
    const tFlange = new THREE.Mesh(new THREE.BoxGeometry(18.5, 0.25, 6.8), this.matTurbineCasing);
    tFlange.position.set(0, 4.5, 0);
    turbGroup.add(tFlange);

    // HP Steam Chest (105 kg/cm²G, 510°C) with 4 Hydraulic Actuator Governor Valves
    const chestGeo = new THREE.BoxGeometry(6.5, 3.6, 6.5);
    const chest = new THREE.Mesh(chestGeo, this.matTurbineCasing);
    chest.position.set(-5.5, 8.5, 0);
    turbGroup.add(chest);

    [-2.0, 2.0].forEach((vx) => {
      [-2.0, 2.0].forEach((vz) => {
        const govGeo = new THREE.CylinderGeometry(0.65, 0.65, 4.0, 16);
        const gov = new THREE.Mesh(govGeo, this.matValveAmber);
        gov.position.set(-5.5 + vx, 11.0, vz);
        turbGroup.add(gov);

        const handWheel = new THREE.Mesh(new THREE.TorusGeometry(0.75, 0.12, 8, 20), this.matYellowSafety);
        handWheel.rotation.x = Math.PI / 2;
        handWheel.position.set(-5.5 + vx, 13.2, vz);
        turbGroup.add(handWheel);
      });
    });

    // MP Steam Extraction Chest (38 kg/cm²G) at X = 2.0m
    const extChest = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.6, 3.8, 20), this.matTurbineCasing);
    extChest.position.set(2.0, 8.0, 0);
    turbGroup.add(extChest);

    // Steam Chest Inlet Flange on Top
    this.addNozzleWithFlange(turbGroup, new THREE.Vector3(-5.5, 10.3, 0), new THREE.Vector3(0, 1, 0), 1.3, 1.2);
    // MP Extraction Nozzle on Top
    this.addNozzleWithFlange(turbGroup, new THREE.Vector3(2.0, 9.9, 0), new THREE.Vector3(0, 1, 0), 1.2, 1.2);

    // Downward Steam Exhaust Neck to Surface Condenser (Diameter 4.8m)
    const exNozzle = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.4, 4.5, 24), this.matTurbineCasing);
    exNozzle.position.set(6.0, 1.5, 0);
    turbGroup.add(exNozzle);

    this.registerInteractive(turbGroup, 'k-301t');
    trainGroup.add(turbGroup);

    // Flexible High-Speed Diaphragm Coupling Guard 1 (Between Turbine and LP Casing)
    const coup1 = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.4, 2.5, 20), this.matYellowSafety);
    coup1.rotation.z = Math.PI / 2;
    coup1.position.set(-19.0, 4.5, 0);
    trainGroup.add(coup1);

    // ==========================================
    // B. K-301 LP Barrel Casing: Case 1 - Stage 1 (X = -8.5m)
    // ==========================================
    const lpGroup = new THREE.Group();
    lpGroup.position.set(-8.5, 0, 0);
    lpGroup.name = 'K-301_LP_Casing_Case1';

    // Pedestal Bearings for LP Case
    [-6.5, 6.5].forEach((bx) => {
      const bBlock = new THREE.Mesh(new THREE.BoxGeometry(2.2, 3.8, 4.8), this.matCompressorBlue);
      bBlock.position.set(bx, 2.2, 0);
      lpGroup.add(bBlock);
    });

    const lpCasingGeo = new THREE.CylinderGeometry(3.6, 3.6, 13.0, 32);
    const lpCasing = new THREE.Mesh(lpCasingGeo, this.matCompressorBlue);
    lpCasing.rotation.z = Math.PI / 2;
    lpCasing.position.set(0, 4.5, 0);
    lpGroup.add(lpCasing);

    // End Barrel Closure Heads & Heavy Shear Ring Flanges
    [-6.5, 6.5].forEach((hx) => {
      const headGeo = new THREE.CylinderGeometry(3.9, 3.9, 1.4, 32);
      const head = new THREE.Mesh(headGeo, this.matFlange);
      head.rotation.z = Math.PI / 2;
      head.position.set(hx, 4.5, 0);
      lpGroup.add(head);

      for (let b = 0; b < 24; b++) {
        const angle = (b / 24) * Math.PI * 2;
        const bolt = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 1.8, 8), this.matStudBolt);
        bolt.rotation.z = Math.PI / 2;
        bolt.position.set(hx, 4.5 + Math.sin(angle) * 3.5, Math.cos(angle) * 3.5);
        lpGroup.add(bolt);
      }
    });

    // Stage 1 Suction Nozzle (Bottom-In: Diameter 1.4m at world X = -10.5m -> local X = -2.0m)
    this.addNozzleWithFlange(lpGroup, new THREE.Vector3(-2.0, 0.9, 0), new THREE.Vector3(0, -1, 0), 1.4, 0.9);
    // Stage 1 Discharge Nozzle (Top-Out: Diameter 1.3m at world X = -6.0m -> local X = +2.5m)
    this.addNozzleWithFlange(lpGroup, new THREE.Vector3(2.5, 8.1, 0), new THREE.Vector3(0, 1, 0), 1.3, 1.2);

    this.registerInteractive(lpGroup, 'k-301_lp');
    trainGroup.add(lpGroup);

    // Flexible High-Speed Diaphragm Coupling Guard 2 (Between LP Case 1 and MP Case 2)
    const coup2 = new THREE.Mesh(new THREE.CylinderGeometry(1.35, 1.35, 2.5, 20), this.matYellowSafety);
    coup2.rotation.z = Math.PI / 2;
    coup2.position.set(1.75, 4.5, 0);
    trainGroup.add(coup2);

    // ==========================================
    // C. K-301 MP Barrel Casing: Case 2 - Stage 2 (X = +12.0m)
    // ==========================================
    const mpGroup = new THREE.Group();
    mpGroup.position.set(12.0, 0, 0);
    mpGroup.name = 'K-301_MP_Casing_Case2';

    // Pedestal Bearings for MP Case
    [-6.5, 6.5].forEach((bx) => {
      const bBlock = new THREE.Mesh(new THREE.BoxGeometry(2.2, 3.8, 4.8), this.matCompressorBlue);
      bBlock.position.set(bx, 2.2, 0);
      mpGroup.add(bBlock);
    });

    const mpCasingGeo = new THREE.CylinderGeometry(3.4, 3.4, 13.0, 32);
    const mpCasing = new THREE.Mesh(mpCasingGeo, this.matCompressorBlue);
    mpCasing.rotation.z = Math.PI / 2;
    mpCasing.position.set(0, 4.5, 0);
    mpGroup.add(mpCasing);

    // End Barrel Closure Heads & Heavy Shear Ring Flanges
    [-6.5, 6.5].forEach((hx) => {
      const headGeo = new THREE.CylinderGeometry(3.7, 3.7, 1.4, 32);
      const head = new THREE.Mesh(headGeo, this.matFlange);
      head.rotation.z = Math.PI / 2;
      head.position.set(hx, 4.5, 0);
      mpGroup.add(head);

      for (let b = 0; b < 24; b++) {
        const angle = (b / 24) * Math.PI * 2;
        const bolt = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 1.8, 8), this.matStudBolt);
        bolt.rotation.z = Math.PI / 2;
        bolt.position.set(hx, 4.5 + Math.sin(angle) * 3.3, Math.cos(angle) * 3.3);
        mpGroup.add(bolt);
      }
    });

    // Stage 2 Suction Nozzle (Bottom-In: Diameter 1.3m at world X = +9.5m -> local X = -2.5m)
    this.addNozzleWithFlange(mpGroup, new THREE.Vector3(-2.5, 1.1, 0), new THREE.Vector3(0, -1, 0), 1.3, 1.1);
    // Stage 2 Discharge Nozzle (Top-Out: Diameter 1.2m at world X = +14.5m -> local X = +2.5m)
    this.addNozzleWithFlange(mpGroup, new THREE.Vector3(2.5, 7.9, 0), new THREE.Vector3(0, 1, 0), 1.2, 1.4);

    this.registerInteractive(mpGroup, 'k-301_mp');
    trainGroup.add(mpGroup);

    // Flexible High-Speed Diaphragm Coupling Guard 3 (Between MP Case 2 and HP Case 3)
    const coup3 = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.3, 2.5, 20), this.matYellowSafety);
    coup3.rotation.z = Math.PI / 2;
    coup3.position.set(22.25, 4.5, 0);
    trainGroup.add(coup3);

    // ==========================================
    // D. K-301 HP Barrel Casing: Case 3 - Stages 3 & 4 + Recycle Impeller (X = +34.0m)
    // ==========================================
    const hpGroup = new THREE.Group();
    hpGroup.position.set(34.0, 0, 0);
    hpGroup.name = 'K-301_HP_Casing_Case3';

    // Pedestal Bearings for HP Case
    [-10.0, 10.0].forEach((bx) => {
      const bBlock = new THREE.Mesh(new THREE.BoxGeometry(2.4, 4.0, 4.8), this.matCompressorBlue);
      bBlock.position.set(bx, 2.2, 0);
      hpGroup.add(bBlock);
    });

    const hpCasingGeo = new THREE.CylinderGeometry(3.3, 3.3, 20.0, 32);
    const hpCasing = new THREE.Mesh(hpCasingGeo, this.matCompressorBlue);
    hpCasing.rotation.z = Math.PI / 2;
    hpCasing.position.set(0, 4.5, 0);
    hpGroup.add(hpCasing);

    // End Barrel Heavy Closure Forgings
    [-10.0, 10.0].forEach((hx) => {
      const head = new THREE.Mesh(new THREE.CylinderGeometry(3.6, 3.6, 1.6, 32), this.matFlange);
      head.rotation.z = Math.PI / 2;
      head.position.set(hx, 4.5, 0);
      hpGroup.add(head);

      for (let b = 0; b < 28; b++) {
        const angle = (b / 28) * Math.PI * 2;
        const bolt = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 2.0, 8), this.matStudBolt);
        bolt.rotation.z = Math.PI / 2;
        bolt.position.set(hx, 4.5 + Math.sin(angle) * 3.2, Math.cos(angle) * 3.2);
        hpGroup.add(bolt);
      }
    });

    // Stage 3 Suction Nozzle (Bottom-In: Diameter 1.2m at world X = +27.5m -> local X = -6.5m)
    this.addNozzleWithFlange(hpGroup, new THREE.Vector3(-6.5, 1.2, 0), new THREE.Vector3(0, -1, 0), 1.2, 1.2);
    // Stage 3 Discharge Nozzle (Top-Out: Diameter 1.1m at world X = +31.5m -> local X = -2.5m)
    this.addNozzleWithFlange(hpGroup, new THREE.Vector3(-2.5, 7.8, 0), new THREE.Vector3(0, 1, 0), 1.1, 1.5);
    // Stage 4 Suction Nozzle (Bottom-In: Diameter 1.1m at world X = +36.5m -> local X = +2.5m)
    this.addNozzleWithFlange(hpGroup, new THREE.Vector3(2.5, 1.2, 0), new THREE.Vector3(0, -1, 0), 1.1, 1.2);
    // Stage 4 Discharge / Recycle Discharge (Top-Out: Diameter 1.1m at world X = +40.5m -> local X = +6.5m)
    this.addNozzleWithFlange(hpGroup, new THREE.Vector3(6.5, 7.8, 0), new THREE.Vector3(0, 1, 0), 1.1, 1.5);

    this.registerInteractive(hpGroup, 'k-301');
    this.registerInteractive(hpGroup, 'k-301_hp');
    trainGroup.add(hpGroup);

    this.group.add(trainGroup);
  }

  // 2B. Grade-Level Surface Condenser Package under K-301T Exhaust
  private buildSurfaceCondenserPackage() {
    const condGroup = new THREE.Group();
    condGroup.position.set(-26.0, 0, 0);
    condGroup.name = 'K-301T_Surface_Condenser';

    // Massive Horizontal Surface Condenser Shell (Length 24m, Diameter 6.5m at Y = 4.2m under mezzanine)
    const shellGeo = new THREE.CylinderGeometry(3.25, 3.25, 24.0, 32);
    const shell = new THREE.Mesh(shellGeo, this.matCarbonSteel);
    shell.rotation.z = Math.PI / 2;
    shell.position.set(0, 4.2, 0);
    condGroup.add(shell);

    // Twin Hotwell Sump Vessels at bottom of condenser
    const hotwell = new THREE.Mesh(new THREE.BoxGeometry(8.0, 2.4, 4.5), this.matCarbonSteel);
    hotwell.position.set(0, 1.2, 0);
    condGroup.add(hotwell);

    // Condensate Extraction Pumps (P-302 A/B)
    [-3.0, 3.0].forEach((pz) => {
      const pMotor = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.9, 2.5, 16), this.matValveBlue);
      pMotor.position.set(8.0, 2.8, pz);
      condGroup.add(pMotor);

      const pPump = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.7, 1.8, 16), this.matAlloySteel);
      pPump.position.set(8.0, 0.9, pz);
      condGroup.add(pPump);
    });

    this.group.add(condGroup);
  }

  // 3. Interstage Knock-Out Separator Drums (North Yard: Z = -60m)
  private buildInterstageSeparators() {
    const sepList = [
      { id: 'v-301', tag: 'V-301', name: '1st Stage Suction KO Drum (25 bar)', x: -90, h: 26.0, d: 5.6 },
      { id: 'v-302', tag: 'V-302', name: '2nd Stage Suction KO Drum (44 bar)', x: -45, h: 28.0, d: 5.4 },
      { id: 'v-303', tag: 'V-303', name: '3rd Stage Suction KO Drum (105 bar)', x: 0, h: 30.0, d: 5.2 },
      { id: 'v-304', tag: 'V-304', name: '4th Stage Suction KO Drum (160 bar)', x: 45, h: 32.0, d: 5.0 },
      { id: 'v-310', tag: 'V-310', name: 'Make-Up Final High-Pressure Separator (220 bar)', x: 90, h: 36.0, d: 6.0 }
    ];

    sepList.forEach((sep) => {
      const vGroup = new THREE.Group();
      vGroup.position.set(sep.x, 0, -60);
      vGroup.name = sep.tag;

      // Reinforced Concrete Octagonal Foundation Base
      const foot = new THREE.Mesh(new THREE.CylinderGeometry(sep.d * 0.68, sep.d * 0.76, 2.2, 8), this.matConcretePad);
      foot.position.set(0, 1.1, 0);
      vGroup.add(foot);

      // Support Skirt with Access Manhole
      const skirt = new THREE.Mesh(new THREE.CylinderGeometry(sep.d * 0.5, sep.d * 0.52, 5.5, 24, 1, true), this.matCarbonSteel);
      skirt.position.set(0, 4.8, 0);
      vGroup.add(skirt);

      // Cylindrical Shell Body
      const shellH = sep.h - 10.5;
      const shell = new THREE.Mesh(new THREE.CylinderGeometry(sep.d * 0.5, sep.d * 0.5, shellH, 32), this.matAlloySteel);
      shell.position.set(0, 5.5 + shellH / 2, 0);
      vGroup.add(shell);

      // Hemispherical Top & Bottom Heads
      const topHead = new THREE.Mesh(new THREE.SphereGeometry(sep.d * 0.5, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), this.matAlloySteel);
      topHead.position.set(0, 5.5 + shellH, 0);
      vGroup.add(topHead);

      const botHead = new THREE.Mesh(new THREE.SphereGeometry(sep.d * 0.5, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), this.matAlloySteel);
      botHead.rotation.x = Math.PI;
      botHead.position.set(0, 5.5, 0);
      vGroup.add(botHead);

      // Circular Access Platforms & Handrails
      [0.45, 0.85].forEach((frac) => {
        const platY = 5.5 + shellH * frac;
        const plat = new THREE.Mesh(new THREE.CylinderGeometry(sep.d * 0.75, sep.d * 0.75, 0.4, 28), this.matCatwalkSteel);
        plat.position.set(0, platY, 0);
        vGroup.add(plat);

        const rail = new THREE.Mesh(new THREE.TorusGeometry(sep.d * 0.74, 0.14, 8, 28), this.matYellowSafety);
        rail.rotation.x = Math.PI / 2;
        rail.position.set(0, platY + 1.8, 0);
        vGroup.add(rail);
      });

      // Nozzles (Top Gas Outlet, South Tangential Feed Inlet, Bottom Liquid Drain)
      this.addNozzleWithFlange(vGroup, new THREE.Vector3(0, 5.5 + shellH + sep.d * 0.5, 0), new THREE.Vector3(0, 1, 0), 1.4, 3.6);
      this.addNozzleWithFlange(vGroup, new THREE.Vector3(0, 2.2, 0), new THREE.Vector3(0, -1, 0), 0.9, 2.8);
      this.addNozzleWithFlange(vGroup, new THREE.Vector3(0, 5.5 + shellH * 0.5, sep.d * 0.5), new THREE.Vector3(0, 0, 1), 1.4, 3.6); // Feed Inlet

      this.registerInteractive(vGroup, sep.id);
      this.group.add(vGroup);
    });
  }

  // 4. Interstage Shell & Tube Heat Exchangers (South Yard: Z = +60m)
  // Specific Process Rule:
  // - E-301: Gas in SHELL, Cooling Water (WC) in TUBES
  // - E-302, E-303, E-304, E-315: Gas in TUBES, Cooling Water (WC) in SHELL
  private buildInterstageCoolers() {
    const clrList = [
      {
        id: 'e-301',
        tag: 'E-301',
        name: 'Syngas Precooler (Gas in Shell / WC in Tubes - 25 bar)',
        x: -90,
        l: 16.0,
        d: 4.2,
        gasInShell: true
      },
      {
        id: 'e-302',
        tag: 'E-302',
        name: '1st Stage Intercooler (Gas in Tubes / WC in Shell - 44 bar)',
        x: -45,
        l: 16.0,
        d: 4.2,
        gasInShell: false
      },
      {
        id: 'e-303',
        tag: 'E-303',
        name: '2nd Stage Intercooler (Gas in Tubes / WC in Shell - 105 bar)',
        x: 0,
        l: 16.0,
        d: 4.2,
        gasInShell: false
      },
      {
        id: 'e-304',
        tag: 'E-304',
        name: '3rd Stage Intercooler (Gas in Tubes / WC in Shell - 160 bar)',
        x: 45,
        l: 16.0,
        d: 4.2,
        gasInShell: false
      },
      {
        id: 'e-315',
        tag: 'E-315',
        name: '4th Stage / Recycle Gas Cooler (Gas in Tubes / WC in Shell - 245 bar)',
        x: 90,
        l: 16.0,
        d: 4.4,
        gasInShell: false
      }
    ];

    clrList.forEach((clr) => {
      const eGroup = new THREE.Group();
      eGroup.position.set(clr.x, 0, 60);
      eGroup.name = clr.tag;

      // Realistic Industrial Two-Tier Saddles (Spaced at ±5.5m, leaving wide open span from X = -4.6m to +4.6m)
      [-5.5, 5.5].forEach((sx) => {
        // Concrete Foundation Plinth (Grade level up to Y = 3.2m)
        const plinth = new THREE.Mesh(new THREE.BoxGeometry(1.8, 3.2, clr.d * 1.15), this.matConcretePad);
        plinth.position.set(sx, 1.6, 0);
        eGroup.add(plinth);

        // Welded Structural Steel Saddle Cradle (Cradles the shell from Y = 3.2m to 5.1m)
        const cradle = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.9, clr.d * 1.05), this.matCarbonSteel);
        cradle.position.set(sx, 4.15, 0);
        eGroup.add(cradle);
      });

      // Shell Body (Horizontal Cylinder along X at center Y = 7.2m)
      const shellGeo = new THREE.CylinderGeometry(clr.d * 0.5, clr.d * 0.5, clr.l, 32);
      const shell = new THREE.Mesh(shellGeo, this.matCarbonSteel);
      shell.rotation.z = Math.PI / 2;
      shell.position.set(0, 7.2, 0);
      eGroup.add(shell);

      // Channel Heads (Tube Side Water Boxes with Bolted Cover Plates at X = ±8.0m)
      [-clr.l * 0.5, clr.l * 0.5].forEach((cx, idx) => {
        const headGeo = new THREE.CylinderGeometry(clr.d * 0.52, clr.d * 0.52, 2.0, 32);
        const head = new THREE.Mesh(headGeo, this.matFlange);
        head.rotation.z = Math.PI / 2;
        head.position.set(cx, 7.2, 0);
        eGroup.add(head);

        const cover = new THREE.Mesh(new THREE.CylinderGeometry(clr.d * 0.54, clr.d * 0.54, 0.4, 32), this.matAlloySteel);
        cover.rotation.z = Math.PI / 2;
        cover.position.set(cx + (idx === 0 ? -1.1 : 1.1), 7.2, 0);
        eGroup.add(cover);
      });

      if (clr.gasInShell) {
        // E-301: Process Gas in SHELL, Cooling Water (WC) in TUBES
        // Shell Process Nozzles: Gas Inlet Top, Gas Outlet Bottom (100% straight vertical)
        this.addNozzleWithFlange(eGroup, new THREE.Vector3(0, 7.2 + clr.d * 0.5, 0), new THREE.Vector3(0, 1, 0), 1.4, 1.2); // Gas In Top
        this.addNozzleWithFlange(eGroup, new THREE.Vector3(0, 7.2 - clr.d * 0.5, 0), new THREE.Vector3(0, -1, 0), 1.4, 1.2); // Gas Out Bottom

        // Channel Head Nozzles: WC In Bottom at West, WC Out Top at East
        this.addNozzleWithFlange(eGroup, new THREE.Vector3(-clr.l * 0.5, 7.2 - clr.d * 0.25, 0), new THREE.Vector3(0, -1, 0), 1.2, 1.2); // WC In Bottom
        this.addNozzleWithFlange(eGroup, new THREE.Vector3(clr.l * 0.5, 7.2 + clr.d * 0.25, 0), new THREE.Vector3(0, 1, 0), 1.2, 1.2);   // WC Out Top
      } else {
        // E-302, E-303, E-304, E-315: High Pressure Process Gas in TUBES, Cooling Water (WC) in SHELL
        // Channel Head Process Nozzles: Gas In Top at West Channel Head, Gas Out Bottom at East Channel Head
        this.addNozzleWithFlange(eGroup, new THREE.Vector3(-clr.l * 0.5, 7.2 + clr.d * 0.25, 0), new THREE.Vector3(0, 1, 0), 1.3, 1.2); // Gas In Top (West)
        this.addNozzleWithFlange(eGroup, new THREE.Vector3(clr.l * 0.5, 7.2 - clr.d * 0.25, 0), new THREE.Vector3(0, -1, 0), 1.3, 1.2);  // Gas Out Bottom (East)

        // Shell Utility Nozzles for Cooling Water:
        // WC Supply IN at Bottom in clear open span (X = +1.5m, away from saddles)
        this.addNozzleWithFlange(eGroup, new THREE.Vector3(1.5, 7.2 - clr.d * 0.5, 0), new THREE.Vector3(0, -1, 0), 1.2, 1.2); // WC Supply In Bottom
        // WCR Return OUT at Top in clear open span (X = -1.5m, away from saddles)
        this.addNozzleWithFlange(eGroup, new THREE.Vector3(-1.5, 7.2 + clr.d * 0.5, 0), new THREE.Vector3(0, 1, 0), 1.2, 1.2); // WCR Return Out Top
      }

      this.registerInteractive(eGroup, clr.id);
      this.group.add(eGroup);
    });
  }

  // 5. Lube Oil & Dry Gas Seal Console Skid (LO/SO Console)
  private buildLubeAndSealOilConsole() {
    const loGroup = new THREE.Group();
    loGroup.position.set(-115, 0, 0);
    loGroup.name = 'Lube_and_Seal_Oil_Console';

    // Oil Reservoir Tank (Length 24m, Width 12m, Height 5.5m)
    const tank = new THREE.Mesh(new THREE.BoxGeometry(24.0, 5.5, 12.0), this.matCompressorBlue);
    tank.position.set(0, 2.75, 0);
    loGroup.add(tank);

    // Dual Main & Standby AC Motor-Driven Oil Pumps (P-301 A/B)
    [-4.2, 4.2].forEach((pz) => {
      const pMotor = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.4, 4.2, 16), this.matValveBlue);
      pMotor.rotation.z = Math.PI / 2;
      pMotor.position.set(-6.5, 6.5, pz);
      loGroup.add(pMotor);

      const pPump = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.2, 3.0, 16), this.matAlloySteel);
      pPump.rotation.z = Math.PI / 2;
      pPump.position.set(-2.5, 6.5, pz);
      loGroup.add(pPump);
    });

    // Emergency Steam Turbine-Driven Lube Oil Pump (P-301C)
    const eTurb = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.3, 3.6, 16), this.matTurbineCasing);
    eTurb.rotation.z = Math.PI / 2;
    eTurb.position.set(6.5, 6.5, 0);
    loGroup.add(eTurb);

    // Dual Duplex Plate Oil Coolers (E-308 A/B)
    [-3.5, 3.5].forEach((cz) => {
      const clr = new THREE.Mesh(new THREE.BoxGeometry(3.2, 6.2, 2.4), this.matAlloySteel);
      clr.position.set(3.0, 7.0, cz);
      loGroup.add(clr);
    });

    // Duplex Micronic Oil Filter Housings (F-301 A/B)
    [-2.2, 2.2].forEach((fz) => {
      const fMesh = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 5.2, 16), this.matFlange);
      fMesh.position.set(-11.0, 7.0, fz);
      loGroup.add(fMesh);
    });

    this.registerInteractive(loGroup, 'lo_console');
    this.group.add(loGroup);
  }

  // 6. Complete Thermal Insulation Process Piping Network & Cladding Jackets
  private buildProcessPipingNetwork() {
    const PIPE_SCALE = 1.15; // Clean, realistic industrial pipe scaling preventing clashing and obstruction

    const pipeDefinitions: Array<{
      name: string;
      color: number;
      radius: number;
      speed: number;
      particleColor: number;
      streamTag: string;
      fluidLabel: string;
      points: THREE.Vector3[];
    }> = [
      // 1a. Fresh Make-Up Syngas (25 bar, 129°C) from Methanator V-104 -> E-301 Precooler SHELL INLET
      {
        name: 'Fresh Syngas (25 bar) -> E-301 SHELL INLET',
        color: 0x0284c7,
        radius: 0.58,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'FRESH SYNGAS 25 BAR -> E-301',
        fluidLabel: 'Hot Fresh Syngas (129°C, 25 bar) into E-301 Shell',
        points: [
          new THREE.Vector3(-190.0, 18.0, 60.0), // from West Battery Limit along South corridor
          new THREE.Vector3(-90.0, 18.0, 60.0),  // runs east to E-301 centerline
          new THREE.Vector3(-90.0, 10.5, 60.0)   // drops vertically into E-301 Top Shell Nozzle flange
        ]
      },
      // 1b. E-301 SHELL OUTLET (43°C) -> V-301 1st Stage Suction KO Drum
      {
        name: 'E-301 SHELL OUTLET -> V-301 1st Stage Suction',
        color: 0x0284c7,
        radius: 0.58,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'COOLED SYNGAS -> V-301',
        fluidLabel: 'Cooled Syngas (43°C, 25 bar) from E-301 Shell to V-301 KO Drum',
        points: [
          new THREE.Vector3(-90.0, 3.9, 60.0),   // from E-301 Bottom Shell Nozzle flange
          new THREE.Vector3(-90.0, 3.8, 60.0),   // elevated pipe rack at Y = 3.8m (above all concrete foundation blocks)
          new THREE.Vector3(-90.0, 3.8, -36.0),  // runs north along clear West Yard lane (45m west of mezzanine columns)
          new THREE.Vector3(-90.0, 3.8, -48.0),  // enters North Yard feed rack area clear of footing
          new THREE.Vector3(-90.0, 13.25, -48.0),// rises to V-301 feed elevation
          new THREE.Vector3(-90.0, 13.25, -57.2) // runs north into V-301 South Feed Nozzle flange
        ]
      },
      // 2. V-301 Overhead Gas -> K-301 LP 1st Stage Suction Nozzle (Elevated Clear Corridor)
      {
        name: 'V-301 Overhead -> K-301 LP 1st Stage Inlet',
        color: 0x0284c7,
        radius: 0.56,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'STAGE 1 SUCTION',
        fluidLabel: '1st Stage Syngas Suction (25 bar)',
        points: [
          new THREE.Vector3(-90.0, 28.2, -60.0), // V-301 top head outlet flange
          new THREE.Vector3(-90.0, 40.0, -60.0), // rises to High North Bridge Tier at Y = 40m
          new THREE.Vector3(-90.0, 40.0, -48.0), // turns south to High North Bridge at Z = -48m
          new THREE.Vector3(-10.5, 40.0, -48.0), // runs east to Stage 1 X-plane (bay between col -15 and col 0)
          new THREE.Vector3(-10.5, 40.0, -18.0), // turns south across High Bridge
          new THREE.Vector3(-10.5, 6.5, -18.0),  // drops vertically outside north mezzanine rail to Y = 6.5m
          new THREE.Vector3(-10.5, 6.5, 0.0),    // runs south through open bay (no columns at X = -10.5)
          new THREE.Vector3(-10.5, 11.9, 0.0)    // rises vertically into Stage 1 Bottom Suction Flange
        ]
      },
      // 3. K-301 1st Stage Discharge (44 bar, 140°C) -> E-302 Intercooler (Gas in Tubes)
      {
        name: 'K-301 1st Stage Discharge (44 bar) -> E-302 Intercooler (Gas in Tubes)',
        color: 0x0369a1,
        radius: 0.54,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'STAGE 1 DISCHARGE (44 BAR)',
        fluidLabel: 'Hot Compressed Syngas (44 bar, 140°C) to E-302 Tubes',
        points: [
          new THREE.Vector3(-6.0, 20.3, 0.0),   // top discharge nozzle of LP casing flange
          new THREE.Vector3(-6.0, 24.0, 0.0),   // rises vertically to Tier 3 elevation Y = 24m
          new THREE.Vector3(-6.0, 24.0, 28.0),  // turns south across South Bridge to Lane 1
          new THREE.Vector3(-53.0, 24.0, 28.0), // runs west along Lane 1 to E-302 West tube inlet X
          new THREE.Vector3(-53.0, 24.0, 60.0), // turns south to E-302 West Channel Head plane
          new THREE.Vector3(-53.0, 9.45, 60.0)  // drops vertically into E-302 West TUBE top nozzle flange
        ]
      },
      // 4. E-302 Cooled Gas (44 bar, 40°C) from Tubes -> V-302 Suction KO Drum
      {
        name: 'E-302 Cooled Gas (44 bar) -> V-302 2nd Stage Suction',
        color: 0x0284c7,
        radius: 0.52,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'COOLED STAGE 1 (44 BAR)',
        fluidLabel: 'Cooled Syngas (44 bar, 40°C) from E-302 Tubes to V-302',
        points: [
          new THREE.Vector3(-37.0, 4.95, 60.0),  // E-302 East tube bottom nozzle flange
          new THREE.Vector3(-37.0, 3.8, 60.0),   // elevated pipe rack at Y = 3.8m (above foundation blocks)
          new THREE.Vector3(-37.0, 3.8, -36.0),  // runs north in open bay between col -45 and col -30 (zero columns at X = -37)
          new THREE.Vector3(-45.0, 3.8, -36.0),  // turns west to V-302 X-line in open North Yard pipe alley
          new THREE.Vector3(-45.0, 3.8, -48.0),  // runs north clear of vessel footing
          new THREE.Vector3(-45.0, 14.25, -48.0),// rises to V-302 feed nozzle elevation
          new THREE.Vector3(-45.0, 14.25, -57.3) // runs north into V-302 feed inlet nozzle flange
        ]
      },
      // 5. V-302 Overhead Gas -> K-301 MP 2nd Stage Suction Nozzle (MP Casing Case 2)
      {
        name: 'V-302 Overhead (44 bar) -> K-301 MP 2nd Stage Inlet',
        color: 0x0284c7,
        radius: 0.52,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'STAGE 2 SUCTION (44 BAR)',
        fluidLabel: '2nd Stage Syngas Suction (44 bar) into MP Casing',
        points: [
          new THREE.Vector3(-45.0, 30.0, -60.0), // V-302 top head outlet flange
          new THREE.Vector3(-45.0, 36.0, -60.0), // rises to North Bridge Tier at Y = 36m
          new THREE.Vector3(-45.0, 36.0, -42.0), // turns south to Lane at Z = -42m
          new THREE.Vector3(9.5, 36.0, -42.0),   // runs east to MP Case Stage 2 X-plane (bay between col 0 and col 15)
          new THREE.Vector3(9.5, 36.0, -18.0),   // turns south across High Bridge
          new THREE.Vector3(9.5, 6.5, -18.0),    // drops vertically outside north mezzanine rail to Y = 6.5m
          new THREE.Vector3(9.5, 6.5, 0.0),      // runs south through open bay (no columns at X = 9.5)
          new THREE.Vector3(9.5, 12.1, 0.0)      // rises vertically into MP Case 2 Bottom Suction Flange
        ]
      },
      // 6. K-301 MP 2nd Stage Discharge (105 bar, 145°C) -> E-303 Intercooler (Gas in Tubes)
      {
        name: 'K-301 2nd Stage Discharge -> E-303 TUBE INLET (Gas in Tubes)',
        color: 0x0369a1,
        radius: 0.50,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'STAGE 2 DISCHARGE -> TUBES',
        fluidLabel: '2nd Stage Compressed Syngas into E-303 Tubes',
        points: [
          new THREE.Vector3(14.5, 20.3, 0.0),   // top discharge nozzle of MP casing flange
          new THREE.Vector3(14.5, 30.0, 0.0),   // rises to Upper Elevation Tier Y = 30m (+6m clearance over Stage 1!)
          new THREE.Vector3(14.5, 30.0, 38.0),  // turns south across South Bridge to Lane 2 at Z = 38m
          new THREE.Vector3(-8.0, 30.0, 38.0),  // runs west along Lane 2 to E-303 West Channel Head X-plane
          new THREE.Vector3(-8.0, 30.0, 60.0),  // turns south to E-303 West Channel Head plane at Z = 60m
          new THREE.Vector3(-8.0, 9.45, 60.0)   // drops straight vertically into E-303 West TUBE top nozzle flange
        ]
      },
      // 7. E-303 TUBE OUTLET -> V-303 3rd Stage Suction KO Drum (Trench Corridor 2)
      {
        name: 'E-303 TUBE OUTLET -> V-303 3rd Stage Suction',
        color: 0x0284c7,
        radius: 0.50,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'COOLED STAGE 2 (FROM TUBES)',
        fluidLabel: 'Cooled Syngas from E-303 Tubes to V-303',
        points: [
          new THREE.Vector3(8.0, 4.95, 60.0),    // E-303 East TUBE bottom nozzle flange
          new THREE.Vector3(8.0, 3.8, 60.0),     // elevated pipe rack at Y = 3.8m (above foundation blocks)
          new THREE.Vector3(8.0, 3.8, -36.0),    // runs north in open bay between col 0 and col 15 (zero columns at X = 8)
          new THREE.Vector3(0.0, 3.8, -36.0),    // turns west to V-303 X-line in open North Yard pipe alley
          new THREE.Vector3(0.0, 3.8, -48.0),    // runs north clear of vessel footing
          new THREE.Vector3(0.0, 15.25, -48.0),  // rises to V-303 feed nozzle elevation
          new THREE.Vector3(0.0, 15.25, -57.4)   // runs north into V-303 South feed nozzle flange
        ]
      },
      // 8. V-303 Overhead Gas -> K-301 HP 3rd Stage Suction Nozzle (HP Casing Case 3)
      {
        name: 'V-303 Overhead -> K-301 HP 3rd Stage Inlet',
        color: 0x0284c7,
        radius: 0.48,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'STAGE 3 SUCTION',
        fluidLabel: '3rd Stage Syngas Suction (105 bar) into HP Casing',
        points: [
          new THREE.Vector3(0.0, 31.8, -60.0),   // V-303 top head outlet flange
          new THREE.Vector3(0.0, 38.0, -60.0),   // vertical riser to upper rack Tier 4 at Y = 38m
          new THREE.Vector3(0.0, 38.0, -45.0),   // turns south to Lane at Z = -45m
          new THREE.Vector3(27.5, 38.0, -45.0),  // runs east to HP Case Stage 3 X-plane (bay between col 15 and col 30)
          new THREE.Vector3(27.5, 38.0, -18.0),  // turns south across overhead bridge
          new THREE.Vector3(27.5, 6.5, -18.0),   // drops vertically outside north mezzanine rail to Y = 6.5m
          new THREE.Vector3(27.5, 6.5, 0.0),     // runs south through open bay (no columns at X = 27.5)
          new THREE.Vector3(27.5, 12.2, 0.0)     // rises vertically into HP Case 3 Bottom Suction Flange
        ]
      },
      // 9. K-301 HP 3rd Stage Discharge -> E-304 Intercooler (Gas in Tubes)
      {
        name: 'K-301 3rd Stage Discharge -> E-304 TUBE INLET (Gas in Tubes)',
        color: 0x0369a1,
        radius: 0.46,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'STAGE 3 DISCHARGE -> TUBES',
        fluidLabel: '3rd Stage Compressed Syngas into E-304 Tubes',
        points: [
          new THREE.Vector3(31.5, 20.3, 0.0),  // top discharge nozzle of HP casing flange (Stage 3)
          new THREE.Vector3(31.5, 24.0, 0.0),  // rises vertically to Tier 3 elevation Y = 24m
          new THREE.Vector3(31.5, 24.0, 28.0), // turns south across overhead bridge to Lane 3 at Z = 28m
          new THREE.Vector3(37.0, 24.0, 28.0), // turns east to E-304 West inlet plane
          new THREE.Vector3(37.0, 24.0, 60.0), // turns south to E-304 West Channel Head plane at Z = 60m
          new THREE.Vector3(37.0, 9.45, 60.0)  // drops straight vertically into E-304 West TUBE top nozzle flange
        ]
      },
      // 10. E-304 TUBE OUTLET -> V-304 4th Stage Suction KO Drum (Trench Corridor 3)
      {
        name: 'E-304 TUBE OUTLET -> V-304 4th Stage Suction',
        color: 0x0284c7,
        radius: 0.46,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'COOLED STAGE 3 (FROM TUBES)',
        fluidLabel: 'Cooled Syngas from E-304 Tubes to V-304',
        points: [
          new THREE.Vector3(53.0, 4.95, 60.0),   // E-304 East TUBE bottom nozzle flange
          new THREE.Vector3(53.0, 3.8, 60.0),    // elevated pipe rack at Y = 3.8m (above foundation blocks)
          new THREE.Vector3(53.0, 3.8, -36.0),   // runs north along clear East corridor (east of all mezzanine columns)
          new THREE.Vector3(45.0, 3.8, -36.0),   // turns west to V-304 X-line in open North Yard pipe alley
          new THREE.Vector3(45.0, 3.8, -48.0),   // runs north clear of vessel footing
          new THREE.Vector3(45.0, 16.25, -48.0), // rises to V-304 feed nozzle elevation
          new THREE.Vector3(45.0, 16.25, -57.5)  // runs north into V-304 South feed nozzle flange
        ]
      },
      // 11. V-304 Overhead Gas -> K-301 HP 4th Stage Final Suction (HP Casing Case 3)
      {
        name: 'V-304 Overhead -> K-301 HP 4th Stage Final Inlet',
        color: 0x0284c7,
        radius: 0.46,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'STAGE 4 SUCTION (160 BAR)',
        fluidLabel: '4th Stage Suction Gas from V-304 into HP Casing',
        points: [
          new THREE.Vector3(45.0, 33.5, -60.0), // V-304 top head outlet flange
          new THREE.Vector3(45.0, 40.0, -60.0), // vertical riser to upper rack Tier 4
          new THREE.Vector3(45.0, 40.0, -45.0), // turns south to Lane at Z = -45m
          new THREE.Vector3(36.5, 40.0, -45.0), // turns west to HP Case Stage 4 X-plane (bay between col 30 and col 45)
          new THREE.Vector3(36.5, 40.0, -18.0), // turns south across overhead bridge
          new THREE.Vector3(36.5, 6.5, -18.0),  // drops vertically outside north mezzanine rail to Y = 6.5m
          new THREE.Vector3(36.5, 6.5, 0.0),    // runs south through open bay (no columns at X = 36.5)
          new THREE.Vector3(36.5, 12.2, 0.0)    // rises vertically into HP Case 3 Stage 4 Bottom Suction Flange
        ]
      },
      // 12. K-301 HP 4th Stage Discharge (240 bar) -> E-315 Final Make-Up Cooler (Upper Corridor Y = 30m)
      {
        name: 'K-301 4th Stage Discharge -> E-315 TUBE INLET (Gas in Tubes)',
        color: 0x0284c7,
        radius: 0.48,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'HP MAKE-UP -> E-315 TUBES',
        fluidLabel: 'High Pressure Syngas (240 bar) from HP Casing into E-315 Tubes',
        points: [
          new THREE.Vector3(40.5, 20.3, 0.0),  // top discharge nozzle of HP casing flange (Stage 4)
          new THREE.Vector3(40.5, 30.0, 0.0),  // rises to Upper Elevation Tier Y = 30m
          new THREE.Vector3(40.5, 30.0, 38.0), // turns south across overhead bridge to Lane 4 at Z = 38m
          new THREE.Vector3(82.0, 30.0, 38.0), // turns east along Lane 4 to E-315 West Channel Head X-plane
          new THREE.Vector3(82.0, 30.0, 60.0), // turns south to E-315 West Channel Head plane at Z = 60m
          new THREE.Vector3(82.0, 9.45, 60.0)  // drops straight vertically into E-315 West TUBE top nozzle flange
        ]
      },
      // 13. E-315 TUBE OUTLET -> V-310 High-Pressure Separator (East Yard Trench)
      {
        name: 'E-315 TUBE OUTLET -> V-310 HP Separator',
        color: 0x0284c7,
        radius: 0.48,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'TO V-310 HP DRUM (FROM TUBES)',
        fluidLabel: 'Cooled Make-Up Syngas from E-315 Tubes to V-310',
        points: [
          new THREE.Vector3(98.0, 4.95, 60.0),  // E-315 East TUBE bottom nozzle flange
          new THREE.Vector3(98.0, 3.8, 60.0),   // elevated pipe rack at Y = 3.8m (above foundation blocks)
          new THREE.Vector3(98.0, 3.8, -36.0),  // runs north along East trench corridor (far east of mezzanine)
          new THREE.Vector3(90.0, 3.8, -36.0),  // turns west to V-310 centerline in North Yard alley
          new THREE.Vector3(90.0, 3.8, -48.0),  // runs north clear of footing
          new THREE.Vector3(90.0, 18.25, -48.0),// rises to feed elevation
          new THREE.Vector3(90.0, 18.25, -57.0) // runs north into V-310 feed inlet flange
        ]
      },
      // 14. V-310 Overhead Syngas -> Battery Limit to Section 400 Synthesis Loop
      {
        name: 'V-310 Overhead HP Syngas -> Section 400 Synthesis Loop',
        color: 0x0284c7,
        radius: 0.54,
        speed: 0.09,
        particleColor: 0x67e8f9,
        streamTag: 'HP SYNGAS TO SYNLOOP',
        fluidLabel: 'Pure Make-up Syngas (240 bar) to R-401 Loop',
        points: [
          new THREE.Vector3(90.0, 38.5, -60.0),  // V-310 top head outlet flange
          new THREE.Vector3(90.0, 44.0, -60.0),  // rises vertically to top rack Tier 5 at Y = 44m
          new THREE.Vector3(90.0, 44.0, -45.0),  // turns south to North piperack corridor at Z = -45m
          new THREE.Vector3(190.0, 44.0, -45.0)  // runs east along North piperack straight to plant boundary
        ]
      },
      // 15. High-Pressure 65 bar (435°C) Steam Supply Header to K-301T Turbine (North Utility Corridor Z = -8m)
      {
        name: 'HP Steam Supply (65 bar, 435°C) -> K-301T Turbine Chest',
        color: 0xd97706,
        radius: 0.56,
        speed: 0.09,
        particleColor: 0xfcd34d,
        streamTag: 'HP STEAM 65 BAR (435°C)',
        fluidLabel: 'Superheated High Pressure Steam (65 bar, 435°C)',
        points: [
          new THREE.Vector3(-190.0, 26.0, -8.0), // enters from West Battery Limit in North utility corridor
          new THREE.Vector3(-37.5, 26.0, -8.0),  // runs east along North utility lane at Z = -8m
          new THREE.Vector3(-37.5, 26.0, 0.0),   // turns south to K-301T turbine chest plane
          new THREE.Vector3(-37.5, 21.3, 0.0)    // drops vertically into K-301T Steam Chest inlet flange
        ]
      },
      // 16. Medium Pressure 39 bar Steam Extraction & Discharge Header from K-301T Turbine
      {
        name: 'MP Steam Extraction & Discharge (39 bar) from K-301T -> Plant MP Header',
        color: 0xb45309,
        radius: 0.50,
        speed: 0.08,
        particleColor: 0xfbbf24,
        streamTag: 'MP STEAM 39 BAR',
        fluidLabel: 'Medium Pressure Steam Extraction & Discharge (39 bar)',
        points: [
          new THREE.Vector3(-30.0, 20.9, 0.0),   // from K-301T MP extraction nozzle on top
          new THREE.Vector3(-30.0, 26.0, 0.0),   // rises vertically to rack level Y = 26m
          new THREE.Vector3(-30.0, 26.0, -12.0), // turns north to North utility corridor at Z = -12m
          new THREE.Vector3(-190.0, 26.0, -12.0) // runs west along North utility lane to plant boundary
        ]
      },
      // 17. Cooling Water Supply Header (WC Supply 32°C - 4.5 kg/cm²G at Z = 82m, Y = 5.0m)
      {
        name: 'Cooling Water Supply Main Header (WC Supply 32°C)',
        color: 0x0284c7,
        radius: 0.54,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'WC SUPPLY 32°C (ماء التبريد الداخل)',
        fluidLabel: 'Industrial Cooling Water Supply (WC) - 32°C, 4.5 bar (شبكة ماء التبريد الداخل)',
        points: [
          new THREE.Vector3(-190.0, 5.0, 82.0),
          new THREE.Vector3(190.0, 5.0, 82.0)
        ]
      },
      // 18a. WC Supply Branch -> E-301 TUBE INLET (Gas in Shell / WC in Tubes)
      {
        name: 'WC Supply -> E-301 TUBES (Gas in Shell / WC in Tubes)',
        color: 0x0284c7,
        radius: 0.44,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'WC -> E-301 TUBES (ماء داخل للأنابيب)',
        fluidLabel: 'Cooling Water WC into E-301 Tube Side (ماء التبريد الداخل بالأنابيب)',
        points: [
          new THREE.Vector3(-98.0, 5.0, 82.0), // take-off from WC supply main at Z = 82m
          new THREE.Vector3(-98.0, 2.6, 82.0), // elevated sleeper support at Y = 2.6m
          new THREE.Vector3(-98.0, 2.6, 60.0), // runs north to under West Channel Head
          new THREE.Vector3(-98.0, 4.95, 60.0) // rises vertically into E-301 West TUBE Channel Head bottom nozzle flange
        ]
      },
      // 18b. WC Supply Branch -> E-302 SHELL INLET (Gas in Tubes / WC in Shell)
      {
        name: 'WC Supply -> E-302 SHELL (Gas in Tubes / WC in Shell)',
        color: 0x0284c7,
        radius: 0.44,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'WC -> E-302 SHELL (ماء داخل للشيل)',
        fluidLabel: 'Cooling Water WC into E-302 Shell Side (ماء التبريد الداخل بالشيل)',
        points: [
          new THREE.Vector3(-43.5, 5.0, 82.0), // take-off from WC supply main
          new THREE.Vector3(-43.5, 2.6, 82.0), // elevated sleeper level at Y = 2.6m
          new THREE.Vector3(-43.5, 2.6, 60.0), // runs north in wide open span between saddles
          new THREE.Vector3(-43.5, 3.9, 60.0)  // rises vertically straight up into E-302 Bottom SHELL Nozzle flange
        ]
      },
      // 18c. WC Supply Branch -> E-303 SHELL INLET (Gas in Tubes / WC in Shell)
      {
        name: 'WC Supply -> E-303 SHELL (Gas in Tubes / WC in Shell)',
        color: 0x0284c7,
        radius: 0.44,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'WC -> E-303 SHELL (ماء داخل للشيل)',
        fluidLabel: 'Cooling Water WC into E-303 Shell Side (ماء التبريد الداخل بالشيل)',
        points: [
          new THREE.Vector3(1.5, 5.0, 82.0),  // take-off from WC supply main
          new THREE.Vector3(1.5, 2.6, 82.0),  // elevated sleeper level at Y = 2.6m
          new THREE.Vector3(1.5, 2.6, 60.0),  // runs north in wide open span between saddles
          new THREE.Vector3(1.5, 3.9, 60.0)   // rises vertically straight up into E-303 Bottom SHELL Nozzle flange
        ]
      },
      // 18d. WC Supply Branch -> E-304 SHELL INLET (Gas in Tubes / WC in Shell)
      {
        name: 'WC Supply -> E-304 SHELL (Gas in Tubes / WC in Shell)',
        color: 0x0284c7,
        radius: 0.44,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'WC -> E-304 SHELL (ماء داخل للشيل)',
        fluidLabel: 'Cooling Water WC into E-304 Shell Side (ماء التبريد الداخل بالشيل)',
        points: [
          new THREE.Vector3(46.5, 5.0, 82.0),  // take-off from WC supply main
          new THREE.Vector3(46.5, 2.6, 82.0),  // elevated sleeper level at Y = 2.6m
          new THREE.Vector3(46.5, 2.6, 60.0),  // runs north in wide open span between saddles
          new THREE.Vector3(46.5, 3.9, 60.0)   // rises vertically straight up into E-304 Bottom SHELL Nozzle flange
        ]
      },
      // 18e. WC Supply Branch -> E-315 SHELL INLET (Gas in Tubes / WC in Shell)
      {
        name: 'WC Supply -> E-315 SHELL (Gas in Tubes / WC in Shell)',
        color: 0x0284c7,
        radius: 0.44,
        speed: 0.08,
        particleColor: 0x38bdf8,
        streamTag: 'WC -> E-315 SHELL (ماء داخل للشيل)',
        fluidLabel: 'Cooling Water WC into E-315 Shell Side (ماء التبريد الداخل بالشيل)',
        points: [
          new THREE.Vector3(91.5, 5.0, 82.0),  // take-off from WC supply main
          new THREE.Vector3(91.5, 2.6, 82.0),  // elevated sleeper level at Y = 2.6m
          new THREE.Vector3(91.5, 2.6, 60.0),  // runs north in wide open span between saddles
          new THREE.Vector3(91.5, 3.9, 60.0)   // rises vertically straight up into E-315 Bottom SHELL Nozzle flange
        ]
      },
      // 19. Cooling Water Return Header (WCR Return 40°C - 2.8 kg/cm²G at Z = 82m, Y = 16.0m)
      {
        name: 'Cooling Water Return (WCR) Main Header (40°C)',
        color: 0x0369a1,
        radius: 0.56,
        speed: 0.08,
        particleColor: 0x0284c7,
        streamTag: 'WCR RETURN 40°C (ماء التبريد الراجع)',
        fluidLabel: 'Warm Cooling Water Return (WCR) to Cooling Towers - 40°C, 2.8 bar (شبكة ماء التبريد الراجع)',
        points: [
          new THREE.Vector3(-190.0, 16.0, 82.0),
          new THREE.Vector3(190.0, 16.0, 82.0)
        ]
      },
      // 19a. WCR Return Branch: E-301 TUBE OUTLET -> Return Header (Gas in Shell / WCR out Tubes)
      {
        name: 'E-301 TUBES -> WCR Return Header (Gas in Shell / WCR out Tubes)',
        color: 0x0369a1,
        radius: 0.44,
        speed: 0.08,
        particleColor: 0x0284c7,
        streamTag: 'E-301 TUBES -> WCR RETURN (ماء راجع من الأنابيب)',
        fluidLabel: 'Warm Water WCR from E-301 Tube Side (خروج ماء التبريد الراجع WCR من أنابيب E-301)',
        points: [
          new THREE.Vector3(-82.0, 9.45, 60.0), // from E-301 East TUBE Channel Head top nozzle flange
          new THREE.Vector3(-82.0, 16.0, 60.0), // rises vertically to upper rack Tier 2
          new THREE.Vector3(-82.0, 16.0, 82.0)  // turns south into WCR Return Header at Z = 82m
        ]
      },
      // 19b. WCR Return Branch: E-302 SHELL OUTLET -> Return Header (Gas in Tubes / WCR out Shell)
      {
        name: 'E-302 SHELL -> WCR Return Header (Gas in Tubes / WCR out Shell)',
        color: 0x0369a1,
        radius: 0.44,
        speed: 0.08,
        particleColor: 0x0284c7,
        streamTag: 'E-302 SHELL -> WCR RETURN (ماء راجع من الشيل)',
        fluidLabel: 'Warm Water WCR from E-302 Shell Side (خروج ماء التبريد الراجع WCR من شيل E-302)',
        points: [
          new THREE.Vector3(-46.5, 10.5, 60.0), // from E-302 Top SHELL Nozzle flange
          new THREE.Vector3(-46.5, 16.0, 60.0), // rises vertically to rack elevation Y = 16m
          new THREE.Vector3(-46.5, 16.0, 82.0)  // turns south into WCR Return Header at Z = 82m
        ]
      },
      // 19c. WCR Return Branch: E-303 SHELL OUTLET -> Return Header (Gas in Tubes / WCR out Shell)
      {
        name: 'E-303 SHELL -> WCR Return Header (Gas in Tubes / WCR out Shell)',
        color: 0x0369a1,
        radius: 0.44,
        speed: 0.08,
        particleColor: 0x0284c7,
        streamTag: 'E-303 SHELL -> WCR RETURN (ماء راجع من الشيل)',
        fluidLabel: 'Warm Water WCR from E-303 Shell Side (خروج ماء التبريد الراجع WCR من شيل E-303)',
        points: [
          new THREE.Vector3(-1.5, 10.5, 60.0),  // from E-303 Top SHELL Nozzle flange
          new THREE.Vector3(-1.5, 16.0, 60.0),  // rises vertically to rack elevation Y = 16m
          new THREE.Vector3(-1.5, 16.0, 82.0)   // turns south into WCR Return Header at Z = 82m
        ]
      },
      // 19d. WCR Return Branch: E-304 SHELL OUTLET -> Return Header (Gas in Tubes / WCR out Shell)
      {
        name: 'E-304 SHELL -> WCR Return Header (Gas in Tubes / WCR out Shell)',
        color: 0x0369a1,
        radius: 0.44,
        speed: 0.08,
        particleColor: 0x0284c7,
        streamTag: 'E-304 SHELL -> WCR RETURN (ماء راجع من الشيل)',
        fluidLabel: 'Warm Water WCR from E-304 Shell Side (خروج ماء التبريد الراجع WCR من شيل E-304)',
        points: [
          new THREE.Vector3(43.5, 10.5, 60.0),  // from E-304 Top SHELL Nozzle flange
          new THREE.Vector3(43.5, 16.0, 60.0),  // rises vertically to rack elevation Y = 16m
          new THREE.Vector3(43.5, 16.0, 82.0)   // turns south into WCR Return Header at Z = 82m
        ]
      },
      // 19e. WCR Return Branch: E-315 SHELL OUTLET -> Return Header (Gas in Tubes / WCR out Shell)
      {
        name: 'E-315 SHELL -> WCR Return Header (Gas in Tubes / WCR out Shell)',
        color: 0x0369a1,
        radius: 0.44,
        speed: 0.08,
        particleColor: 0x0284c7,
        streamTag: 'E-315 SHELL -> WCR RETURN (ماء راجع من الشيل)',
        fluidLabel: 'Warm Water WCR from E-315 Shell Side (خروج ماء التبريد الراجع WCR من شيل E-315)',
        points: [
          new THREE.Vector3(88.5, 10.5, 60.0),  // from E-315 Top SHELL Nozzle flange
          new THREE.Vector3(88.5, 16.0, 60.0),  // rises vertically to rack elevation Y = 16m
          new THREE.Vector3(88.5, 16.0, 82.0)   // turns south into WCR Return Header at Z = 82m
        ]
      }
    ];

    const bandTexCache = new Map<string, THREE.CanvasTexture>();

    pipeDefinitions.forEach((def) => {
      const effectiveRadius = def.radius * PIPE_SCALE;
      const cladRadius = effectiveRadius + 0.12;

      const tubeMat = new THREE.MeshStandardMaterial({
        color: def.color,
        roughness: 0.28,
        metalness: 0.92
      });

      const pipeGroup = new THREE.Group();
      pipeGroup.name = def.name;
      pipeGroup.userData = {
        name: def.name,
        streamTag: def.streamTag,
        fluidLabel: def.fluidLabel,
        isInsulated: true,
        insulationType: 'Mineral Wool / Stucco Aluminum Cladding (صوف صخري + غلاف ألومنيوم مضلع)',
        operatingPress: def.name.match(/\(([^)]+bar[^)]*)\)/)?.[1] || '105 bar'
      };

      // Straight Segment Spools & Aluminum Cladding
      for (let i = 0; i < def.points.length - 1; i++) {
        const p1 = def.points[i];
        const p2 = def.points[i + 1];
        const dir = new THREE.Vector3().subVectors(p2, p1);
        const len = dir.length();

        if (len > 0.01) {
          const mid = new THREE.Vector3().addVectors(p1, p2).multiplyScalar(0.5);
          const up = new THREE.Vector3(0, 1, 0);
          const normDir = dir.clone().normalize();

          // Core Pipe (optimized to 12 segments)
          const coreGeo = new THREE.CylinderGeometry(effectiveRadius, effectiveRadius, len, 12, 1, false);
          const coreMesh = new THREE.Mesh(coreGeo, tubeMat);
          coreMesh.position.copy(mid);
          if (Math.abs(normDir.dot(up)) < 0.9999) {
            coreMesh.quaternion.setFromUnitVectors(up, normDir);
          } else if (normDir.y < 0) {
            coreMesh.rotation.x = Math.PI;
          }
          pipeGroup.add(coreMesh);

          // Aluminum Thermal Cladding Jacket (optimized 16 segments, shadows disabled for performance)
          const cladGeo = new THREE.CylinderGeometry(cladRadius, cladRadius, Math.max(0.05, len - 0.2), 16, 1, false);
          const cladMesh = new THREE.Mesh(cladGeo, this.matAluminumCladding);
          cladMesh.position.copy(mid);
          if (Math.abs(normDir.dot(up)) < 0.9999) {
            cladMesh.quaternion.setFromUnitVectors(up, normDir);
          } else if (normDir.y < 0) {
            cladMesh.rotation.x = Math.PI;
          }
          cladMesh.castShadow = false;
          cladMesh.receiveShadow = false;
          pipeGroup.add(cladMesh);
          this.claddingMeshes.push(cladMesh);

          // SS304 Clamping Straps (spaced every 4m, 12 segments)
          const numBands = Math.max(1, Math.floor(len / 4.0));
          for (let b = 1; b <= numBands; b++) {
            const frac = b / (numBands + 1);
            const bandPos = new THREE.Vector3().addVectors(p1, dir.clone().multiplyScalar(frac));
            const strapGeo = new THREE.CylinderGeometry(cladRadius * 1.025, cladRadius * 1.025, 0.18, 12);
            const strapMesh = new THREE.Mesh(strapGeo, this.matCladdingStraps);
            strapMesh.position.copy(bandPos);
            if (Math.abs(normDir.dot(up)) < 0.9999) {
              strapMesh.quaternion.setFromUnitVectors(up, normDir);
            } else if (normDir.y < 0) {
              strapMesh.rotation.x = Math.PI;
            }
            pipeGroup.add(strapMesh);
          }

          // ASME Identification Band with caching
          if (len > 8.0) {
            const cacheKey = `${def.streamTag}_${def.color}`;
            let bandTex = bandTexCache.get(cacheKey);
            if (!bandTex) {
              bandTex = createThermalInsulationBandTexture(
                def.streamTag,
                def.fluidLabel,
                def.name.split(':')[0],
                def.name.match(/\(([^)]+)\)/)?.[1] || 'SYNGAS',
                `#${def.color.toString(16).padStart(6, '0')}`,
                true
              );
              bandTexCache.set(cacheKey, bandTex);
            }
            const idBandGeo = new THREE.CylinderGeometry(cladRadius * 1.035, cladRadius * 1.035, 1.8, 16);
            const idBandMat = new THREE.MeshStandardMaterial({ map: bandTex, roughness: 0.25, metalness: 0.3 });
            const idBandMesh = new THREE.Mesh(idBandGeo, idBandMat);
            idBandMesh.position.copy(mid);
            if (Math.abs(normDir.dot(up)) < 0.9999) {
              idBandMesh.quaternion.setFromUnitVectors(up, normDir);
            } else if (normDir.y < 0) {
              idBandMesh.rotation.x = Math.PI;
            }
            pipeGroup.add(idBandMesh);
          }
        }
      }

      // Smooth 90° Elbow Gores & Companion Flanges (optimized segments)
      def.points.forEach((pt, idx) => {
        if (idx > 0 && idx < def.points.length - 1) {
          const elbowMesh = new THREE.Mesh(new THREE.SphereGeometry(cladRadius * 1.02, 12, 8), this.matLobsterElbow);
          elbowMesh.position.copy(pt);
          pipeGroup.add(elbowMesh);
          this.claddingMeshes.push(elbowMesh);
        } else {
          const nextPt = idx === 0 ? def.points[1] : def.points[def.points.length - 2];
          const termDir = new THREE.Vector3().subVectors(idx === 0 ? pt : pt, nextPt).normalize();
          const termFlangeGeo = new THREE.CylinderGeometry(effectiveRadius * 1.7, effectiveRadius * 1.7, 0.42, 16);
          const termFlange = new THREE.Mesh(termFlangeGeo, this.matFlange);
          termFlange.position.copy(pt);
          const up = new THREE.Vector3(0, 1, 0);
          if (Math.abs(termDir.dot(up)) < 0.9999) {
            termFlange.quaternion.setFromUnitVectors(up, termDir);
          } else if (termDir.y < 0) {
            termFlange.rotation.x = Math.PI;
          }
          pipeGroup.add(termFlange);
        }
      });

      this.group.add(pipeGroup);

      // Register pipeline clicking
      const pipeId = def.name.toLowerCase().replace(/[^a-z0-9]/g, '_');
      const info: EquipmentInfo = {
        id: pipeId,
        tag: def.streamTag,
        name: def.name,
        arabicName: `خط غاز التصنيع والضاغط: ${def.fluidLabel}`,
        type: 'piping',
        section: 'Syngas Compression (K-301 Complex)',
        sectionNumber: 3,
        rowNumber: 5,
        position: def.points[Math.floor(def.points.length / 2)].clone(),
        inletStream: 'Upstream Stage',
        outletStream: 'Downstream Stage / Intercooler',
        operatingTemp: '40°C - 145°C',
        operatingPress: def.name.match(/\(([^)]+bar[^)]*)\)/)?.[1] || '105 bar',
        catalystOrInternals: 'عزل حراري وغلاف ألومنيوم معزول Stucco-Embossed 0.8mm مع أحزمة شد SS304',
        description: 'خط أنابيب نقل وضغط غاز التصنيع عالي الضغط مجهز بحماية ضد الاهتزازات (Anti-Vibration Supports) وعزل حراري كامل.'
      };

      pipeGroup.userData = { equipmentId: pipeId, equipmentInfo: info, isClickable: true };
      this.interactiveMeshes.push(pipeGroup);
    });
  }

  // 8. High-Visibility Industrial Telemetry Badges with Arabic Typography
  private buildEquipmentBadgesAndSigns() {
    const badges: Array<{
      tag: string;
      ar: string;
      param: string;
      pos: THREE.Vector3;
      scale?: [number, number];
    }> = [
      {
        tag: 'K-301 TRAIN',
        ar: 'قطار ضاغط غاز التخليق: ٣ أكياس (L.P. و M.P. و H.P.) بـ ٤ مراحل كبس + التوربين الدافع K-301T',
        param: '3 Casings: Case 1 (LP: 25.0->44.5 kg/cm²G), Case 2 (MP: 44.5->75.0 kg/cm²G), Case 3 (HP: 75.0->130 & 130->170..239 kg/cm²G) | Steam Turbine KT-301 (65 kg/cm² @ 435°C, 18.5 MW)',
        pos: new THREE.Vector3(0, 36.0, 0),
        scale: [32.0, 7.5]
      },
      { tag: 'KT-301', ar: 'التوربين البخاري الدافع KT-301', param: 'HP Steam 65 kg/cm² (435°C) -> MP Scania Extraction (39 kg/cm²) | 18.5 MW | 10,000 RPM Driver', pos: new THREE.Vector3(-32, 26.0, 0), scale: [16.0, 5.5] },
      { tag: 'K-301 LP', ar: 'جسم الضغط المنخفض L.P. (Case 1 - المرحلة الأولى)', param: 'LP Casing (Stage 1): 25.0 -> 44.5 kg/cm²G | 1st Stage Suction from V-301 -> Discharge to E-302', pos: new THREE.Vector3(-8.5, 26.0, 0), scale: [16.0, 5.5] },
      { tag: 'K-301 MP', ar: 'جسم الضغط المتوسط M.P. (Case 2 - المرحلة الثانية)', param: 'MP Casing (Stage 2): 44.5 -> 75.0 kg/cm²G | 2nd Stage Suction from V-302 -> Discharge to E-303', pos: new THREE.Vector3(12.0, 26.0, 0), scale: [16.0, 5.5] },
      { tag: 'K-301 HP', ar: 'جسم الضغط العالي H.P. (Case 3 - المرحلتان 3 و 4 وعجلة التدوير)', param: 'HP Casing (Stages 3 & 4): St.3 (75.0 -> 130.0 kg/cm²G) + St.4 (130.0 -> 170..239 kg/cm²G) + Recycle ΔP 28.6 kg/cm²G', pos: new THREE.Vector3(34.0, 26.0, 0), scale: [16.0, 5.5] },
      { tag: 'V-301', ar: 'عازل سحب المرحلة الأولى V-301', param: '25.0 kg/cm²G | 43°C -> Knock-out Droplets before Stage 1 (LAHH Trip Protected)', pos: new THREE.Vector3(-90, 38.0, -60), scale: [14.0, 4.8] },
      { tag: 'E-301', ar: 'مبادل E-301 (الغاز بالشيل / ماء التبريد WC الداخل بالأنابيب و WCR الخارج بالأنابيب)', param: 'Gas in SHELL (129°C -> 43°C) | Water: WC in TUBES (32°C) -> WCR out TUBES (40°C) | 25.0 kg/cm²G', pos: new THREE.Vector3(-90, 18.0, 60), scale: [16.0, 5.5] },
      { tag: 'V-302', ar: 'عازل سحب المرحلة الثانية V-302', param: '44.5 kg/cm²G | 43°C -> Interstage Knock-Out (LAHH Trip Protected)', pos: new THREE.Vector3(-45, 40.0, -60), scale: [14.0, 4.8] },
      { tag: 'E-302', ar: 'مبادل E-302 (الغاز بالأنابيب / ماء التبريد WC الداخل بالشيل و WCR الخارج بالشيل)', param: 'Gas in TUBES (135°C -> 43°C) | Water: WC in SHELL (32°C) -> WCR out SHELL (40°C) | 44.5 kg/cm²G', pos: new THREE.Vector3(-45, 18.0, 60), scale: [16.0, 5.5] },
      { tag: 'V-303', ar: 'عازل سحب المرحلة الثالثة V-303', param: '75.0 kg/cm²G | 43°C -> Interstage Knock-Out (LAHH Trip Protected)', pos: new THREE.Vector3(0, 42.0, -60), scale: [14.0, 4.8] },
      { tag: 'E-303', ar: 'مبادل E-303 (الغاز بالأنابيب / ماء التبريد WC الداخل بالشيل و WCR الخارج بالشيل)', param: 'Gas in TUBES (142°C -> 43°C) | Water: WC in SHELL (32°C) -> WCR out SHELL (40°C) | 75.0 kg/cm²G', pos: new THREE.Vector3(0, 18.0, 60), scale: [16.0, 5.5] },
      { tag: 'V-304', ar: 'عازل سحب المرحلة الرابعة V-304', param: '130.0 kg/cm²G | 43°C -> 4th Stage Suction Knock-Out before 239 kg/cm²G (LAHH Trip)', pos: new THREE.Vector3(45, 44.0, -60), scale: [14.0, 4.8] },
      { tag: 'E-304', ar: 'مبادل E-304 (الغاز بالأنابيب / ماء التبريد WC الداخل بالشيل و WCR الخارج بالشيل)', param: 'Gas in TUBES (138°C -> 43°C) | Water: WC in SHELL (32°C) -> WCR out SHELL (40°C) | 130.0 kg/cm²G', pos: new THREE.Vector3(45, 18.0, 60), scale: [16.0, 5.5] },
      { tag: 'V-310', ar: 'فاصل غاز التصنيع والتدوير النهائي V-310', param: '170.0..239.0 kg/cm²G | 43°C -> HP Make-Up Feed to SynLoop R-401', pos: new THREE.Vector3(90, 48.0, -60), scale: [16.0, 5.5] },
      { tag: 'E-315', ar: 'مبادل E-315 (الغاز بالأنابيب / ماء التبريد WC الداخل بالشيل و WCR الخارج بالشيل)', param: 'Gas in TUBES (55°C -> 43°C) | Water: WC in SHELL (32°C) -> WCR out SHELL (40°C) | 170..239 kg/cm²G', pos: new THREE.Vector3(90, 18.0, 60), scale: [16.0, 5.5] },
      { tag: 'WC HEADER', ar: 'أنبوب التغذية الرئيسي لمياه التبريد الداخلة WC', param: 'Cooling Water Supply (WC) - 32°C, 4.5 kg/cm²G -> To E-301 Tubes & E-302/303/304/315 Shells', pos: new THREE.Vector3(0, 10.0, 82.0), scale: [18.0, 5.0] },
      { tag: 'WCR HEADER', ar: 'أنبوب التجميع الرئيسي لمياه التبريد الراجعة WCR', param: 'Cooling Water Return (WCR) - 40°C, 2.8 kg/cm²G -> From E-301 Tubes & E-302/303/304/315 Shells', pos: new THREE.Vector3(0, 21.0, 82.0), scale: [18.0, 5.0] },
      { tag: 'LO/SO CONSOLE', ar: 'منظومة الزيت: Lube Oil (P-302 A,B) و Seal Oil (P-303, P-304 A,B)', param: 'Lube Oil at 2.8 kg/cm²G (P-302 A,B) | Seal Oil ΔP 0.3-0.5 kg/cm² (P-303, P-304 A,B)', pos: new THREE.Vector3(-115, 16.0, 0), scale: [16.0, 5.5] },
      {
        tag: 'DCS-300-PFD',
        ar: 'شاشة المخطط التشغيلي والتحكم الرقمي لضاغط K-301',
        param: 'K-301 Complex Master Digital PFD Screen | DWG 6112P-100-300-00 | Click to inspect',
        pos: new THREE.Vector3(0, 22.0, 125.0),
        scale: [22.0, 5.5]
      }
    ];

    badges.forEach((b) => {
      const canvas = document.createElement('canvas');
      canvas.width = 1024;
      canvas.height = 360;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Dark Industrial HUD Card
      ctx.fillStyle = 'rgba(10, 18, 30, 0.96)';
      ctx.fillRect(0, 0, 1024, 360);

      // Gradient Accent Header
      const grad = ctx.createLinearGradient(0, 0, 1024, 0);
      grad.addColorStop(0, '#0284c7');
      grad.addColorStop(0.5, '#38bdf8');
      grad.addColorStop(1, '#0284c7');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 1024, 16);

      // Border
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 6;
      ctx.strokeRect(3, 3, 1018, 354);

      // Tag Badge Box
      ctx.direction = 'ltr';
      ctx.font = 'bold 32px sans-serif';
      const measuredTag = ctx.measureText(b.tag).width;
      const tagBoxWidth = Math.max(240, measuredTag + 40);
      ctx.fillStyle = '#0369a1';
      ctx.fillRect(30, 35, tagBoxWidth, 60);
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText(b.tag, 30 + tagBoxWidth / 2, 78);

      // Arabic Name
      ctx.direction = 'rtl';
      ctx.textAlign = 'right';
      ctx.fillStyle = '#fef08a';
      ctx.font = b.ar.length > 45 ? 'bold 24px sans-serif' : (b.ar.length > 30 ? 'bold 28px sans-serif' : 'bold 34px sans-serif');
      ctx.fillText(b.ar, 990, 78);

      // DCS Telemetry Line
      ctx.direction = 'ltr';
      ctx.textAlign = 'left';
      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 23px monospace';
      ctx.fillText(`⚡ DCS TELEMETRY:`, 30, 150);

      ctx.fillStyle = '#f8fafc';
      ctx.font = b.param.length > 70 ? 'bold 20px sans-serif' : 'bold 23px sans-serif';
      ctx.fillText(b.param, 30, 210);

      // Status indicator pill
      ctx.fillStyle = 'rgba(16, 185, 129, 0.2)';
      ctx.fillRect(30, 260, 964, 60);
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2;
      ctx.strokeRect(30, 260, 964, 60);

      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(60, 290, 11, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 22px sans-serif';
      ctx.fillText('ONLINE • NORMAL RUNNING (10,000 RPM / ZERO VIBRATION)', 85, 298);

      const tex = new THREE.CanvasTexture(canvas);
      tex.generateMipmaps = true;
      tex.minFilter = THREE.LinearFilter;
      tex.magFilter = THREE.LinearFilter;
      tex.anisotropy = 2;
      tex.needsUpdate = true;
      const spriteMat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false });
      const sprite = new THREE.Sprite(spriteMat);
      sprite.position.copy(b.pos);
      const s = b.scale || [14.0, 4.8];
      sprite.scale.set(s[0], s[1], 1.0);
      this.group.add(sprite);
    });
  }

  // 8b. Stage Number & Pipeline Flow Badges (#1 to #15, #S1, #S2) placed on every process pipe
  private buildPipelineStageNumberBadges() {
    const stageBadges = [
      { num: '1', ar: 'غاز التصنيع الطازج (25 kg/cm²G) -> شيل E-301', pos: new THREE.Vector3(-120.0, 22.0, 60.0), col: '#0284c7' },
      { num: '2', ar: 'خروج شيل E-301 (25 kg/cm²G) -> عازل V-301', pos: new THREE.Vector3(-90.0, 20.0, 5.0), col: '#0284c7' },
      { num: '3', ar: 'سحب المرحلة 1 (25 kg/cm²G) -> كابينة LP', pos: new THREE.Vector3(-45.0, 40.0, -42.0), col: '#0284c7' },
      { num: '4', ar: 'طرد مرحلة 1 مضغوط (44.5 kg/cm²G) -> أنابيب E-302', pos: new THREE.Vector3(-35.0, 32.0, 38.0), col: '#0369a1' },
      { num: '5', ar: 'خروج أنابيب E-302 (44.5 kg/cm²G) -> عازل V-302', pos: new THREE.Vector3(-42.0, 16.0, 5.0), col: '#0284c7' },
      { num: '6', ar: 'سحب المرحلة 2 (44.5 kg/cm²G) -> كابينة MP', pos: new THREE.Vector3(-18.0, 40.0, -42.0), col: '#0284c7' },
      { num: '7', ar: 'طرد مرحلة 2 مضغوط (75 kg/cm²G) -> أنابيب E-303', pos: new THREE.Vector3(3.0, 34.0, 38.0), col: '#0369a1' },
      { num: '8', ar: 'خروج أنابيب E-303 (75 kg/cm²G) -> عازل V-303', pos: new THREE.Vector3(5.0, 16.0, 5.0), col: '#0284c7' },
      { num: '9', ar: 'سحب المرحلة 3 (75 kg/cm²G) -> كابينة HP', pos: new THREE.Vector3(14.0, 42.0, -45.0), col: '#0284c7' },
      { num: '10', ar: 'طرد مرحلة 3 مضغوط (130 kg/cm²G) -> أنابيب E-304', pos: new THREE.Vector3(34.5, 29.0, 28.0), col: '#0369a1' },
      { num: '11', ar: 'خروج أنابيب E-304 (130 kg/cm²G) -> عازل V-304', pos: new THREE.Vector3(49.0, 16.0, 5.0), col: '#0284c7' },
      { num: '12', ar: 'سحب المرحلة 4 (130 kg/cm²G) -> كابينة HP', pos: new THREE.Vector3(41.0, 44.0, -45.0), col: '#0284c7' },
      { num: '13', ar: 'طرد مرحلة 4 النهائي (170..239 kg/cm²G) -> أنابيب E-315', pos: new THREE.Vector3(61.0, 34.0, 38.0), col: '#0284c7' },
      { num: '14', ar: 'خروج أنابيب E-315 (170..239 kg/cm²G) -> فاصل V-310', pos: new THREE.Vector3(94.0, 16.0, 5.0), col: '#0284c7' },
      { num: '15', ar: 'غاز التصنيع التعويضي (170..239 kg/cm²G) -> حلقة R-401', pos: new THREE.Vector3(135.0, 48.0, -45.0), col: '#0284c7' },
      { num: 'S1', ar: 'بخار محمص عالي الضغط (65 kg/cm², 435°C) -> توربين KT-301', pos: new THREE.Vector3(-70.0, 30.0, -8.0), col: '#d97706' },
      { num: 'S2', ar: 'استخراج بخار متوسط وتصريف (39 kg/cm²) عبر Scania', pos: new THREE.Vector3(-30.0, 26.0, 5.0), col: '#b45309' }
    ];

    stageBadges.forEach((b) => {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 160;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Dark solid background
      ctx.fillStyle = 'rgba(7, 16, 32, 0.95)';
      ctx.fillRect(0, 0, 512, 160);

      // Accent border
      ctx.strokeStyle = b.col;
      ctx.lineWidth = 5;
      ctx.strokeRect(3, 3, 506, 154);

      // Inner glow line
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1;
      ctx.strokeRect(8, 8, 496, 144);

      // Number circular badge on the left
      ctx.fillStyle = b.col;
      ctx.beginPath();
      ctx.arc(70, 80, 48, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 4;
      ctx.stroke();

      ctx.direction = 'ltr';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#ffffff';
      ctx.font = b.num.length > 2 ? 'bold 32px monospace' : 'bold 48px monospace';
      ctx.fillText(b.num, 70, 80);

      // Arabic stage description
      ctx.direction = 'rtl';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#fef08a';
      ctx.font = b.ar.length > 40 ? 'bold 20px sans-serif' : 'bold 23px sans-serif';
      ctx.fillText(b.ar, 485, 80);

      const tex = new THREE.CanvasTexture(canvas);
      tex.generateMipmaps = false;
      tex.minFilter = THREE.LinearFilter;
      tex.magFilter = THREE.LinearFilter;
      tex.needsUpdate = true;

      const spriteMat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false });
      const sprite = new THREE.Sprite(spriteMat);
      sprite.position.copy(b.pos);
      sprite.scale.set(12.0, 3.75, 1.0);
      this.group.add(sprite);
    });
  }

  // 9. Grand Master DCS Operations & PFD Display Screen (Unit 300 / K-301)
  private buildDcsInfoScreens() {
    const screenGroup = new THREE.Group();
    screenGroup.position.set(0, 0, 125);
    screenGroup.name = 'Unit300_Master_PFD_Station';

    // 3 Structural Pylons with Heavy Concrete Footings
    [-12.0, 0, 12.0].forEach((xPos) => {
      const pylonGeo = new THREE.BoxGeometry(0.8, 6.5, 0.8);
      const pylon = new THREE.Mesh(pylonGeo, this.matCatwalkSteel);
      pylon.position.set(xPos, 3.25, 0);
      screenGroup.add(pylon);

      const footGeo = new THREE.BoxGeometry(2.0, 0.6, 2.0);
      const foot = new THREE.Mesh(footGeo, this.matConcretePad);
      foot.position.set(xPos, 0.3, 0);
      screenGroup.add(foot);
    });

    // Elevated Inspection Catwalk with Handrail
    const walkGeo = new THREE.BoxGeometry(32.0, 0.3, 3.0);
    const walk = new THREE.Mesh(walkGeo, this.matCatwalkSteel);
    walk.position.set(0, 5.8, 1.8);
    screenGroup.add(walk);

    const railGeo = new THREE.BoxGeometry(32.0, 1.2, 0.1);
    const rail = new THREE.Mesh(railGeo, this.matYellowSafety);
    rail.position.set(0, 6.5, 3.2);
    screenGroup.add(rail);

    // Ultra High-Resolution 2048x1024 Canvas for Crisp Legibility and Instant 60 FPS Loading
    const canvas = document.createElement('canvas');
    canvas.width = 2048;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d')!;

    // 1. Deep Solid Dark Navy Industrial Background with balanced brightness
    ctx.fillStyle = '#02060c';
    ctx.fillRect(0, 0, 2048, 1024);

    // Crisp Blueprint Technical Grid
    ctx.strokeStyle = 'rgba(14, 165, 233, 0.05)';
    ctx.lineWidth = 1;
    for (let x = 0; x < 2048; x += 80) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 1024);
      ctx.stroke();
    }
    for (let y = 0; y < 1024; y += 80) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(2048, y);
      ctx.stroke();
    }

    // Outer Heavy Amber / Gold Neon Frame
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 12;
    ctx.strokeRect(8, 8, 2032, 1008);

    // Inner Glowing Electric Cyan Sub-Border
    ctx.strokeStyle = '#00c8ef';
    ctx.lineWidth = 4;
    ctx.strokeRect(22, 22, 2004, 980);

    // Master Header Bar
    ctx.fillStyle = 'rgba(10, 16, 28, 0.98)';
    ctx.fillRect(28, 28, 1992, 90);
    ctx.strokeStyle = '#0284c7';
    ctx.lineWidth = 2;
    ctx.strokeRect(28, 28, 1992, 90);

    // Header Title (Arabic)
    ctx.direction = 'rtl';
    ctx.textAlign = 'right';
    ctx.fillStyle = '#fef08a';
    ctx.font = 'bold 37px sans-serif';
    ctx.fillText('⚡ المخطط التشغيلي والتحكم الرقمي الشامل لضاغط غاز التخليق K-301 والتوربين ومبرداته', 1990, 78);

    // Header English Subtitle
    ctx.direction = 'ltr';
    ctx.textAlign = 'left';
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 22px monospace';
    ctx.fillText('SYNTHESIS GAS COMPRESSOR COMPLEX (K-301 / DWG 6112P-100-300-00)', 50, 78);

    // 4 Top Key Performance Indicators (KPI Telemetry Strip)
    const kpis = [
      { label: 'سرعة الدوران (DRIVER SPEED)', val: '10,000 RPM', col: '#10b981', sub: 'NORMAL CONTINUOUS' },
      { label: 'ضغط الطرد النهائي (FINAL HP)', val: '170..239 kg/cm²G', col: '#00c8ef', sub: 'TO SYNLOOP R-401' },
      { label: 'تغذية البخار (HP STEAM)', val: '65 kg/cm² @ 435°C', col: '#f59e0b', sub: 'KT-301 STEAM CHEST' },
      { label: 'تدوير الغاز (SYN RECYCLE)', val: 'ΔP 28.6 kg/cm²G / 205 t/h', col: '#a855f7', sub: 'CIRCULATOR STAGE' }
    ];

    const kpiW = 475;
    const kpiGap = 21;
    const startX = 40;
    kpis.forEach((k, idx) => {
      const kx = startX + idx * (kpiW + kpiGap);
      ctx.fillStyle = 'rgba(10, 18, 30, 0.95)';
      ctx.fillRect(kx, 130, kpiW, 80);
      ctx.strokeStyle = k.col;
      ctx.lineWidth = 2;
      ctx.strokeRect(kx, 130, kpiW, 80);

      ctx.direction = 'ltr';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#94a3b8';
      ctx.font = 'bold 15px sans-serif';
      ctx.fillText(k.label, kx + kpiW / 2, 153);

      ctx.fillStyle = k.col;
      ctx.font = 'bold 24px monospace';
      ctx.fillText(k.val, kx + kpiW / 2, 183);

      ctx.fillStyle = '#cbd5e1';
      ctx.font = 'bold 12px monospace';
      ctx.fillText(k.sub, kx + kpiW / 2, 201);
    });

    // 4 Main Structured Operations Cards (Wide, Ultra-Clean & Clear)
    const sections = [
      {
        title: '1. التوربين البخاري الدافع KT-301',
        sub: 'Steam Turbine Driver (65 kg/cm² @ 435°C / Scania 39 kg/cm²)',
        col: '#f59e0b',
        x: 40,
        w: 475,
        items: [
          { label: 'بخار الضغط العالي:', val: 'توربين يفتر بضغط 65 kg/cm² وحرارة 435°C' },
          { label: 'استخراج البخار Scania:', val: 'يصدر بخاراً بضغط 39 kg/cm²' },
          { label: 'سرعة الدوران التصميمية:', val: '10,000 RPM (حاكم السرعة)' },
          { label: 'القدرة الميكانيكية للتوربين:', val: 'حوالي 18.5 MW لإدارة الأجسام الثلاثة' }
        ]
      },
      {
        title: '2. كابينة الكبس المنخفض والمتوسط (LP & MP)',
        sub: 'Stages 1 & 2 Casings (25.0 -> 44.5 -> 75.0 kg/cm²G)',
        col: '#00c8ef',
        x: 40 + 475 + 21,
        w: 475,
        items: [
          { label: 'سحب غاز التصنيع V-301:', val: '25.0 kg/cm²G / 43°C بعد شيل E-301' },
          { label: 'كبس المرحلة الأولى (LP):', val: '25.0 -> 44.5 kg/cm²G -> E-302' },
          { label: 'مبرد E-302 وفاصل V-302:', val: 'الغاز بالتيوب / ماء بالشيل (44.5 kg/cm²G)' },
          { label: 'كبس المرحلة الثانية (MP):', val: '44.5 -> 75.0 kg/cm²G -> E-303' }
        ]
      },
      {
        title: '3. كابينة الكبس عالي الضغط وعجلة التدوير',
        sub: 'Stages 3 & 4 (75 -> 130 -> 170..239 kg/cm²G) + E-304 & E-315',
        col: '#10b981',
        x: 40 + (475 + 21) * 2,
        w: 475,
        items: [
          { label: 'مبرد E-303 وفاصل V-303:', val: 'الغاز بالتيوب / ماء بالشيل (75.0 kg/cm²G)' },
          { label: 'كبس مرحلة 3 ومبرد E-304:', val: '75.0 -> 130.0 kg/cm²G وتبريد بالتيوب إلى 43°C' },
          { label: 'فاصل V-304 والمرحلة 4:', val: 'سحب مرحلة 4 للكبس إلى 170-239 kg/cm²G -> V-310' },
          { label: 'عجلة تدوير غاز التخليق:', val: 'رفع هيدروليكي 28.6 kg/cm²G لحلقة R-401' }
        ]
      },
      {
        title: '4. منظومة الزيت (Lube & Seal) وموانع الارتجاف',
        sub: 'Lube Oil (P-302), Seal Oil (P-303/P-304) & Anti-Surge',
        col: '#a855f7',
        x: 40 + (475 + 21) * 3,
        w: 475,
        items: [
          { label: 'زيت التزييت Lube Oil:', val: 'مضخات P-302 A,B بضغط 2.8 kg/cm²G للمحامل' },
          { label: 'زيت العزل Seal Oil:', val: 'مضخات P-304 A,B ومضخة P-303 لموانع التسرب' },
          { label: 'مسيطرات مانع الارتجاف:', val: 'مسيطرات FRCA 331 و FRCA 332 و FRCA 333' },
          { label: 'أسباب رحلة الضاغطة K-301 Trip:', val: 'حرارة المراحل، منسوب الفاصلات، عبور أمونيا Recycle' }
        ]
      }
    ];

    sections.forEach((sec) => {
      // Column Box Container
      ctx.fillStyle = 'rgba(10, 20, 35, 0.94)';
      ctx.fillRect(sec.x, 225, sec.w, 710);
      ctx.strokeStyle = sec.col;
      ctx.lineWidth = 3;
      ctx.strokeRect(sec.x, 225, sec.w, 710);

      // Section Header Banner
      ctx.fillStyle = sec.col;
      ctx.fillRect(sec.x, 225, sec.w, 65);

      ctx.direction = 'rtl';
      ctx.textAlign = 'right';
      ctx.fillStyle = '#030712';
      ctx.font = 'bold 22px sans-serif';
      ctx.fillText(sec.title, sec.x + sec.w - 15, 258);

      ctx.direction = 'ltr';
      ctx.textAlign = 'left';
      ctx.font = 'bold 14px monospace';
      ctx.fillStyle = '#0f172a';
      ctx.fillText(sec.sub, sec.x + 15, 280);

      // 4 Clean Item Cards inside Column
      let itemY = 305;
      sec.items.forEach((item, itemIdx) => {
        // Item Box Background
        ctx.fillStyle = 'rgba(15, 28, 48, 0.9)';
        ctx.fillRect(sec.x + 12, itemY, sec.w - 24, 140);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
        ctx.lineWidth = 1;
        ctx.strokeRect(sec.x + 12, itemY, sec.w - 24, 140);

        // Step Number Badge
        ctx.fillStyle = sec.col;
        ctx.beginPath();
        ctx.arc(sec.x + sec.w - 32, itemY + 28, 13, 0, Math.PI * 2);
        ctx.fill();

        ctx.direction = 'ltr';
        ctx.textAlign = 'center';
        ctx.fillStyle = '#030712';
        ctx.font = 'bold 15px sans-serif';
        ctx.fillText(`${itemIdx + 1}`, sec.x + sec.w - 32, itemY + 33);

        // Item Title
        ctx.direction = 'rtl';
        ctx.textAlign = 'right';
        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 19px sans-serif';
        ctx.fillText(item.label, sec.x + sec.w - 55, itemY + 33);

        // Item Value
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 17px sans-serif';
        ctx.fillText(item.val, sec.x + sec.w - 25, itemY + 72);

        // Visual Status Pill
        ctx.fillStyle = 'rgba(16, 185, 129, 0.2)';
        ctx.fillRect(sec.x + 20, itemY + 98, sec.w - 40, 27);
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 1;
        ctx.strokeRect(sec.x + 20, itemY + 98, sec.w - 40, 27);

        ctx.direction = 'rtl';
        ctx.textAlign = 'center';
        ctx.fillStyle = '#34d399';
        ctx.font = 'bold 14px monospace';
        ctx.fillText('● الحالة: نشط ومستقر ضمن الحدود الهندسية المصممة', sec.x + sec.w / 2, itemY + 117);

        itemY += 158;
      });
    });

    // Bottom Navigation & Click Instructions Strip
    ctx.fillStyle = 'rgba(255, 235, 59, 0.22)';
    ctx.fillRect(40, 938, 1968, 65);
    ctx.strokeStyle = '#ffeb3b';
    ctx.lineWidth = 3;
    ctx.strokeRect(40, 938, 1968, 65);

    ctx.direction = 'rtl';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px sans-serif';
    ctx.fillText('⚡ انقر بالفأرة أو المس الشاشة هنا لفتح بنك الـ 100 سؤال ودليل التشغيل C-13..C-14 والمخطط الرقمي لضاغط K-301 والتوربين', 1024, 978);

    const tex = new THREE.CanvasTexture(canvas);
    tex.generateMipmaps = false;
    tex.minFilter = THREE.LinearFilter;
    tex.magFilter = THREE.LinearFilter;

    const monGeo = new THREE.PlaneGeometry(30.0, 14.0);
    const monMat = new THREE.MeshBasicMaterial({
      map: tex,
      toneMapped: true,
      side: THREE.FrontSide,
      depthWrite: true
    });
    const mon = new THREE.Mesh(monGeo, monMat);
    mon.position.set(0, 12.0, 0.35);
    screenGroup.add(mon);

    const frameGeo = new THREE.BoxGeometry(30.8, 14.8, 0.2);
    const frameMesh = new THREE.Mesh(frameGeo, this.matCatwalkSteel);
    frameMesh.position.set(0, 12.0, 0.0);
    screenGroup.add(frameMesh);

    this.registerInteractive(screenGroup, 'unit300_master_pfd_board');
    this.group.add(screenGroup);
  }

  private renderCanvasWrappedText(
    ctx: CanvasRenderingContext2D,
    text: string,
    x: number,
    y: number,
    maxWidth: number,
    lineHeight: number,
    maxLines: number = 4
  ) {
    const words = text.split(' ');
    let line = '';
    let lineCount = 0;

    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = ctx.measureText(testLine);
      const testWidth = metrics.width;
      if (testWidth > maxWidth && n > 0) {
        ctx.fillText(line.trim(), x, y);
        line = words[n] + ' ';
        y += lineHeight;
        lineCount++;
        if (lineCount >= maxLines - 1 && n < words.length - 1) {
          const remaining = words.slice(n).join(' ');
          let fit = remaining;
          while (ctx.measureText(fit + '...').width > maxWidth && fit.length > 0) {
            fit = fit.substring(0, fit.length - 1);
          }
          ctx.fillText(fit.trim() + '...', x, y);
          return;
        }
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line.trim(), x, y);
  }

  private addNozzleWithFlange(group: THREE.Group, pos: THREE.Vector3, dir: THREE.Vector3, d: number, l: number) {
    const nozzleGroup = new THREE.Group();
    nozzleGroup.position.copy(pos);

    const pipeGeo = new THREE.CylinderGeometry(d * 0.5, d * 0.5, l, 16);
    const pipe = new THREE.Mesh(pipeGeo, this.matCarbonSteel);
    pipe.position.set(0, l * 0.5, 0);
    nozzleGroup.add(pipe);

    const flangeGeo = new THREE.CylinderGeometry(d * 0.85, d * 0.85, 0.45, 16);
    const flange = new THREE.Mesh(flangeGeo, this.matFlange);
    flange.position.set(0, l, 0);
    nozzleGroup.add(flange);

    const up = new THREE.Vector3(0, 1, 0);
    if (Math.abs(dir.dot(up)) < 0.9999) {
      nozzleGroup.quaternion.setFromUnitVectors(up, dir.normalize());
    } else if (dir.y < 0) {
      nozzleGroup.rotation.x = Math.PI;
    }

    group.add(nozzleGroup);
  }

  private registerInteractive(obj: THREE.Object3D, equipmentId: string) {
    const info = MASTER_EQUIPMENT_DATA.find((e) => e.id.toLowerCase() === equipmentId.toLowerCase()) || {
      id: equipmentId,
      tag: equipmentId.toUpperCase(),
      name: `${equipmentId.toUpperCase()} Compressor Equipment`,
      arabicName: `معدة ضاغط غاز التصنيع ${equipmentId.toUpperCase()}`,
      type: 'compressor',
      section: 'Syngas Compression (K-301 Complex)',
      sectionNumber: 3,
      rowNumber: 5,
      position: obj.position.clone(),
      inletStream: 'Syngas Feed',
      outletStream: 'High Pressure Syngas Stream',
      operatingTemp: '40°C - 145°C',
      operatingPress: '25.0 - 170.0 kg/cm²G',
      catalystOrInternals: 'Multi-stage Centrifugal Impellers & Dry Gas Seals',
      description: 'Syngas Compressor Train Component with Anti-Surge & Vibration Protection.'
    };

    obj.userData = {
      equipmentId: equipmentId,
      equipmentInfo: info,
      isClickable: true
    };
    this.interactiveMeshes.push(obj);

    // Tag child meshes with userData so raycaster hits detect equipment data,
    // but keep interactiveMeshes array lean and fast
    obj.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        child.userData = {
          equipmentId: equipmentId,
          equipmentInfo: info,
          isClickable: true
        };
      }
    });
  }

  // Animation Update Tick (Rotating Rotor Shafts)
  public update(delta: number) {
    // 1. Rotate compressor & turbine rotor shaft at 10,000 RPM equivalent
    this.rotatingShafts.forEach((shaft) => {
      shaft.rotation.x += delta * 24.0;
    });
  }

  // Toggle Thermal Insulation Cladding Mode
  public toggleCladdingMode() {
    this.isCladdingTranslucent = !this.isCladdingTranslucent;
    this.claddingMeshes.forEach((mesh) => {
      if (this.isCladdingTranslucent) {
        mesh.material = new THREE.MeshStandardMaterial({
          color: 0xe2e8f0,
          roughness: 0.15,
          metalness: 0.9,
          transparent: true,
          opacity: 0.35,
          depthWrite: false
        });
      } else {
        mesh.material = this.matAluminumCladding;
      }
    });
  }
}

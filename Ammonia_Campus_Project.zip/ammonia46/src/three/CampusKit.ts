import * as THREE from 'three';
import { MASTER_EQUIPMENT_DATA } from './PlantDiagramData';
import { EQUIPMENT_REFORM_100 } from '../diagram2d/data_reform_100';
import { EQUIPMENT_CO2_200 } from '../diagram2d/data_co2_200';
import { EQUIPMENT_COMP_300 } from '../diagram2d/data_comp_300';
import { EQUIPMENT_K301 } from '../diagram2d/data_k301';
import { EQUIPMENT_SYNTH_400 } from '../diagram2d/data_synth_400';
import { EQUIPMENT_UREA_500 } from '../diagram2d/data_urea_500';
import { EQUIPMENT_STEAM_BFW } from '../diagram2d/data_steam_bfw';
import { EQUIPMENT_STEAM_HEADER } from '../diagram2d/data_steam_header';

/**
 * CampusKit — أدوات بناء "حرم المعمل" الموسّع:
 *  - قياس مساحة أي قسم ثلاثي الأبعاد تلقائياً (Footprint) لوضعه بدقة على المخطط العام
 *  - إخفاء بلاطات الأرضية الداخلية للأقسام حتى لا تتعارض مع الشوارع الجديدة
 *  - لافتات أسماء المعدات (Tag + الاسم العربي) بجانب كل معدة
 *  - مجاري مياه الصرف الصناعي (Waste Water) بجانب كل قسم
 *  - شوارع عريضة مع أرصفة وخطوط
 */

// ---------------------------------------------------------------------------
// 1) NAME INDEX — اسم كل معدة (من البيانات الرئيسية + مخططات 2D)
// ---------------------------------------------------------------------------
export interface NameEntry { en: string; ar: string; }

const normTag = (t: string) => t.toUpperCase().replace(/\s+/g, '').replace(/[_]/g, '');

let nameIndex: Map<string, NameEntry> | null = null;

function buildNameIndex(): Map<string, NameEntry> {
  const idx = new Map<string, NameEntry>();
  const put = (tag: string, en: string, ar: string) => {
    if (!tag) return;
    const k = normTag(tag);
    const prev = idx.get(k);
    if (!prev || (!prev.ar && ar)) idx.set(k, { en: en || (prev ? prev.en : ''), ar: ar || (prev ? prev.ar : '') });
  };
  const dicts: Record<string, any>[] = [
    EQUIPMENT_COMP_300, EQUIPMENT_K301, EQUIPMENT_SYNTH_400, EQUIPMENT_UREA_500,
    EQUIPMENT_REFORM_100, EQUIPMENT_CO2_200, EQUIPMENT_STEAM_BFW, EQUIPMENT_STEAM_HEADER,
  ];
  dicts.forEach((d) => {
    if (!d) return;
    Object.keys(d).forEach((key) => {
      const e = d[key];
      if (!e) return;
      put(e.tag || key, e.name || '', e.nameAr || '');
      put(key, e.name || '', e.nameAr || '');
    });
  });
  // MASTER data has priority (written last so it overrides empty arabic only; keep first non-empty)
  MASTER_EQUIPMENT_DATA.forEach((e) => put(e.tag, e.name, e.arabicName || ''));
  return idx;
}

export function lookupName(tag: string): NameEntry | undefined {
  if (!nameIndex) nameIndex = buildNameIndex();
  const k = normTag(tag);
  let hit = nameIndex.get(k);
  if (hit) return hit;
  // try without trailing letter (P-201A -> P-201) or with A/B
  hit = nameIndex.get(k.replace(/[A-Z]{1,2}$/, ''));
  if (hit) return hit;
  for (const suffix of ['A', 'AB', 'A/B']) {
    hit = nameIndex.get(k + suffix);
    if (hit) return hit;
  }
  return undefined;
}

// ---------------------------------------------------------------------------
// 2) MEASURING / TRIMMING
// ---------------------------------------------------------------------------
function isEffectivelyVisible(obj: THREE.Object3D, root: THREE.Object3D): boolean {
  let o: THREE.Object3D | null = obj;
  while (o) {
    if (!o.visible) return false;
    if (o === root) break;
    o = o.parent;
  }
  return true;
}

function meshWorldBox(m: THREE.Mesh, out: THREE.Box3): THREE.Box3 {
  if (!m.geometry.boundingBox) m.geometry.computeBoundingBox();
  out.copy(m.geometry.boundingBox!).applyMatrix4(m.matrixWorld);
  return out;
}

/** يخفي بلاطات/ألواح الأرضية الكبيرة داخل القسم (تخرج عن حدود المعدات نفسها). */
export function trimGroundSlabs(root: THREE.Object3D) {
  root.updateMatrixWorld(true);
  const core = new THREE.Box3();
  const slabs: { mesh: THREE.Mesh; size: THREE.Vector3 }[] = [];
  const tmp = new THREE.Box3();
  const size = new THREE.Vector3();

  root.traverse((o) => {
    const t = (o as any).type as string;
    if (t === 'GridHelper') { o.visible = false; return; }
    const m = o as THREE.Mesh;
    if (!m.isMesh || !m.geometry) return;
    meshWorldBox(m, tmp);
    if (tmp.isEmpty()) return;
    tmp.getSize(size);
    const flat = size.y < 0.9 && size.x > 6 && size.z > 6;
    if (flat) {
      slabs.push({ mesh: m, size: size.clone() });
    } else {
      core.union(tmp);
    }
  });
  if (core.isEmpty()) return;
  const cs = core.getSize(new THREE.Vector3());
  slabs.forEach(({ mesh, size: s }) => {
    if (s.x > cs.x * 1.04 || s.z > cs.z * 1.04) mesh.visible = false;
  });
}

/** مساحة القسم الفعلية (المرئية فقط) في الإحداثيات العالمية. */
export function measureVisible(root: THREE.Object3D): THREE.Box3 {
  root.updateMatrixWorld(true);
  const box = new THREE.Box3();
  const tmp = new THREE.Box3();
  root.traverse((o) => {
    const m = o as THREE.Mesh;
    if (!m.isMesh || !m.geometry) return;
    if (!isEffectivelyVisible(m, root)) return;
    meshWorldBox(m, tmp);
    if (!tmp.isEmpty()) box.union(tmp);
  });
  return box;
}

// ---------------------------------------------------------------------------
// 3) LABEL SPRITES (اسم كل معدة)
// ---------------------------------------------------------------------------
const labelTexCache = new Map<string, THREE.CanvasTexture>();

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function fitText(ctx: CanvasRenderingContext2D, text: string, maxW: number, startPx: number, font: (px: number) => string): number {
  let px = startPx;
  ctx.font = font(px);
  while (ctx.measureText(text).width > maxW && px > 14) {
    px -= 2;
    ctx.font = font(px);
  }
  return px;
}

function labelTexture(tag: string, sub: string, accent: string): THREE.CanvasTexture {
  const key = tag + '|' + sub + '|' + accent;
  const cached = labelTexCache.get(key);
  if (cached) return cached;
  const W = 512, H = 168;
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = 'rgba(8,16,28,0.88)';
  roundRect(ctx, 4, 4, W - 8, H - 8, 20);
  ctx.fill();
  ctx.strokeStyle = accent;
  ctx.lineWidth = 5;
  roundRect(ctx, 4, 4, W - 8, H - 8, 20);
  ctx.stroke();
  ctx.fillStyle = accent;
  ctx.textAlign = 'center';
  fitText(ctx, tag, W - 40, 64, (px) => `bold ${px}px monospace`);
  ctx.fillText(tag, W / 2, 70);
  if (sub) {
    ctx.fillStyle = '#ffffff';
    fitText(ctx, sub, W - 40, 38, (px) => `bold ${px}px "Segoe UI", Tahoma, sans-serif`);
    ctx.fillText(sub, W / 2, 130);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.anisotropy = 4;
  labelTexCache.set(key, tex);
  return tex;
}

export interface CampusLabel { sprite: THREE.Sprite; baseScale: THREE.Vector2; }

export function makeLabelSprite(tag: string, sub: string, accent = '#38bdf8', worldHeight = 2.3): THREE.Sprite {
  const tex = labelTexture(tag, sub, accent);
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, depthTest: true, fog: false });
  const sp = new THREE.Sprite(mat);
  sp.scale.set(worldHeight * (512 / 168), worldHeight, 1);
  sp.renderOrder = 20;
  sp.userData.isCampusLabel = true;
  sp.userData.tag = tag;
  return sp;
}

const TAG_RE = /^([A-Z]{1,5}-\d{1,4}(?:[A-Z]{1,2})?(?:\s?[A-Z](?:\/[A-Z])?)?)(?:[_\s](.*))?$/;
const TAG_RE_NODASH = /^([A-Z])(\d{3,4}[A-Z]?)(?:_(.*))?$/;

/** أسماء عربية للمعدات غير الموجودة في جداول البيانات (برج التبريد ... إلخ). */
function extraArabicName(tag: string): string {
  const k = tag.toUpperCase();
  if (k.startsWith('FAN-')) return 'مروحة سحب هواء — برج التبريد';
  if (k.startsWith('BASIN')) return 'حوض الماء البارد';
  if (k.startsWith('CT-')) return 'خلية برج التبريد';
  if (/^P-71\d/.test(k)) return 'مضخة ماء التبريد الدوارة';
  if (k.startsWith('E-711')) return 'المكثف السطحي E-711';
  return '';
}

/**
 * يمرّ على كل المجموعات المسمّاة في وحدة 3D (E-201, T-201, P-201A_Pump …)
 * ويضع لافتة اسم بجانب كل معدة (جهة الشارع الرئيسي).
 */
export function autoLabelModule(
  moduleRoot: THREE.Object3D,
  labelsParent: THREE.Object3D,
  accent: string,
  labelStore: THREE.Sprite[],
  opts: { avenueX?: number; minSize?: number; labelHeight?: number } = {}
) {
  moduleRoot.updateMatrixWorld(true);
  const avenueX = opts.avenueX ?? 0;
  const minSize = opts.minSize ?? 1.2;
  const candidates = new Map<string, { obj: THREE.Object3D; box: THREE.Box3; vol: number; tag: string; rest: string }>();

  moduleRoot.traverse((o) => {
    if (o === moduleRoot || !o.name || (o as any).isMesh || (o as any).isSprite) return;
    let m = TAG_RE.exec(o.name);
    if (!m) {
      const m2 = TAG_RE_NODASH.exec(o.name);
      if (!m2) return;
      m = [o.name, `${m2[1]}-${m2[2]}`, m2[3]] as any;
    }
    if (!isEffectivelyVisible(o, moduleRoot)) return;
    const box = new THREE.Box3().setFromObject(o);
    if (box.isEmpty()) return;
    const s = box.getSize(new THREE.Vector3());
    if (Math.max(s.x, s.y, s.z) < minSize) return;
    if (s.x > 120 || s.z > 120) return; // container groups
    const vol = s.x * s.y * s.z;
    const prev = candidates.get(o.name);
    if (!prev || vol > prev.vol) candidates.set(o.name, { obj: o, box, vol, tag: String(m[1]).trim(), rest: String(m[2] || '').replace(/_/g, ' ').trim() });
  });

  const occupied = new Map<string, number>();
  const sorted = Array.from(candidates.values()).sort((a, b) => b.vol - a.vol);
  sorted.forEach((c) => {
    const size = c.box.getSize(new THREE.Vector3());
    const center = c.box.getCenter(new THREE.Vector3());
    const dir = center.x > avenueX ? -1 : 1; // نحو الشارع الرئيسي
    const lx = center.x + dir * (size.x / 2 + 1.6);
    let ly = size.y > 9 ? 6.8 : Math.min(c.box.max.y + 1.5, 7.5);
    ly = Math.max(ly, 2.6);
    const lz = center.z;
    // anti-overlap: shift upward in 2.4m steps
    let placed = false;
    for (let i = 0; i < 4 && !placed; i++) {
      const key = `${Math.round(lx / 4)}_${Math.round(lz / 4)}_${Math.round((ly + i * 2.6) / 2.6)}`;
      if (!occupied.has(key)) {
        occupied.set(key, 1);
        ly = ly + i * 2.6;
        placed = true;
      }
    }
    if (!placed) return;
    const info = lookupName(c.tag);
    const ar = info?.ar || extraArabicName(c.tag);
    const sub = c.rest ? (ar ? `${c.rest} — ${ar}` : c.rest) : (ar || info?.en || '');
    const sp = makeLabelSprite(c.tag, sub.length > 46 ? sub.slice(0, 44) + '…' : sub, accent, opts.labelHeight ?? 2.3);
    sp.position.set(lx, ly, lz);
    labelsParent.add(sp);
    labelStore.push(sp);
  });
}

// ---------------------------------------------------------------------------
// 4) ROADS, GROUND, DRAINS
// ---------------------------------------------------------------------------
export function tiledMaterial(base: THREE.MeshStandardMaterial, sx: number, sz: number, tile = 10): THREE.MeshStandardMaterial {
  const m = base.clone();
  if (base.map) {
    const t = base.map.clone();
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(Math.max(1, sx / tile), Math.max(1, sz / tile));
    t.needsUpdate = true;
    m.map = t;
  }
  return m;
}

export interface CampusMats {
  asphalt: THREE.MeshStandardMaterial;
  sidewalk: THREE.MeshStandardMaterial;
  curbYellow: THREE.MeshStandardMaterial;
  concretePlinth: THREE.MeshStandardMaterial;
  carbonSteel: THREE.MeshStandardMaterial;
  alloySteel: THREE.MeshStandardMaterial;
  safetyYellow: THREE.MeshStandardMaterial;
  safetyBlue: THREE.MeshStandardMaterial;
  gratingDeck: THREE.MeshStandardMaterial;
  glassBuilding: THREE.MeshStandardMaterial;
  hotDischarge: THREE.MeshStandardMaterial;
  [k: string]: any;
}

/** شارع مستطيل (sx على محور X، sz على محور Z) مع أرصفة وخطوط. */
export function buildStreet(
  parent: THREE.Object3D, mats: CampusMats,
  cx: number, cz: number, sx: number, sz: number,
  opts: { dashed?: boolean; edgeLines?: boolean } = {}
) {
  const road = new THREE.Mesh(new THREE.PlaneGeometry(sx, sz), tiledMaterial(mats.asphalt, sx, sz, 12));
  road.rotation.x = -Math.PI / 2;
  road.position.set(cx, 0.02, cz);
  road.receiveShadow = true;
  parent.add(road);

  const lineMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
  const whiteMat = new THREE.MeshBasicMaterial({ color: 0xf1f5f9 });
  const alongZ = sz >= sx;
  const len = alongZ ? sz : sx;
  const wid = alongZ ? sx : sz;

  if (opts.dashed !== false) {
    const n = Math.floor(len / 9);
    const dashGeo = alongZ ? new THREE.PlaneGeometry(0.35, 4.6) : new THREE.PlaneGeometry(4.6, 0.35);
    for (let i = 0; i < n; i++) {
      const d = new THREE.Mesh(dashGeo, lineMat);
      d.rotation.x = -Math.PI / 2;
      const off = -len / 2 + 4.5 + i * 9;
      d.position.set(alongZ ? cx : cx + off, 0.035, alongZ ? cz + off : cz);
      parent.add(d);
    }
  }
  if (opts.edgeLines !== false) {
    [-1, 1].forEach((sgn) => {
      const g = alongZ ? new THREE.PlaneGeometry(0.22, len) : new THREE.PlaneGeometry(len, 0.22);
      const l = new THREE.Mesh(g, whiteMat);
      l.rotation.x = -Math.PI / 2;
      const o = sgn * (wid / 2 - 0.7);
      l.position.set(alongZ ? cx + o : cx, 0.035, alongZ ? cz : cz + o);
      parent.add(l);
    });
  }
}

/** رصيف/كيرب مرتفع. */
export function buildCurb(parent: THREE.Object3D, mats: CampusMats, cx: number, cz: number, sx: number, sz: number) {
  const b = new THREE.Mesh(new THREE.BoxGeometry(sx, 0.26, sz), mats.sidewalk);
  b.position.set(cx, 0.13, cz);
  parent.add(b);
}

// --- Waste water drain -------------------------------------------------------
let drainWaterTex: THREE.CanvasTexture | null = null;
const drainAnimTextures: THREE.Texture[] = [];

function getDrainWaterTexture(): THREE.CanvasTexture {
  if (drainWaterTex) return drainWaterTex;
  const c = document.createElement('canvas');
  c.width = 128; c.height = 128;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#244a4f';
  ctx.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 40; i++) {
    ctx.strokeStyle = `rgba(150,210,200,${0.08 + Math.random() * 0.14})`;
    ctx.lineWidth = 1 + Math.random() * 2;
    const y = Math.random() * 128;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(32, y + 6, 96, y - 6, 128, y);
    ctx.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  drainWaterTex = t;
  return t;
}

export function animateDrains(dt: number) {
  drainAnimTextures.forEach((t) => { t.offset.y -= dt * 0.12; });
}

/**
 * مجرى مياه الصرف الصناعي (Waste Water) — قناة خرسانية مفتوحة مع ماء جارٍ وأغطية تفتيش وسهم اتجاه.
 * (x0,z0) → (x1,z1) ويكون إما على محور Z أو على محور X.
 */
export function buildWasteWaterDrain(
  parent: THREE.Object3D, mats: CampusMats,
  x0: number, z0: number, x1: number, z1: number,
  width: number, labelStore: THREE.Sprite[], title: string, titleAr: string
) {
  const alongZ = Math.abs(z1 - z0) >= Math.abs(x1 - x0);
  const len = alongZ ? Math.abs(z1 - z0) : Math.abs(x1 - x0);
  const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
  const g = new THREE.Group();
  g.position.set(cx, 0, cz);
  if (!alongZ) g.rotation.y = Math.PI / 2;

  const rimMat = mats.concretePlinth;
  // two concrete walls
  [-1, 1].forEach((s) => {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.42, len), rimMat);
    wall.position.set(s * (width / 2 + 0.22), 0.21, 0);
    g.add(wall);
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.47, 0.04, len), mats.curbYellow);
    stripe.position.set(s * (width / 2 + 0.22), 0.43, 0);
    g.add(stripe);
  });
  // channel bed (dark) + flowing water
  const bed = new THREE.Mesh(new THREE.BoxGeometry(width, 0.1, len), new THREE.MeshStandardMaterial({ color: 0x10171c, roughness: 0.9 }));
  bed.position.set(0, 0.05, 0);
  g.add(bed);

  const wTex = getDrainWaterTexture().clone();
  wTex.wrapS = wTex.wrapT = THREE.RepeatWrapping;
  wTex.repeat.set(Math.max(1, width / 3), Math.max(1, len / 6));
  wTex.needsUpdate = true;
  drainAnimTextures.push(wTex);
  const water = new THREE.Mesh(
    new THREE.PlaneGeometry(width * 0.92, len),
    new THREE.MeshStandardMaterial({ map: wTex, color: 0x6fa8a0, roughness: 0.15, metalness: 0.3, emissive: 0x0b2a2c, emissiveIntensity: 0.6 })
  );
  water.rotation.x = -Math.PI / 2;
  water.position.set(0, 0.2, 0);
  g.add(water);

  // inspection grates every ~14 m
  const grateMat = new THREE.MeshStandardMaterial({ color: 0x59606b, roughness: 0.5, metalness: 0.8 });
  const nG = Math.max(1, Math.floor(len / 14));
  for (let i = 0; i < nG; i++) {
    const gz = -len / 2 + (i + 0.5) * (len / nG);
    const grate = new THREE.Mesh(new THREE.BoxGeometry(width + 0.6, 0.12, 1.6), grateMat);
    grate.position.set(0, 0.44, gz);
    g.add(grate);
    for (let b = -2; b <= 2; b++) {
      const bar = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.06, 1.55), mats.carbonSteel);
      bar.position.set(b * (width / 5), 0.52, gz);
      g.add(bar);
    }
  }
  // flow arrows (painted)
  const arrowMat = new THREE.MeshBasicMaterial({ color: 0x7dd3fc });
  const nA = Math.max(1, Math.floor(len / 30));
  for (let i = 0; i < nA; i++) {
    const az = -len / 2 + (i + 0.5) * (len / nA) + 6;
    const sh = new THREE.Shape();
    sh.moveTo(0, 1.4); sh.lineTo(0.7, 0); sh.lineTo(0.25, 0); sh.lineTo(0.25, -1.3); sh.lineTo(-0.25, -1.3); sh.lineTo(-0.25, 0); sh.lineTo(-0.7, 0); sh.closePath();
    const arrow = new THREE.Mesh(new THREE.ShapeGeometry(sh), arrowMat);
    arrow.rotation.x = -Math.PI / 2;
    arrow.position.set(0, 0.22, az);
    g.add(arrow);
  }
  parent.add(g);

  // sign(s)
  const nSign = Math.max(1, Math.floor(len / 70));
  for (let i = 0; i < nSign; i++) {
    const t = (i + 0.5) / nSign;
    const px = alongZ ? cx : x0 + (x1 - x0) * t;
    const pz = alongZ ? z0 + (z1 - z0) * t : cz;
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.2, 8), mats.carbonSteel);
    post.position.set(px, 1.1, pz);
    parent.add(post);
    const sp = makeLabelSprite('WASTE WATER', `مجرى مياه الصرف — ${titleAr}`, '#2dd4bf', 1.5);
    sp.position.set(px, 2.9, pz);
    parent.add(sp);
    labelStore.push(sp);
  }
  void title;
}

// ---------------------------------------------------------------------------
// 5) MISC HELPERS
// ---------------------------------------------------------------------------
export function canvasPlane(
  w: number, h: number, pxW: number, pxH: number,
  draw: (ctx: CanvasRenderingContext2D, W: number, H: number) => void,
  basic = true
): THREE.Mesh {
  const c = document.createElement('canvas');
  c.width = pxW; c.height = pxH;
  const ctx = c.getContext('2d')!;
  draw(ctx, pxW, pxH);
  const tex = new THREE.CanvasTexture(c);
  tex.anisotropy = 4;
  const mat = basic ? new THREE.MeshBasicMaterial({ map: tex, toneMapped: false }) : new THREE.MeshStandardMaterial({ map: tex });
  return new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
}

/** يلف نصاً عربياً/إنجليزياً داخل عرض محدد ويرسمه. */
export function drawWrapped(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, maxW: number, lineH: number, maxLines = 6): number {
  const words = text.split(/\s+/);
  let line = '';
  let lines = 0;
  for (let i = 0; i < words.length; i++) {
    const test = line ? line + ' ' + words[i] : words[i];
    if (ctx.measureText(test).width > maxW && line) {
      ctx.fillText(line, x, y);
      y += lineH;
      line = words[i];
      lines++;
      if (lines >= maxLines - 1) {
        const rest = words.slice(i).join(' ');
        ctx.fillText(rest.length > 60 ? rest.slice(0, 58) + '…' : rest, x, y);
        return y + lineH;
      }
    } else {
      line = test;
    }
  }
  if (line) { ctx.fillText(line, x, y); y += lineH; }
  return y;
}

/** أنبوب مستقيم بين نقطتين. */
export function pipeBetween(parent: THREE.Object3D, a: THREE.Vector3, b: THREE.Vector3, r: number, mat: THREE.Material) {
  const dir = new THREE.Vector3().subVectors(b, a);
  const len = dir.length();
  if (len < 0.01) return;
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 10), mat);
  m.position.copy(a).addScaledVector(dir, 0.5);
  m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
  parent.add(m);
  const j = new THREE.Mesh(new THREE.SphereGeometry(r * 1.02, 8, 6), mat);
  j.position.copy(b);
  parent.add(j);
}

export function pipePath(parent: THREE.Object3D, pts: THREE.Vector3[], r: number, mat: THREE.Material) {
  for (let i = 0; i < pts.length - 1; i++) pipeBetween(parent, pts[i], pts[i + 1], r, mat);
}

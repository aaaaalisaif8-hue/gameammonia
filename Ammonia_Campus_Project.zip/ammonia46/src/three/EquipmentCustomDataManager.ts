/**
 * EquipmentCustomDataManager.ts
 * مدير ومحرر البيانات والمعادلات الكيميائية والضغوط ودرجات الحرارة لكافة معدات المصنع بالترتيب
 * يتيح إضافة وتعديل وحفظ وحذف المعادلات والبيانات التشغيلية لكل قسم من أقسام المصنع.
 */

import { EquipmentInfo, MASTER_EQUIPMENT_DATA } from './PlantDiagramData';
import { escapeHtml } from '../securityUtils';

export interface CustomEquipmentRecord {
  id: string;
  tag: string;
  chemicalReaction: string;
  operatingTemp: string;
  operatingPress: string;
  customNotes: string;
  updatedAt: string;
}

export interface SectionEquipmentGroup {
  sectionNumber: number;
  sectionId: string;
  nameAr: string;
  nameEn: string;
  equipmentList: EquipmentInfo[];
}

const STORAGE_KEY = 'nh3_custom_equipment_records_v1';

export class EquipmentCustomDataManager {
  private static instance: EquipmentCustomDataManager | null = null;
  private customRecords: Record<string, CustomEquipmentRecord> = {};
  private modalEl: HTMLElement | null = null;
  private currentInspectedEquipment: EquipmentInfo | null = null;
  private currentSectionIndex: number = 0;
  private currentEquipmentIndexInSection: number = 0;
  private onDataChangedCallbacks: ((eqId: string) => void)[] = [];

  public static getInstance(): EquipmentCustomDataManager {
    if (!EquipmentCustomDataManager.instance) {
      EquipmentCustomDataManager.instance = new EquipmentCustomDataManager();
    }
    return EquipmentCustomDataManager.instance;
  }

  private constructor() {
    this.loadFromStorage();
    if (typeof document !== 'undefined') {
      if (document.body) {
        this.initDOM();
      } else {
        document.addEventListener('DOMContentLoaded', () => this.initDOM());
      }
    }
  }

  private loadFromStorage() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        this.customRecords = JSON.parse(saved) || {};
      }
    } catch (e) {
      this.customRecords = {};
    }
  }

  private saveToStorage() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.customRecords));
    } catch (e) {
      console.warn('Failed to save custom equipment record to storage', e);
    }
  }

  public subscribe(callback: (eqId: string) => void) {
    this.onDataChangedCallbacks.push(callback);
  }

  private notify(eqId: string) {
    this.onDataChangedCallbacks.forEach((cb) => cb(eqId));
  }

  public getCustomRecord(idOrTag: string): CustomEquipmentRecord | null {
    const key = idOrTag.toLowerCase();
    return this.customRecords[key] || null;
  }

  public hasCustomRecord(idOrTag: string): boolean {
    const key = idOrTag.toLowerCase();
    return !!this.customRecords[key];
  }

  public saveRecord(record: CustomEquipmentRecord) {
    const key = record.id.toLowerCase();
    record.updatedAt = new Date().toISOString();
    this.customRecords[key] = record;
    // Also store under tag as alias
    this.customRecords[record.tag.toLowerCase()] = record;
    this.saveToStorage();
    this.notify(record.id);
  }

  public deleteRecord(idOrTag: string) {
    const key = idOrTag.toLowerCase();
    const rec = this.customRecords[key];
    if (rec) {
      delete this.customRecords[rec.id.toLowerCase()];
      delete this.customRecords[rec.tag.toLowerCase()];
      this.saveToStorage();
      this.notify(rec.id);
    }
  }

  public getEffectiveData(eq: EquipmentInfo): {
    operatingTemp: string;
    operatingPress: string;
    chemicalReaction: string;
    description: string;
    isCustom: boolean;
  } {
    const custom = this.getCustomRecord(eq.id) || this.getCustomRecord(eq.tag);
    if (custom) {
      return {
        operatingTemp: custom.operatingTemp || eq.operatingTemp,
        operatingPress: custom.operatingPress || eq.operatingPress,
        chemicalReaction: custom.chemicalReaction || eq.chemicalReaction || '',
        description: custom.customNotes ? `${custom.customNotes}\n\n[الوصف الأساسي]: ${eq.description}` : eq.description,
        isCustom: true
      };
    }
    return {
      operatingTemp: eq.operatingTemp,
      operatingPress: eq.operatingPress,
      chemicalReaction: eq.chemicalReaction || '',
      description: eq.description,
      isCustom: false
    };
  }

  // Get all plant equipment ordered cleanly by section
  public getSectionsInOrder(): SectionEquipmentGroup[] {
    const sectionMap: Record<number, SectionEquipmentGroup> = {
      1: {
        sectionNumber: 1,
        sectionId: 'sec_desulf',
        nameAr: 'القسم الأول: قسم التغذية وإزالة الكبريت (Natural Gas Feed & Desulfurization)',
        nameEn: 'Natural Gas Feed & Desulfurization Unit (Unit 100)',
        equipmentList: []
      },
      2: {
        sectionNumber: 2,
        sectionId: 'sec_reformer',
        nameAr: 'القسم الثاني: فرن الإصلاح الأولي والثانوي وتوليد البخار (Reforming & WHB)',
        nameEn: 'Primary & Secondary Reforming Unit (Unit 100)',
        equipmentList: []
      },
      3: {
        sectionNumber: 3,
        sectionId: 'sec_shift',
        nameAr: 'القسم الثالث: مفاعلات التحويل بدرجات الحرارة العالية والواطئة (Shift HTS/LTS)',
        nameEn: 'Shift Conversion Unit (Unit 100)',
        equipmentList: []
      },
      4: {
        sectionNumber: 4,
        sectionId: 'sec_co2',
        nameAr: 'القسم الرابع: منظومة إزالة واستخلاص CO₂ كاتاكارب (Catacarb Unit 200)',
        nameEn: 'CO2 Removal & Catacarb Absorption Unit (Unit 200)',
        equipmentList: []
      },
      5: {
        sectionNumber: 5,
        sectionId: 'sec_methanation',
        nameAr: 'القسم الخامس: مفاعل الميثانايتر للتنقية والضواغط (Methanation & Compression)',
        nameEn: 'Methanation & Compression Unit (Unit 100 & 300)',
        equipmentList: []
      },
      6: {
        sectionNumber: 6,
        sectionId: 'sec_synloop',
        nameAr: 'القسم السادس: حلقة تخليق الأمونيا والمفاعل R-401 (Ammonia Synthesis Loop)',
        nameEn: 'Ammonia Synthesis Loop & Converter R-401 (Unit 400)',
        equipmentList: []
      },
      7: {
        sectionNumber: 7,
        sectionId: 'sec_storage',
        nameAr: 'القسم السابع: خزانات الأمونيا والتبريد ومحطات الشحن (Storage & Refrigeration)',
        nameEn: 'Refrigeration, Chilling & Storage (E-412, V-408, F-401)',
        equipmentList: []
      },
      8: {
        sectionNumber: 8,
        sectionId: 'sec_cooling_tower',
        nameAr: 'القسم الثامن: منظومة برج التبريد الصناعي والمضخات ومكثف E711 (Cooling Tower & Pumps)',
        nameEn: 'Industrial Cooling Tower, 10 CW Pumps P711A-J & Condenser E711',
        equipmentList: []
      }
    };

    MASTER_EQUIPMENT_DATA.forEach((eq) => {
      const secNum = eq.sectionNumber || 1;
      if (sectionMap[secNum]) {
        sectionMap[secNum].equipmentList.push(eq);
      } else {
        sectionMap[1].equipmentList.push(eq);
      }
    });

    // Add Cooling Tower equipment if not in list
    const ctEquipment: EquipmentInfo[] = [
      {
        id: 'cooling_tower',
        tag: 'Cooling Tower',
        name: 'Industrial Induced Draft Cooling Tower',
        arabicName: 'برج التبريد الصناعي 9 خلايا',
        type: 'tower',
        section: 'Cooling Tower Circuit',
        sectionNumber: 8,
        rowNumber: 1,
        position: MASTER_EQUIPMENT_DATA[0]?.position || { x: 0, y: 0, z: 0 } as any,
        inletStream: 'Warm Cooling Water Return (WCR) 42.0°C from plant',
        outletStream: 'Cooled Water Supply (CW) 32.0°C to plant',
        operatingTemp: '32.0°C Basin Water / 42.0°C Return',
        operatingPress: 'Atmospheric Draft',
        catalystOrInternals: 'PVC Cellular Film Fill, Drift Eliminators, 9 Fan Assemblies',
        description: 'برج تبريد صناعي ذو سحب قسري علوي مكون من 9 خلايا تبريد مستقلة لتبريد ماء المصنع وإعادة تدويره.',
        chemicalReaction: 'H₂O(liquid) + Air(dry) ⇌ H₂O(vapor) + Evaporative Cooling (Latent Heat Absorption: ~540 kcal/kg)'
      },
      {
        id: 'e-711',
        tag: 'E711',
        name: 'Surface Condenser E711',
        arabicName: 'المكثف السطحي الصناعي E711',
        type: 'exchanger',
        section: 'Cooling Tower Circuit',
        sectionNumber: 8,
        rowNumber: 2,
        position: MASTER_EQUIPMENT_DATA[0]?.position || { x: 0, y: 0, z: 0 } as any,
        inletStream: 'Turbine Exhaust Steam from 4500 RPM Turbines P711A & P711B',
        outletStream: 'Pure Condensate to Boiler Feed Water (BFW) Deaerator',
        operatingTemp: '45.0°C Condensate / 65.0°C Exhaust Steam',
        operatingPress: 'Vacuum 0.08 kg/cm²A (Full Condenser Vacuum)',
        catalystOrInternals: 'Titanium / Admiralty Brass Shell & Tube condenser bundle with vacuum hotwell sump',
        description: 'مكثف سطحي صناعي ضخم يتلقى البخار العادم من التوربينات البخارية لتكثيفه واسترجاع ماء المراجل النقي.',
        chemicalReaction: 'H₂O(exhaust steam at 0.08 bar) → H₂O(liquid condensate) [Phase Change Condensation]'
      },
      {
        id: 'p711a',
        tag: 'P-A',
        name: 'Turbine-Driven CW Pump A (4500 RPM)',
        arabicName: 'مضخة مياه التبريد التوربينية P-A',
        type: 'pump',
        section: 'Cooling Tower Circuit',
        sectionNumber: 8,
        rowNumber: 3,
        position: MASTER_EQUIPMENT_DATA[0]?.position || { x: 0, y: 0, z: 0 } as any,
        inletStream: 'Cold Water from Basin (32.0°C)',
        outletStream: 'Underground CW Supply Header (4.2 kg/cm²G)',
        operatingTemp: '32.0°C',
        operatingPress: 'Suction: 0.1 kg/cm²G | Discharge: 4.2 kg/cm²G',
        catalystOrInternals: 'Horizontal Centrifugal Split-case Pump driven by 4500 RPM Steam Turbine',
        description: 'مضخة مياه تبريد رئيسية عملاقة مدفوعة بتوربين بخاري لتغذية شبكة مياه التبريد لمصنع الأمونيا.'
      },
      {
        id: 'p711b',
        tag: 'P-B',
        name: 'Turbine-Driven CW Pump B (4500 RPM)',
        arabicName: 'مضخة مياه التبريد التوربينية P-B',
        type: 'pump',
        section: 'Cooling Tower Circuit',
        sectionNumber: 8,
        rowNumber: 4,
        position: MASTER_EQUIPMENT_DATA[0]?.position || { x: 0, y: 0, z: 0 } as any,
        inletStream: 'Cold Water from Basin (32.0°C)',
        outletStream: 'Underground CW Supply Header (4.2 kg/cm²G)',
        operatingTemp: '32.0°C',
        operatingPress: 'Suction: 0.1 kg/cm²G | Discharge: 4.2 kg/cm²G',
        catalystOrInternals: 'Horizontal Centrifugal Split-case Pump driven by 4500 RPM Steam Turbine',
        description: 'مضخة مياه التبريد التوربينية الاحتياطية/المتوازية الثانية لضمان استمرارية التبريد.'
      }
    ];

    sectionMap[8].equipmentList = ctEquipment;

    return Object.values(sectionMap);
  }

  private initDOM() {
    if (typeof document === 'undefined' || !document.body) return;

    let modal = document.getElementById('v3d-equipment-custom-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'v3d-equipment-custom-modal';
      modal.className = 'v3d-eq-custom-modal';
      modal.style.display = 'none';
      document.body.appendChild(modal);
    }
    this.modalEl = modal;

    this.injectStyles();
  }

  public openEditor(equipment: EquipmentInfo) {
    this.currentInspectedEquipment = equipment;
    const sections = this.getSectionsInOrder();
    
    // Find section and index
    let foundSecIdx = 0;
    let foundEqIdx = 0;
    for (let s = 0; s < sections.length; s++) {
      const idx = sections[s].equipmentList.findIndex((item) => item.id.toLowerCase() === equipment.id.toLowerCase() || item.tag.toLowerCase() === equipment.tag.toLowerCase());
      if (idx !== -1) {
        foundSecIdx = s;
        foundEqIdx = idx;
        break;
      }
    }

    this.currentSectionIndex = foundSecIdx;
    this.currentEquipmentIndexInSection = foundEqIdx;

    if (this.modalEl) {
      this.modalEl.style.display = 'flex';
      this.render();
    }
  }

  public close() {
    if (this.modalEl) {
      this.modalEl.style.display = 'none';
    }
  }

  private render() {
    if (!this.modalEl) return;
    const sections = this.getSectionsInOrder();
    const currentSec = sections[this.currentSectionIndex] || sections[0];
    const currentEq = currentSec.equipmentList[this.currentEquipmentIndexInSection] || this.currentInspectedEquipment || currentSec.equipmentList[0];
    this.currentInspectedEquipment = currentEq;

    const custom = this.getCustomRecord(currentEq.id) || this.getCustomRecord(currentEq.tag);
    const eff = this.getEffectiveData(currentEq);

    this.modalEl.innerHTML = `
      <div class="v3d-eqc-card">
        <!-- Header -->
        <div class="v3d-eqc-header">
          <div style="display:flex;align-items:center;gap:12px;">
            <span style="font-size:24px;">🔬</span>
            <div>
              <h2>تخصيص وإضافة البيانات والمعادلات الكيميائية للمعدة (Custom Equipment Engineering Data)</h2>
              <small>إضافة وحفظ وتعديل وحذف المعادلة الكيميائية، الضغط، درجة الحرارة، والمعلومات لكل أقسام المصنع بالترتيب</small>
            </div>
          </div>
          <button id="v3d-eqc-close-btn" class="v3d-eqc-btn-close">✕</button>
        </div>

        <!-- Section & Sequential Stepper Bar -->
        <div class="v3d-eqc-stepper">
          <div class="v3d-eqc-sec-select-wrap">
            <label>اختر القسم بالترتيب:</label>
            <select id="v3d-eqc-sec-select">
              ${sections.map((sec, idx) => `
                <option value="${idx}" ${idx === this.currentSectionIndex ? 'selected' : ''}>
                  ${escapeHtml(sec.nameAr)} (${sec.equipmentList.length} معدات)
                </option>
              `).join('')}
            </select>
          </div>

          <div class="v3d-eqc-nav-buttons">
            <button id="v3d-eqc-prev-btn" class="v3d-eqc-btn-nav" title="المعدة السابقة في هذا القسم">◀ المعدة السابقة</button>
            <span class="v3d-eqc-stepper-counter">
              معدة <b>${this.currentEquipmentIndexInSection + 1}</b> من <b>${currentSec.equipmentList.length}</b>
            </span>
            <button id="v3d-eqc-next-btn" class="v3d-eqc-btn-nav" title="المعدة التالية في هذا القسم">المعدة التالية ▶</button>
          </div>
        </div>

        <!-- Active Equipment Identity Badge -->
        <div class="v3d-eqc-eq-badge-strip">
          <div style="display:flex;align-items:center;gap:10px;">
            <span class="v3d-eqc-tag">${escapeHtml(currentEq.tag)}</span>
            <span class="v3d-eqc-title">${escapeHtml(currentEq.arabicName || currentEq.name)}</span>
            <span class="v3d-eqc-sub-en">(${escapeHtml(currentEq.name)})</span>
          </div>
          ${custom ? `<span class="v3d-eqc-custom-badge">✨ يحتوي على بيانات ومعادلة مخصصة محفوظة</span>` : `<span class="v3d-eqc-default-badge">📋 البيانات القياسية الحالية للتصميم الياباني</span>`}
        </div>

        <!-- Main Form Body -->
        <div class="v3d-eqc-body">
          <div class="v3d-eqc-form-grid">
            <!-- 1. Chemical Reaction / Equation -->
            <div class="v3d-eqc-field full-width">
              <label>
                🧪 المعادلة الكيميائية والتفاعل (Chemical Equation / Reaction):
                <small style="color:#94a3b8;font-weight:normal;margin-right:8px;">اكتب صيغة التفاعل الكيميائي أو الاتزان أو التحول الفيزيائي لهذه المعدة</small>
              </label>
              <!-- Quick chemical symbol insertion buttons -->
              <div class="v3d-eqc-symbol-toolbar">
                <span style="font-size:11px;color:#cbd5e1;align-self:center;">رموز سريعة:</span>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="⇌">⇌</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="→">→</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="+">+</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="ΔH < 0 (طارد)">ΔH < 0</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="ΔH > 0 (ماص)">ΔH > 0</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="CH₄">CH₄</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="H₂O">H₂O</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="CO">CO</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="CO₂">CO₂</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="H₂">H₂</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="N₂">N₂</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="NH₃">NH₃</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="ZnO + H₂S ⇌ ZnS + H₂O">تفاعل الكبريت</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="CH₄ + H₂O ⇌ CO + 3H₂">إصلاح الميثان</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="CO + H₂O ⇌ CO₂ + H₂">تفاعل التحويل Shift</button>
                <button type="button" class="v3d-eqc-sym-btn" data-sym="N₂ + 3H₂ ⇌ 2NH₃">تخليق الأمونيا</button>
              </div>
              <textarea id="eqc-reaction" rows="2" placeholder="اكتب المعادلة الكيميائية هنا (مثال: CH₄ + H₂O ⇌ CO + 3H₂  (ΔH = +206 kJ/mol))...">${escapeHtml(custom ? custom.chemicalReaction : (currentEq.chemicalReaction || ''))}</textarea>
            </div>

            <!-- 2. Operating Temperature -->
            <div class="v3d-eqc-field">
              <label>🌡️ درجة الحرارة التشغيلية (Operating Temperature):</label>
              <input type="text" id="eqc-temp" placeholder="مثال: 795.0 °C أو 380 °C" value="${escapeHtml(custom ? custom.operatingTemp : currentEq.operatingTemp)}" />
              <div class="v3d-eqc-hint">القيمة الافتراضية للتصميم: <code>${escapeHtml(currentEq.operatingTemp || 'غير محدد')}</code></div>
            </div>

            <!-- 3. Operating Pressure -->
            <div class="v3d-eqc-field">
              <label>⏱️ الضغط التشغيلي (Operating Pressure):</label>
              <input type="text" id="eqc-press" placeholder="مثال: 32.5 kg/cm²G أو 245.0 kg/cm²G" value="${escapeHtml(custom ? custom.operatingPress : currentEq.operatingPress)}" />
              <div class="v3d-eqc-hint">القيمة الافتراضية للتصميم: <code>${escapeHtml(currentEq.operatingPress || 'غير محدد')}</code></div>
            </div>

            <!-- 4. Custom Notes & Engineering Info -->
            <div class="v3d-eqc-field full-width">
              <label>📝 المعلومات والملاحظات الهندسية (Engineering Information & Technical Notes):</label>
              <textarea id="eqc-notes" rows="3" placeholder="أضف أي معلومات تفصيلية عن العوامل المساعدة، معايير السيطرة، إشارات الإنذار، أو مهام المشغل...">${escapeHtml(custom ? custom.customNotes : '')}</textarea>
            </div>
          </div>

          <!-- Status Message Notification -->
          <div id="v3d-eqc-status-msg" style="display:none;margin-top:12px;padding:10px 14px;border-radius:6px;font-size:12px;font-weight:bold;"></div>

          <!-- Action Buttons Bar -->
          <div class="v3d-eqc-footer-actions">
            <div style="display:flex;gap:10px;">
              <button id="v3d-eqc-save-btn" class="v3d-eqc-btn-save">
                💾 حفظ وتطبيق التغييرات على المعدة
              </button>
              ${custom ? `
                <button id="v3d-eqc-delete-btn" class="v3d-eqc-btn-delete" title="حذف البيانات المخصصة والرجوع إلى أرقام التصميم الأساسية">
                  🗑️ حذف وإعادة للقيم الأصلية
                </button>
              ` : ''}
            </div>

            <button id="v3d-eqc-close-action-btn" class="v3d-eqc-btn-cancel">
              إغلاق
            </button>
          </div>
        </div>
      </div>
    `;

    // Events Hookup
    document.getElementById('v3d-eqc-close-btn')?.addEventListener('click', () => this.close());
    document.getElementById('v3d-eqc-close-action-btn')?.addEventListener('click', () => this.close());

    // Section dropdown change
    document.getElementById('v3d-eqc-sec-select')?.addEventListener('change', (e) => {
      this.currentSectionIndex = parseInt((e.target as HTMLSelectElement).value) || 0;
      this.currentEquipmentIndexInSection = 0;
      this.render();
    });

    // Prev / Next equipment buttons
    document.getElementById('v3d-eqc-prev-btn')?.addEventListener('click', () => {
      if (this.currentEquipmentIndexInSection > 0) {
        this.currentEquipmentIndexInSection--;
      } else if (this.currentSectionIndex > 0) {
        this.currentSectionIndex--;
        const prevSec = sections[this.currentSectionIndex];
        this.currentEquipmentIndexInSection = prevSec.equipmentList.length - 1;
      }
      this.render();
    });

    document.getElementById('v3d-eqc-next-btn')?.addEventListener('click', () => {
      if (this.currentEquipmentIndexInSection < currentSec.equipmentList.length - 1) {
        this.currentEquipmentIndexInSection++;
      } else if (this.currentSectionIndex < sections.length - 1) {
        this.currentSectionIndex++;
        this.currentEquipmentIndexInSection = 0;
      }
      this.render();
    });

    // Quick symbol insertion
    document.querySelectorAll('.v3d-eqc-sym-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const sym = btn.getAttribute('data-sym');
        const rxInput = document.getElementById('eqc-reaction') as HTMLTextAreaElement;
        if (sym && rxInput) {
          const start = rxInput.selectionStart;
          const end = rxInput.selectionEnd;
          const val = rxInput.value;
          rxInput.value = val.substring(0, start) + sym + val.substring(end);
          rxInput.focus();
          rxInput.selectionStart = rxInput.selectionEnd = start + sym.length;
        }
      });
    });

    // Save action
    document.getElementById('v3d-eqc-save-btn')?.addEventListener('click', () => {
      this.handleSave(currentEq);
    });

    // Delete action
    document.getElementById('v3d-eqc-delete-btn')?.addEventListener('click', () => {
      if (confirm(`هل أنت متأكد من حذف البيانات المخصصة للمعدة (${currentEq.tag}) والرجوع للقيم الأصلية للمصنع؟`)) {
        this.deleteRecord(currentEq.id);
        this.showStatus('🗑️ تم حذف البيانات المخصصة بنجاح واستعادة القيم الأصلية للمعدة.', true);
        setTimeout(() => this.render(), 700);
      }
    });
  }

  private handleSave(eq: EquipmentInfo) {
    const rxEl = document.getElementById('eqc-reaction') as HTMLTextAreaElement;
    const tempEl = document.getElementById('eqc-temp') as HTMLInputElement;
    const pressEl = document.getElementById('eqc-press') as HTMLInputElement;
    const notesEl = document.getElementById('eqc-notes') as HTMLTextAreaElement;

    const record: CustomEquipmentRecord = {
      id: eq.id,
      tag: eq.tag,
      chemicalReaction: rxEl ? rxEl.value.trim() : '',
      operatingTemp: tempEl ? tempEl.value.trim() : eq.operatingTemp,
      operatingPress: pressEl ? pressEl.value.trim() : eq.operatingPress,
      customNotes: notesEl ? notesEl.value.trim() : '',
      updatedAt: new Date().toISOString()
    };

    this.saveRecord(record);
    this.showStatus('💾 تم حفظ وتثبيت المعادلة والبيانات التشغيلية للمعدة بنجاح وتحديثها فورياً في العرض ثلاثي الأبعاد!', true);
    setTimeout(() => this.render(), 600);
  }

  private showStatus(msg: string, isSuccess: boolean) {
    const el = document.getElementById('v3d-eqc-status-msg');
    if (!el) return;
    el.style.display = 'block';
    el.style.background = isSuccess ? 'rgba(16, 185, 129, 0.18)' : 'rgba(239, 68, 68, 0.18)';
    el.style.border = `1px solid ${isSuccess ? '#10b981' : '#ef4444'}`;
    el.style.color = isSuccess ? '#34d399' : '#f87171';
    el.textContent = msg;
  }

  private injectStyles() {
    if (document.getElementById('v3d-equipment-custom-styles')) return;

    const style = document.createElement('style');
    style.id = 'v3d-equipment-custom-styles';
    style.textContent = `
      .v3d-eq-custom-modal {
        position: fixed;
        inset: 0;
        z-index: 999998;
        background: rgba(3, 7, 18, 0.94);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        font-family: 'Cairo', system-ui, sans-serif;
        direction: rtl;
      }

      .v3d-eqc-card {
        width: 100%;
        max-width: 950px;
        max-height: 90vh;
        background: #0b1329;
        border: 2px solid #0284c7;
        border-radius: 16px;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        box-shadow: 0 24px 60px rgba(0, 0, 0, 0.95), 0 0 30px rgba(2, 132, 199, 0.3);
      }

      .v3d-eqc-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 22px;
        background: #080e1e;
        border-bottom: 1px solid #1e293b;
      }

      .v3d-eqc-header h2 {
        margin: 0;
        font-size: 15px;
        color: #38bdf8;
      }

      .v3d-eqc-header small {
        color: #94a3b8;
        font-size: 11px;
      }

      .v3d-eqc-btn-close {
        background: transparent;
        border: none;
        color: #cbd5e1;
        font-size: 20px;
        font-weight: bold;
        cursor: pointer;
        padding: 4px 8px;
      }
      .v3d-eqc-btn-close:hover {
        color: #ef4444;
      }

      .v3d-eqc-stepper {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 22px;
        background: #0f172a;
        border-bottom: 1px solid #1e293b;
        gap: 16px;
        flex-wrap: wrap;
      }

      .v3d-eqc-sec-select-wrap {
        display: flex;
        align-items: center;
        gap: 8px;
        flex: 1;
        min-width: 280px;
      }

      .v3d-eqc-sec-select-wrap label {
        font-size: 12px;
        color: #94a3b8;
        white-space: nowrap;
      }

      .v3d-eqc-sec-select-wrap select {
        width: 100%;
        background: #090d16;
        border: 1px solid #334155;
        color: #38bdf8;
        padding: 6px 12px;
        border-radius: 6px;
        font-family: 'Cairo', system-ui, sans-serif;
        font-size: 12px;
        font-weight: bold;
      }

      .v3d-eqc-nav-buttons {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .v3d-eqc-btn-nav {
        background: #1e293b;
        color: #e2e8f0;
        border: 1px solid #334155;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: bold;
        cursor: pointer;
      }
      .v3d-eqc-btn-nav:hover {
        background: #334155;
        color: #38bdf8;
      }

      .v3d-eqc-stepper-counter {
        font-size: 11.5px;
        color: #cbd5e1;
        white-space: nowrap;
      }

      .v3d-eqc-eq-badge-strip {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 22px;
        background: rgba(2, 132, 199, 0.1);
        border-bottom: 1px solid #1e293b;
      }

      .v3d-eqc-tag {
        background: #0284c7;
        color: #ffffff;
        font-weight: 900;
        font-size: 13px;
        padding: 3px 10px;
        border-radius: 6px;
        font-family: 'IBM Plex Mono', monospace;
      }

      .v3d-eqc-title {
        font-weight: bold;
        font-size: 14px;
        color: #ffffff;
      }

      .v3d-eqc-sub-en {
        color: #94a3b8;
        font-size: 12px;
      }

      .v3d-eqc-custom-badge {
        background: rgba(16, 185, 129, 0.18);
        border: 1px solid #10b981;
        color: #34d399;
        font-size: 11px;
        font-weight: bold;
        padding: 4px 10px;
        border-radius: 20px;
      }

      .v3d-eqc-default-badge {
        background: rgba(148, 163, 184, 0.12);
        border: 1px solid #475569;
        color: #94a3b8;
        font-size: 11px;
        padding: 4px 10px;
        border-radius: 20px;
      }

      .v3d-eqc-body {
        padding: 22px;
        overflow-y: auto;
        flex: 1;
      }

      .v3d-eqc-form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 18px;
      }
      .v3d-eqc-field.full-width {
        grid-column: 1 / -1;
      }

      .v3d-eqc-field label {
        display: block;
        font-size: 12.5px;
        font-weight: bold;
        color: #cbd5e1;
        margin-bottom: 6px;
      }

      .v3d-eqc-field input, .v3d-eqc-field textarea {
        width: 100%;
        background: #080d1a;
        border: 1px solid #334155;
        color: #ffffff;
        padding: 10px 14px;
        border-radius: 8px;
        font-family: 'Cairo', system-ui, sans-serif;
        font-size: 13px;
        box-sizing: border-box;
      }
      .v3d-eqc-field input:focus, .v3d-eqc-field textarea:focus {
        border-color: #0284c7;
        outline: none;
        box-shadow: 0 0 10px rgba(2, 132, 199, 0.3);
      }

      .v3d-eqc-hint {
        font-size: 10.5px;
        color: #94a3b8;
        margin-top: 4px;
      }
      .v3d-eqc-hint code {
        color: #38bdf8;
        background: #080d1a;
        padding: 1px 5px;
        border-radius: 4px;
      }

      .v3d-eqc-symbol-toolbar {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        margin-bottom: 8px;
        background: #0f172a;
        padding: 6px 10px;
        border-radius: 6px;
        border: 1px solid #1e293b;
      }

      .v3d-eqc-sym-btn {
        background: #1e293b;
        color: #38bdf8;
        border: 1px solid #334155;
        border-radius: 4px;
        padding: 2px 7px;
        font-size: 11px;
        font-weight: bold;
        cursor: pointer;
      }
      .v3d-eqc-sym-btn:hover {
        background: #0284c7;
        color: #ffffff;
      }

      .v3d-eqc-footer-actions {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 20px;
        border-top: 1px solid #1e293b;
        padding-top: 16px;
      }

      .v3d-eqc-btn-save {
        background: linear-gradient(135deg, #0284c7, #0369a1);
        color: #ffffff;
        border: none;
        padding: 10px 20px;
        border-radius: 8px;
        font-weight: 800;
        font-size: 13px;
        cursor: pointer;
        box-shadow: 0 4px 14px rgba(2, 132, 199, 0.4);
      }
      .v3d-eqc-btn-save:hover {
        background: #0284c7;
      }

      .v3d-eqc-btn-delete {
        background: rgba(239, 68, 68, 0.15);
        color: #f87171;
        border: 1px solid #ef4444;
        padding: 10px 16px;
        border-radius: 8px;
        font-weight: bold;
        font-size: 12.5px;
        cursor: pointer;
      }
      .v3d-eqc-btn-delete:hover {
        background: #ef4444;
        color: #ffffff;
      }

      .v3d-eqc-btn-cancel {
        background: #1e293b;
        color: #cbd5e1;
        border: 1px solid #334155;
        padding: 10px 18px;
        border-radius: 8px;
        font-size: 13px;
        cursor: pointer;
      }
      .v3d-eqc-btn-cancel:hover {
        background: #334155;
      }
    `;
    document.head.appendChild(style);
  }
}

export const equipmentCustomDataManager = EquipmentCustomDataManager.getInstance();

import * as THREE from 'three';
import { EquipmentInfo, MASTER_EQUIPMENT_DATA } from './PlantDiagramData';
import { Equipment3DBuilder, MaterialPalette } from './Equipment3DBuilder';
import { EquipmentCustomDataManager } from './EquipmentCustomDataManager';
import { CoolingTower3D } from './CoolingTower3D';
import { ReformingSection100_3D } from './ReformingSection100_3D';
import { CO2RemovalSection200_3D } from './CO2RemovalSection200_3D';
import { SynthesisSection400_3D } from './SynthesisSection400_3D';
import { SyngasCompressorK301_3D } from './SyngasCompressorK301_3D';
import { ControlRoom3D } from './ControlRoom3D';
import { SteamSystem3D } from './SteamSystem3D';
import { CompressorHall, HALL_WIDTH, STAIR_RUN, StairZone } from './CompressorHall';
import { CampusControlRoom, PLANT_SECTIONS } from './CampusControlRoom';
import {
  CampusMats, trimGroundSlabs, measureVisible, autoLabelModule, buildStreet, buildCurb,
  buildWasteWaterDrain, makeLabelSprite, tiledMaterial, animateDrains,
} from './CampusKit';
import {
  createCarbonSteelTexture,
  createAluminumCladdingTexture,
  createWetGroundTexture,
} from './TextureGenerator';

/**
 * AMMONIA GAME 3D - Professional Industrial Simulation
 * Features:
 * - Playable Engineer Hero character in blue jumpsuit and safety hardhat
 * - Real spatial layout:
 *   - Gate / Reception (الاستعلامات) at entrance
 *   - Main asphalt avenue with lane dividers and streetlamps
 *   - Right side: 9-cell Industrial Cooling Tower with circulation pumps
 *   - Left side: Section 1 (Reformer H-101, Secondary Reformer R-102, Boiler, Shift Converters, Methanator)
 *   - Cross street dividing Section 1 from Section 2 (Catacarb CO2 Removal T-201, T-202)
 *   - Control Room building with glass facade and consoles
 *   - Opposite across boulevard: Elevated 2nd-Floor Compressor Mezzanine (طابق الضاغطات الخمسة)
 *     with 3 distinct staircases (beginning, middle, end) leading up to Y=10.5m!
 *     Hosts K-301, K-302, K-303, K-401 (18 kg/cm², 180°C), and K-501
 *   - Section 4 (Ammonia Synthesis R-401, E-412, V-408, storage) adjacent to Section 1
 * - Third-person and first-person camera modes
 * - Smooth physics: walking, running, vertical stair climbing to 2nd floor, deck navigation
 * - Virtual Touch Joystick & Action Buttons for mobile/tablets
 * - Interactive plant inspection missions and checklist
 * - Procedural Web Audio sound effects (plant ambience, turbine hum, footsteps, chimes)
 */

export interface GameQuest {
  minY?: number;
  id: string;
  titleAr: string;
  titleEn: string;
  targetTag: string;
  position: THREE.Vector3;
  targetRadius: number;
  completed: boolean;
  descriptionAr: string;
}

export class AmmoniaGame {
  public group: THREE.Group;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private domElement: HTMLElement;

  // Active state
  public isActive: boolean = false;
  private clock: THREE.Clock = new THREE.Clock();

  // Hero Character
  public heroGroup: THREE.Group = new THREE.Group();
  private heroTorso!: THREE.Mesh;
  private heroHead!: THREE.Mesh;
  private heroHelmet!: THREE.Mesh;
  private heroLeftArm!: THREE.Group;
  private heroRightArm!: THREE.Group;
  private heroLeftLeg!: THREE.Group;
  private heroRightLeg!: THREE.Group;
  private heroPosition = new THREE.Vector3(0, 0, -145); // Start at Reception Gate
  private heroRotationY = 0; // Facing North into plant
  private heroVelocity = new THREE.Vector3();
  private walkAnimPhase = 0;
  private isMoving = false;
  private isRunning = false;
  private currentElevation = 0; // Ground (0) or Elevated Compressor Deck (10.5)

  // Camera settings
  public cameraMode: 'third_person' | 'first_person' = 'third_person';
  private camPitch = 0.22;
  private camYaw = 0;
  private camDistance = 11.0;
  private targetCamPos = new THREE.Vector3();
  private targetCamLookAt = new THREE.Vector3();

  // Control inputs
  private keys: { [key: string]: boolean } = {};
  private joystickVec = new THREE.Vector2(); // x: turn/strafe, y: forward/back
  private isPointerDown = false;
  private lastPointerX = 0;
  private lastPointerY = 0;

  // Sound Synth
  private audioCtx?: AudioContext;
  private ambientSoundGain?: GainNode;
  private isMuted: boolean = false;
  private lastFootstepTime = 0;

  // Quests & Inspection
  public quests: GameQuest[] = [];
  public currentQuestIndex = 0;
  public inspectedTags = new Set<string>();
  public currentNearbyEquipment: EquipmentInfo | null = null;
  public onInspectCallback?: (info: EquipmentInfo) => void;
  public onQuestCompletedCallback?: (quest: GameQuest) => void;

  // Staircases bounding boxes for vertical climbing (3 staircases to elevated compressor floor)
  // Compressor mezzanine deck: X from 32 to 62, Z from -35 to 95, Y = 10.5
  // Stair 1 (Beginning): Z: -35 to -23, X: 24 to 32, Y: 0 -> 10.5
  // Stair 2 (Middle):    Z: 25 to 37,   X: 24 to 32, Y: 0 -> 10.5
  // Stair 3 (End):       Z: 83 to 95,   X: 24 to 32, Y: 0 -> 10.5
  private staircasesLegacy = [
    { id: 'stair_start', minX: 22, maxX: 33, minZ: -37, maxZ: -21, startZ: -21, endZ: -35, startY: 0, endY: 10.5 },
    { id: 'stair_mid',   minX: 22, maxX: 33, minZ: 23,  maxZ: 39,  startZ: 25,  endZ: 37,  startY: 0, endY: 10.5 },
    { id: 'stair_end',   minX: 22, maxX: 33, minZ: 81,  maxZ: 97,  startZ: 83,  endZ: 95,  startY: 0, endY: 10.5 }
  ];

  // Mezzanine deck bounds:
  private deckBounds = { minX: 0, maxX: 0, minZ: 0, maxZ: 0, height: 10.5 };
  public staircases: StairZone[] = [];
  private campusRoot = new THREE.Group();
  private labelStore: THREE.Sprite[] = [];
  private labelFrame = 0;
  private _tmpV = new THREE.Vector3();
  private gateZ = -236;
  private waypoints: { id: string; nameAr: string; x: number; y: number; z: number; rot: number }[] = [];
  private zones: { id: string; nameAr: string; color: string; minX: number; maxX: number; minZ: number; maxZ: number }[] = [];
  private worldBounds = { minX: -260, maxX: 260, minZ: -270, maxZ: 560 };
  private crBounds = { minX: 0, maxX: 0, minZ: 0, maxZ: 0, y: 0.42 };
  private worldEquip: { eq: EquipmentInfo; x: number; y: number; z: number; deck: boolean }[] = [];
  private campusInfo: any = null;
  private compressorHall?: CompressorHall;
  private campusControlRoom?: CampusControlRoom;
  public steamSystem?: SteamSystem3D;
  private lampBudget = 6;
  private savedFogDensity?: number;

  // Materials Palette
  private mats: { [key: string]: THREE.MeshStandardMaterial | THREE.MeshBasicMaterial } = {};

  // Master 3D Submodules integrated into the game world
  public coolingTower?: CoolingTower3D;
  public reforming100?: ReformingSection100_3D;
  public co2Removal200?: CO2RemovalSection200_3D;
  public synthesis400?: SynthesisSection400_3D;
  public syngasK301?: SyngasCompressorK301_3D;
  public controlRoom3D?: ControlRoom3D;

  // UI Overlays
  private hudContainer?: HTMLElement;
  private questBanner?: HTMLElement;
  private inspectPrompt?: HTMLElement;
  private miniMapCanvas?: HTMLCanvasElement;
  private miniMapCtx?: CanvasRenderingContext2D;

  constructor(scene: THREE.Scene, camera: THREE.PerspectiveCamera, domElement: HTMLElement) {
    this.scene = scene;
    this.camera = camera;
    this.domElement = domElement;
    this.group = new THREE.Group();
    this.group.name = 'AmmoniaGame_World';

    this.initMaterials();
    this.buildWorldEnvironment();
    this.buildHeroCharacter();
    this.initQuests();
    this.setupEventListeners();
    this.createGameHUD();
  }

  // -------------------------------------------------------------
  // 1. MATERIALS & PROCEDURAL TEXTURES
  // -------------------------------------------------------------
  private initMaterials() {
    const carbonSteelTex = createCarbonSteelTexture();
    const claddingTex = createAluminumCladdingTexture();
    const asphaltTex = createWetGroundTexture();

    this.mats.asphalt = new THREE.MeshStandardMaterial({
      color: 0x22262c,
      roughness: 0.85,
      metalness: 0.15,
      map: asphaltTex,
    });

    this.mats.sidewalk = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.7,
      metalness: 0.1,
    });

    this.mats.curbYellow = new THREE.MeshStandardMaterial({
      color: 0xfacc15,
      roughness: 0.5,
      metalness: 0.2,
    });

    this.mats.roadStripe = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.4,
      metalness: 0.1,
    });

    this.mats.carbonSteel = new THREE.MeshStandardMaterial({
      color: 0x3b4252,
      roughness: 0.35,
      metalness: 0.85,
      map: carbonSteelTex,
    });

    this.mats.alloySteel = new THREE.MeshStandardMaterial({
      color: 0xd8dee9,
      roughness: 0.25,
      metalness: 0.92,
      map: claddingTex,
    });

    this.mats.brassValve = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      roughness: 0.3,
      metalness: 0.8,
    });

    this.mats.safetyBlue = new THREE.MeshStandardMaterial({
      color: 0x1d4ed8,
      roughness: 0.45,
      metalness: 0.3,
    });

    this.mats.safetyYellow = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.4,
      metalness: 0.4,
    });

    this.mats.safetyGreen = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      roughness: 0.4,
      metalness: 0.4,
    });

    this.mats.concretePlinth = new THREE.MeshStandardMaterial({
      color: 0x64748b,
      roughness: 0.9,
      metalness: 0.05,
    });

    this.mats.gratingDeck = new THREE.MeshStandardMaterial({
      color: 0x475569,
      roughness: 0.4,
      metalness: 0.8,
    });

    this.mats.glassBuilding = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      roughness: 0.1,
      metalness: 0.9,
      transparent: true,
      opacity: 0.65,
    });

    this.mats.heroSuit = new THREE.MeshStandardMaterial({
      color: 0x1e40af, // Royal industrial work blue
      roughness: 0.65,
      metalness: 0.1,
    });

    this.mats.heroHelmet = new THREE.MeshStandardMaterial({
      color: 0xfef08a, // High-visibility engineer yellow helmet
      roughness: 0.3,
      metalness: 0.3,
    });

    this.mats.heroSkin = new THREE.MeshStandardMaterial({
      color: 0xd4a373,
      roughness: 0.8,
      metalness: 0.0,
    });

    this.mats.heroBoots = new THREE.MeshStandardMaterial({
      color: 0x1f2937,
      roughness: 0.5,
      metalness: 0.2,
    });

    this.mats.hiVisVest = new THREE.MeshStandardMaterial({
      color: 0x22c55e, // Bright fluorescent safety green
      roughness: 0.4,
      metalness: 0.2,
    });

    this.mats.hotDischarge = new THREE.MeshStandardMaterial({
      color: 0xb91c1c, // 180°C hot line
      roughness: 0.35,
      metalness: 0.8,
    });

    this.mats.liquidAmmonia = new THREE.MeshStandardMaterial({
      color: 0x06b6d4, // Cyan condensed refrigerant line
      roughness: 0.25,
      metalness: 0.85,
    });

    // High-Vis Retroreflective 3M Silver Tape
    this.mats.reflectiveSilver = new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      roughness: 0.1,
      metalness: 0.95,
    });

    // Safety Glasses / Visor Lens
    this.mats.gogglesLens = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      roughness: 0.1,
      metalness: 0.9,
      transparent: true,
      opacity: 0.55,
    });

    // Leather Work Gloves
    this.mats.gloveLeather = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.75,
      metalness: 0.1,
    });

    // Digital Inspector Tablet Screen
    const tabletCanvas = document.createElement('canvas');
    tabletCanvas.width = 256;
    tabletCanvas.height = 384;
    const tCtx = tabletCanvas.getContext('2d')!;
    tCtx.fillStyle = '#06111e';
    tCtx.fillRect(0, 0, 256, 384);
    tCtx.fillStyle = '#38bdf8';
    tCtx.font = 'bold 20px monospace';
    tCtx.fillText('DCS TELEMETRY', 20, 35);
    tCtx.fillStyle = '#10b981';
    tCtx.font = '16px monospace';
    tCtx.fillText('STATUS: NORMAL', 20, 65);
    tCtx.fillText('H-101: 750°C', 20, 100);
    tCtx.fillText('K-401: 18 bar', 20, 135);
    tCtx.fillText('T-201: 35 bar', 20, 170);
    tCtx.strokeStyle = '#0284c7';
    tCtx.lineWidth = 3;
    tCtx.beginPath();
    tCtx.moveTo(20, 220); tCtx.lineTo(70, 280); tCtx.lineTo(140, 240); tCtx.lineTo(230, 310);
    tCtx.stroke();
    const tabletTex = new THREE.CanvasTexture(tabletCanvas);

    this.mats.tabletScreen = new THREE.MeshBasicMaterial({
      map: tabletTex,
    });
  }

  // -------------------------------------------------------------
  // 2. WORLD ENVIRONMENT — الحرم الموسّع للمعمل (Campus Master Plan)
  //
  //   [الاستعلامات]  ← الشارع الرئيسي العريض →  [غرفة السيطرة]
  //   يمين الشارع (من منظور الماشي):  برج التبريد ← القسم الرابع ← قسم الضاغطات (طابق علوي + 3 سلالم)
  //   يسار الشارع:                     القسم الأول ← القسم الثاني ← منظومة البخار
  //   بين كل قسم وآخر: شارع عريض + مجرى مياه صرف (Waste Water) بجانب كل قسم
  //   * أبعاد كل قسم تُقاس تلقائياً من النموذج ثلاثي الأبعاد ثم يوضع بدقة على المخطط.
  // -------------------------------------------------------------
  private buildWorldEnvironment() {
    const m = this.mats as unknown as CampusMats;
    const AVE_W = 26, AH = AVE_W / 2;
    const INNER = 23;          // بداية الأقسام من محور الشارع
    const GAP = 38;            // الشارع الفاصل بين قسمين (شارع + مجريان + أرصفة)
    const Z_GATE = -236;
    const Z_START = -180;

    this.group.add(this.campusRoot);

    type Side = 'left' | 'right';
    interface Blk { id: string; nameAr: string; nameEn: string; side: Side; accent: string; num: string; minX: number; maxX: number; minZ: number; maxZ: number; }
    const blocks: Blk[] = [];
    const cursor: Record<Side, number> = { left: Z_START, right: Z_START };
    const sgnOf = (s: Side) => (s === 'left' ? 1 : -1);
    const secInfo = (id: string) => PLANT_SECTIONS.find((s) => s.id === id)!;
    const labelStore = this.labelStore;

    const placeModule = (id: string, side: Side, mod: THREE.Object3D) => {
      const info = secInfo(id);
      trimGroundSlabs(mod);
      const box = measureVisible(mod);
      const size = box.getSize(new THREE.Vector3());
      const c = box.getCenter(new THREE.Vector3());
      const cz = cursor[side] + size.z / 2;
      const cx = sgnOf(side) * (INNER + size.x / 2);
      mod.position.x += cx - c.x;
      mod.position.z += cz - c.z;
      mod.position.y += -box.min.y;
      this.campusRoot.add(mod);
      mod.updateMatrixWorld(true);
      const blk: Blk = { id, nameAr: info.nameAr, nameEn: info.nameEn, side, accent: info.accent, num: info.num,
        minX: cx - size.x / 2, maxX: cx + size.x / 2, minZ: cz - size.z / 2, maxZ: cz + size.z / 2 };
      blocks.push(blk);
      cursor[side] += size.z + GAP;
      autoLabelModule(mod, this.campusRoot, info.accent, labelStore, { avenueX: 0 });
      return blk;
    };

    // ---- RIGHT column: cooling tower → section 4 → compressors ----
    this.coolingTower = new CoolingTower3D();
    this.coolingTower.group.scale.setScalar(0.92);
    placeModule('cooling', 'right', this.coolingTower.group);

    this.synthesis400 = new SynthesisSection400_3D();
    this.synthesis400.group.scale.setScalar(0.74);
    placeModule('sec4', 'right', this.synthesis400.group);

    const hall = new CompressorHall(m, labelStore, 1);
    this.compressorHall = hall;
    this.syngasK301 = hall.k301;
    const hallInnerEdge = -(INNER + 1);                // x of stair foot
    const hallCx = hallInnerEdge - STAIR_RUN - HALL_WIDTH / 2;
    const hallCz = cursor.right + hall.length / 2;
    hall.group.position.set(hallCx, 0, hallCz);
    this.campusRoot.add(hall.group);
    hall.group.updateMatrixWorld(true);
    if (hall.k301) autoLabelModule(hall.k301.group, this.campusRoot, '#a78bfa', labelStore, { avenueX: 0 });
    const hallBlk: Blk = { id: 'sec3', nameAr: secInfo('sec3').nameAr, nameEn: secInfo('sec3').nameEn, side: 'right', accent: secInfo('sec3').accent, num: 'SECTION 300',
      minX: hallCx - HALL_WIDTH / 2, maxX: hallInnerEdge, minZ: hallCz - hall.length / 2, maxZ: hallCz + hall.length / 2 };
    blocks.push(hallBlk);
    cursor.right += hall.length + GAP;
    // physics for the elevated floor
    hall.stairs.forEach((s) => this.staircases.push({ ...s, minX: s.minX + hallCx, maxX: s.maxX + hallCx, minZ: s.minZ + hallCz, maxZ: s.maxZ + hallCz }));
    this.deckBounds = { minX: hallCx - HALL_WIDTH / 2, maxX: hallCx + HALL_WIDTH / 2, minZ: hallCz - hall.length / 2, maxZ: hallCz + hall.length / 2, height: 10.5 };

    // ---- LEFT column: section 1 → section 2 → steam ----
    this.reforming100 = new ReformingSection100_3D();
    this.reforming100.group.scale.setScalar(0.82);
    placeModule('sec1', 'left', this.reforming100.group);

    this.co2Removal200 = new CO2RemovalSection200_3D();
    this.co2Removal200.group.scale.setScalar(0.74);
    placeModule('sec2', 'left', this.co2Removal200.group);

    try {
      this.steamSystem = new SteamSystem3D();
      this.steamSystem.group.scale.setScalar(0.9);
      placeModule('steam', 'left', this.steamSystem.group);
    } catch (err) {
      console.warn('SteamSystem3D could not be placed:', err);
      this.steamSystem = undefined;
    }

    // ---- extents ----
    const leftBlocks = blocks.filter((b) => b.side === 'left');
    const rightBlocks = blocks.filter((b) => b.side === 'right');
    const outerL = Math.max(...leftBlocks.map((b) => b.maxX)) + 12;
    const outerR = Math.min(...rightBlocks.map((b) => b.minX)) - 12;
    const zEnd = Math.max(cursor.left, cursor.right) - GAP;
    const PLAZA = 34;
    const Z_CCR = zEnd + PLAZA;                         // front facade of the control room
    const crDepth = 60;
    const zMin = Z_GATE - 40, zMax = Z_CCR + crDepth + 30;
    const halfW = Math.max(outerL, -outerR, 100) + 40;

    // ---- ground ----
    const groundMat = tiledMaterial(m.asphalt, halfW * 2, zMax - zMin, 18);
    groundMat.color = new THREE.Color(0x2b3036);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(halfW * 2 + 160, zMax - zMin + 160), groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(0, -0.05, (zMin + zMax) / 2);
    this.campusRoot.add(ground);

    // ---- main avenue (wide) + sidewalks + avenue-side waste-water drains ----
    const aveLen = Z_CCR - 6 - (Z_GATE - 30);
    const aveCz = (Z_CCR - 6 + (Z_GATE - 30)) / 2;
    buildStreet(this.campusRoot, m, 0, aveCz, AVE_W, aveLen);
    [-1, 1].forEach((s) => buildCurb(this.campusRoot, m, s * (AH + 1.6), aveCz, 3.2, aveLen));

    // ---- plots, cross streets, drains, entrance boards per block ----
    const drainX = AH + 3.2 + 2.3;
    const pad = new THREE.MeshStandardMaterial({ color: 0x5d646b, roughness: 0.95 });
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
    blocks.forEach((b, idx) => {
      const sgn = sgnOf(b.side);
      const w = b.maxX - b.minX, d = b.maxZ - b.minZ;
      const plot = new THREE.Mesh(new THREE.PlaneGeometry(w + 6, d + 6), pad);
      plot.rotation.x = -Math.PI / 2;
      plot.position.set((b.minX + b.maxX) / 2, 0.03, (b.minZ + b.maxZ) / 2);
      this.campusRoot.add(plot);
      [[0, -1], [0, 1]].forEach(([, s]) => {
        const ln = new THREE.Mesh(new THREE.PlaneGeometry(w + 6, 0.35), lineMat);
        ln.rotation.x = -Math.PI / 2;
        ln.position.set((b.minX + b.maxX) / 2, 0.045, (b.minZ + b.maxZ) / 2 + s * (d / 2 + 3));
        this.campusRoot.add(ln);
      });

      // drain along the avenue for the whole length of the block
      buildWasteWaterDrain(this.campusRoot, m, sgn * drainX, b.minZ - 4, sgn * drainX, b.maxZ + 4, 2.6, labelStore, b.nameEn, b.nameAr);

      // entrance board
      const sp = makeLabelSprite(b.num, b.nameAr, b.accent, 4.2);
      sp.userData.big = true;
      sp.position.set(sgn * (AH + 4), 12.5, b.minZ + 14);
      this.campusRoot.add(sp);
      labelStore.push(sp);
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.22, 11, 10), m.carbonSteel);
      post.position.set(sgn * (AH + 4), 5.5, b.minZ + 14);
      this.campusRoot.add(post);

      // cross street after the block (except when it is the last of its column)
      const next = blocks.find((o, j) => j > idx && o.side === b.side);
      if (next) {
        const zc = (b.maxZ + next.minZ) / 2;
        const outer = sgn > 0 ? outerL : outerR;
        const len = Math.abs(outer) - AH;
        buildStreet(this.campusRoot, m, sgn * (AH + len / 2), zc, len, 22, { dashed: true });
        buildWasteWaterDrain(this.campusRoot, m, sgn * (AH + 6), b.maxZ + 2.2, outer, b.maxZ + 2.2, 2.6, labelStore, b.nameEn, b.nameAr);
        buildWasteWaterDrain(this.campusRoot, m, sgn * (AH + 6), next.minZ - 2.2, outer, next.minZ - 2.2, 2.6, labelStore, next.nameEn, next.nameAr);
      }
      this.zones.push({ id: b.id, nameAr: b.nameAr, color: b.accent, minX: b.minX, maxX: b.maxX, minZ: b.minZ, maxZ: b.maxZ });
    });

    // ---- plaza in front of the control room ----
    const plaza = new THREE.Mesh(new THREE.PlaneGeometry(halfW * 1.1, PLAZA + 6), new THREE.MeshStandardMaterial({ color: 0x7b828a, roughness: 0.85 }));
    plaza.rotation.x = -Math.PI / 2;
    plaza.position.set(0, 0.03, zEnd + PLAZA / 2 - 2);
    this.campusRoot.add(plaza);
    for (let i = -6; i <= 6; i++) {
      if (Math.abs(i) < 2) continue;
      const bay = new THREE.Mesh(new THREE.PlaneGeometry(0.25, 6), lineMat);
      bay.rotation.x = -Math.PI / 2;
      bay.position.set(i * 5, 0.05, Z_CCR - 8);
      this.campusRoot.add(bay);
    }

    // ---- street lamps (emissive heads; only a few real point lights) ----
    for (let z = Z_GATE + 12; z <= Z_CCR - 12; z += 36) {
      this.buildStreetLamp(-(AH + 0.8), z);
      this.buildStreetLamp(AH + 0.8, z);
    }

    // ---- reception gate ----
    this.buildReceptionGate(0, Z_GATE);
    this.gateZ = Z_GATE;

    // ---- control room ----
    this.campusControlRoom = new CampusControlRoom(m, labelStore);
    this.campusControlRoom.group.position.set(0, 0, Z_CCR);
    this.campusRoot.add(this.campusControlRoom.group);
    this.crBounds = { minX: -this.campusControlRoom.width / 2, maxX: this.campusControlRoom.width / 2, minZ: Z_CCR, maxZ: Z_CCR + crDepth, y: 0.42 };
    this.zones.push({ id: 'ccr', nameAr: 'غرفة السيطرة', color: '#a855f7', minX: this.crBounds.minX, maxX: this.crBounds.maxX, minZ: Z_CCR, maxZ: Z_CCR + crDepth });

    // ---- world bounds / start ----
    this.worldBounds = { minX: -(Math.abs(outerR) + 24), maxX: outerL + 24, minZ: Z_GATE - 30, maxZ: Z_CCR + crDepth - 2 };
    this.heroPosition.set(0, 0, Z_GATE - 14);
    this.campusInfo = { blocks, Z_GATE, Z_CCR, AH, INNER, hallCx, hallCz, hallLen: hall.length, deckBays: hall.bayCenters };

    // ---- waypoints (fast travel) ----
    this.waypoints.push({ id: 'gate', nameAr: '🚪 الاستعلامات', x: 0, y: 0, z: Z_GATE - 14, rot: 0 });
    blocks.forEach((b) => {
      const sgn = sgnOf(b.side);
      this.waypoints.push({ id: b.id, nameAr: b.nameAr, x: sgn * (AH + 1.5), y: 0, z: (b.minZ + b.maxZ) / 2 - 8, rot: sgn > 0 ? Math.PI / 2 : -Math.PI / 2 });
    });
    const k401 = hall.bayCenters.find((x) => x.key === 'K-401');
    if (k401) this.waypoints.push({ id: 'deck', nameAr: '⬆️ طابق الضاغطات (فوق)', x: hallCx + 18, y: 10.5, z: hallCz + k401.z, rot: -Math.PI / 2 });
    this.waypoints.push({ id: 'ccr_front', nameAr: '🏢 مدخل غرفة السيطرة', x: 0, y: 0, z: Z_CCR - 14, rot: 0 });
    this.waypoints.push({ id: 'ccr_in', nameAr: '🖥️ داخل غرفة السيطرة', x: 0, y: 0.42, z: Z_CCR + 30, rot: Math.PI });

    this.group.updateMatrixWorld(true);
    this.buildWorldEquipment();
    this.scene.add(this.group);
  }

  /** مواقع المعدات الحقيقية في العالم (من لافتات الأسماء) لاستخدامها بالفحص عند الاقتراب. */
  private buildWorldEquipment() {
    const norm = (s: string) => s.toUpperCase().replace(/[\s_]/g, '');
    const base = (s: string) => norm(s).replace(/(?<=\d)[A-Z\/]+$/, '');
    const exact = new Map<string, { x: number; y: number; z: number; deck: boolean }>();
    const loose = new Map<string, { x: number; y: number; z: number; deck: boolean }>();
    const v = new THREE.Vector3();
    const hallGroup = this.compressorHall?.group;
    const isDeck = (o: THREE.Object3D) => { let p: THREE.Object3D | null = o; while (p) { if (p === hallGroup) return true; p = p.parent; } return false; };
    this.labelStore.forEach((sp) => {
      const tg = sp.userData.tag as string | undefined;
      if (!tg || tg === 'WASTE WATER') return;
      sp.getWorldPosition(v);
      const rec = { x: v.x, y: v.y, z: v.z, deck: isDeck(sp) };
      if (!exact.has(norm(tg))) exact.set(norm(tg), rec);
      if (!loose.has(base(tg))) loose.set(base(tg), rec);
    });
    MASTER_EQUIPMENT_DATA.forEach((eq) => {
      const hit = exact.get(norm(eq.tag)) || loose.get(base(eq.tag));
      if (hit) this.worldEquip.push({ eq, ...hit });
    });
  }

  private updateLabels() {
    const hp = this.heroPosition;
    const v = this._tmpV;
    for (const sp of this.labelStore) {
      sp.getWorldPosition(v);
      const d = Math.hypot(v.x - hp.x, v.z - hp.z);
      const big = sp.userData.big === true;
      sp.visible = d < (big ? 150 : 72);
      if (!sp.visible) continue;
      if (sp.userData.bx === undefined) { sp.userData.bx = sp.scale.x; sp.userData.by = sp.scale.y; }
      const k = THREE.MathUtils.clamp(d / 30, 1, 2.3);
      sp.scale.set(sp.userData.bx * k, sp.userData.by * k, 1);
    }
  }

  public teleportTo(id: string) {
    const wp = this.waypoints.find((w) => w.id === id);
    if (!wp) return;
    this.heroPosition.set(wp.x, wp.y, wp.z);
    this.heroRotationY = wp.rot;
    this.camYaw = wp.rot;
    this.heroGroup.position.copy(this.heroPosition);
    this.heroGroup.rotation.y = wp.rot;
    this.camera.position.set(wp.x - Math.sin(wp.rot) * 10, wp.y + 5, wp.z - Math.cos(wp.rot) * 10);
    this.playSuccessChime();
  }

  // Road builder with curbs and lane divider markings
  private buildRoad(centerX: number, centerZ: number, width: number, length: number, isNorthSouth: boolean) {
    const roadGeo = new THREE.PlaneGeometry(width, length);
    const roadMesh = new THREE.Mesh(roadGeo, this.mats.asphalt);
    roadMesh.rotation.x = -Math.PI / 2;
    if (!isNorthSouth) {
      roadMesh.rotation.z = Math.PI / 2;
    }
    roadMesh.position.set(centerX, 0.01, centerZ);
    this.group.add(roadMesh);

    // Curbs & Sidewalks on both sides
    const curbW = 1.6;
    const curbH = 0.25;
    if (isNorthSouth) {
      [-width / 2 - curbW / 2, width / 2 + curbW / 2].forEach((xOffset) => {
        const swGeo = new THREE.BoxGeometry(curbW, curbH, length);
        const sw = new THREE.Mesh(swGeo, this.mats.sidewalk);
        sw.position.set(centerX + xOffset, curbH / 2, centerZ);
        this.group.add(sw);

        // Yellow painted curb line
        const cGeo = new THREE.BoxGeometry(0.18, 0.28, length);
        const c = new THREE.Mesh(cGeo, this.mats.curbYellow);
        const curbEdgeX = xOffset > 0 ? centerX + width / 2 + 0.09 : centerX - width / 2 - 0.09;
        c.position.set(curbEdgeX, curbH / 2 + 0.02, centerZ);
        this.group.add(c);
      });

      // Dashed yellow center dividing line
      for (let z = -length / 2 + 3; z <= length / 2 - 3; z += 8) {
        const stripeGeo = new THREE.PlaneGeometry(0.35, 4.5);
        const stripe = new THREE.Mesh(stripeGeo, this.mats.curbYellow);
        stripe.rotation.x = -Math.PI / 2;
        stripe.position.set(centerX, 0.03, centerZ + z);
        this.group.add(stripe);
      }
    } else {
      [-length / 2 - curbW / 2, length / 2 + curbW / 2].forEach((zOffset) => {
        const swGeo = new THREE.BoxGeometry(width, curbH, curbW);
        const sw = new THREE.Mesh(swGeo, this.mats.sidewalk);
        sw.position.set(centerX, curbH / 2, centerZ + zOffset);
        this.group.add(sw);
      });
    }
  }

  private buildStreetLamp(x: number, z: number) {
    const lampGroup = new THREE.Group();
    lampGroup.position.set(x, 0, z);

    // Base concrete footing
    const footGeo = new THREE.CylinderGeometry(0.45, 0.5, 0.6, 12);
    const foot = new THREE.Mesh(footGeo, this.mats.concretePlinth);
    foot.position.set(0, 0.3, 0);
    lampGroup.add(foot);

    // Tall tapered pole (8.5m)
    const poleGeo = new THREE.CylinderGeometry(0.12, 0.22, 8.0, 12);
    const pole = new THREE.Mesh(poleGeo, this.mats.carbonSteel);
    pole.position.set(0, 4.3, 0);
    lampGroup.add(pole);

    // Curved arm
    const armGeo = new THREE.CylinderGeometry(0.08, 0.08, 2.2, 8);
    const arm = new THREE.Mesh(armGeo, this.mats.carbonSteel);
    arm.rotation.z = x < 0 ? -Math.PI / 4 : Math.PI / 4;
    arm.position.set(x < 0 ? 0.8 : -0.8, 8.6, 0);
    lampGroup.add(arm);

    // Lamp fixture head with warm light
    const headGeo = new THREE.BoxGeometry(0.9, 0.25, 0.45);
    const head = new THREE.Mesh(headGeo, this.mats.safetyYellow);
    head.position.set(x < 0 ? 1.6 : -1.6, 9.2, 0);
    lampGroup.add(head);

    // Point Light
    (head.material as THREE.MeshStandardMaterial) = new THREE.MeshStandardMaterial({ color: 0xfff3c4, emissive: 0xffe9a8, emissiveIntensity: 1.6 });
    if (this.lampBudget > 0) {
      this.lampBudget--;
      const light = new THREE.PointLight(0xfff3c4, 1.4, 40, 1.5);
      light.position.set(x < 0 ? 1.6 : -1.6, 9.0, 0);
      lampGroup.add(light);
    }

    this.group.add(lampGroup);
  }

  // -------------------------------------------------------------
  // 3. MAIN GATE & RECEPTION (الاستعلامات)
  // -------------------------------------------------------------
  private buildReceptionGate(x: number, z: number) {
    const gateGroup = new THREE.Group();
    gateGroup.position.set(x, 0, z);
    gateGroup.name = 'Gate_Reception';

    // Concrete island foundation
    const islandGeo = new THREE.BoxGeometry(22, 0.4, 12);
    const island = new THREE.Mesh(islandGeo, this.mats.concretePlinth);
    island.position.set(0, 0.2, 0);
    gateGroup.add(island);

    // Security Gatehouse Cabin (الاستعلامات)
    const cabinGeo = new THREE.BoxGeometry(6.5, 4.2, 5.0);
    const cabin = new THREE.Mesh(cabinGeo, this.mats.sidewalk);
    cabin.position.set(-6.5, 2.3, 0);
    gateGroup.add(cabin);

    // Glass Observation Window
    const winGeo = new THREE.BoxGeometry(5.2, 2.0, 0.2);
    const win = new THREE.Mesh(winGeo, this.mats.glassBuilding);
    win.position.set(-6.5, 2.6, 2.52);
    gateGroup.add(win);

    // Reception Door
    const doorGeo = new THREE.BoxGeometry(1.4, 2.4, 0.1);
    const door = new THREE.Mesh(doorGeo, this.mats.carbonSteel);
    door.position.set(-3.3, 1.4, 0);
    door.rotation.y = Math.PI / 2;
    gateGroup.add(door);

    // Overhang Roof Canopy
    const canopyGeo = new THREE.BoxGeometry(20, 0.5, 8.0);
    const canopy = new THREE.Mesh(canopyGeo, this.mats.safetyBlue);
    canopy.position.set(0, 6.0, 0);
    gateGroup.add(canopy);

    // Canopy Steel Support Columns
    [-8.5, 8.5].forEach((cx) => {
      const colGeo = new THREE.CylinderGeometry(0.25, 0.25, 5.6, 12);
      const col = new THREE.Mesh(colGeo, this.mats.alloySteel);
      col.position.set(cx, 3.0, 0);
      gateGroup.add(col);
    });

    // Boom Barrier Gate (حاجز أمني متحرك)
    const barrierBaseGeo = new THREE.BoxGeometry(0.8, 1.4, 0.8);
    const barrierBase = new THREE.Mesh(barrierBaseGeo, this.mats.safetyYellow);
    barrierBase.position.set(1.5, 0.9, 0);
    gateGroup.add(barrierBase);

    const boomArmGeo = new THREE.BoxGeometry(5.5, 0.15, 0.15);
    const boomArm = new THREE.Mesh(boomArmGeo, this.mats.curbYellow);
    boomArm.position.set(4.3, 1.2, 0);
    gateGroup.add(boomArm);

    // Arabic Welcome Signboard (استعلامات مجمع تصنيع الأمونيا)
    const signCanvas = document.createElement('canvas');
    signCanvas.width = 1024;
    signCanvas.height = 256;
    const sCtx = signCanvas.getContext('2d')!;
    sCtx.fillStyle = '#0f172a';
    sCtx.fillRect(0, 0, 1024, 256);
    sCtx.strokeStyle = '#0284c7';
    sCtx.lineWidth = 12;
    sCtx.strokeRect(6, 6, 1012, 244);

    sCtx.fillStyle = '#38bdf8';
    sCtx.font = 'bold 54px sans-serif';
    sCtx.textAlign = 'center';
    sCtx.fillText('بوابة الاستعلامات والأمن الصناعي — مجمع الأمونيا', 512, 90);
    sCtx.fillStyle = '#ffffff';
    sCtx.font = 'bold 36px monospace';
    sCtx.fillText('AMMONIA PLANT RECEPTION & INDUSTRIAL GATE', 512, 160);
    sCtx.fillStyle = '#22c55e';
    sCtx.font = '28px sans-serif';
    sCtx.fillText('الرجاء ارتداء قبعة ومعدات السلامة قبل الدخول', 512, 220);

    const signTex = new THREE.CanvasTexture(signCanvas);
    const signMesh = new THREE.Mesh(new THREE.PlaneGeometry(12, 3.0), new THREE.MeshBasicMaterial({ map: signTex }));
    signMesh.position.set(0, 7.8, 0.2);
    gateGroup.add(signMesh);

    this.group.add(gateGroup);
  }

  // -------------------------------------------------------------
  // 10. HERO CHARACTER (THE ENGINEER)
  // Blue jumpsuit, yellow safety hardhat, boots, reflective harness
  // -------------------------------------------------------------
  private buildHeroCharacter() {
    this.heroGroup = new THREE.Group();
    this.heroGroup.name = 'Hero_Engineer';
    this.heroGroup.position.copy(this.heroPosition);

    // -------------------------------------------------------------
    // 1. TORSO & WORK COVERALL (JUMPSUIT)
    // -------------------------------------------------------------
    const torsoGroup = new THREE.Group();
    torsoGroup.position.set(0, 1.45, 0);

    // Main chest & stomach (Tapered anatomical upper body)
    const upperTorsoGeo = new THREE.CylinderGeometry(0.44, 0.36, 0.95, 16);
    this.heroTorso = new THREE.Mesh(upperTorsoGeo, this.mats.heroSuit);
    torsoGroup.add(this.heroTorso);

    // Collar
    const collarGeo = new THREE.CylinderGeometry(0.24, 0.28, 0.14, 16);
    const collar = new THREE.Mesh(collarGeo, this.mats.heroSuit);
    collar.position.set(0, 0.52, 0);
    torsoGroup.add(collar);

    // Brass Zipper line
    const zipperGeo = new THREE.BoxGeometry(0.04, 0.88, 0.04);
    const zipper = new THREE.Mesh(zipperGeo, this.mats.brassValve);
    zipper.position.set(0, 0, 0.42);
    torsoGroup.add(zipper);

    // Chest Pockets
    [-0.18, 0.18].forEach((px) => {
      const pocketGeo = new THREE.BoxGeometry(0.18, 0.22, 0.05);
      const pocket = new THREE.Mesh(pocketGeo, this.mats.heroSuit);
      pocket.position.set(px, 0.22, 0.41);
      torsoGroup.add(pocket);
    });

    // 3M Hi-Vis Reflective Harness Vest (Neon Green Harness + Silver Retroreflective Stripes)
    const vestHarnessGeo = new THREE.BoxGeometry(0.89, 0.28, 0.52);
    const vestHarness = new THREE.Mesh(vestHarnessGeo, this.mats.hiVisVest);
    vestHarness.position.set(0, 0.2, 0);
    torsoGroup.add(vestHarness);

    // Silver Reflective Tape Stripes across chest & back
    const tapeHorizGeo = new THREE.BoxGeometry(0.9, 0.08, 0.54);
    const tapeHoriz = new THREE.Mesh(tapeHorizGeo, this.mats.reflectiveSilver);
    tapeHoriz.position.set(0, 0.2, 0);
    torsoGroup.add(tapeHoriz);

    // Radio Walkie-Talkie on left shoulder strap
    const radioGeo = new THREE.BoxGeometry(0.14, 0.3, 0.1);
    const radio = new THREE.Mesh(radioGeo, this.mats.carbonSteel);
    radio.position.set(-0.3, 0.28, 0.26);
    torsoGroup.add(radio);

    const antennaGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.25, 8);
    const antenna = new THREE.Mesh(antennaGeo, this.mats.carbonSteel);
    antenna.position.set(-0.3, 0.52, 0.26);
    torsoGroup.add(antenna);

    // Radio LED Status Dot (Red/Green light)
    const ledGeo = new THREE.SphereGeometry(0.02, 8, 8);
    const led = new THREE.Mesh(ledGeo, new THREE.MeshBasicMaterial({ color: 0x22c55e }));
    led.position.set(-0.3, 0.4, 0.31);
    torsoGroup.add(led);

    // Tool Belt around waist with brass buckle
    const beltGeo = new THREE.CylinderGeometry(0.4, 0.4, 0.12, 16);
    const belt = new THREE.Mesh(beltGeo, this.mats.heroBoots);
    belt.position.set(0, -0.42, 0);
    torsoGroup.add(belt);

    const buckleGeo = new THREE.BoxGeometry(0.12, 0.14, 0.05);
    const buckle = new THREE.Mesh(buckleGeo, this.mats.brassValve);
    buckle.position.set(0, -0.42, 0.41);
    torsoGroup.add(buckle);

    this.heroGroup.add(torsoGroup);

    // -------------------------------------------------------------
    // 2. HEAD & REALISTIC SAFETY HARDHAT HELMET
    // -------------------------------------------------------------
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 2.22, 0);

    // Neck
    const neckGeo = new THREE.CylinderGeometry(0.14, 0.16, 0.22, 12);
    const neck = new THREE.Mesh(neckGeo, this.mats.heroSkin);
    neck.position.set(0, -0.11, 0);
    headGroup.add(neck);

    // Anatomical Head with sculpted facial features
    const headGeo = new THREE.SphereGeometry(0.26, 24, 20);
    this.heroHead = new THREE.Mesh(headGeo, this.mats.heroSkin);
    this.heroHead.scale.set(0.92, 1.05, 0.96);
    headGroup.add(this.heroHead);

    // Realistic Eyes (Sclera + Blue/Brown Iris + Pupil)
    [-0.085, 0.085].forEach((eyeX) => {
      // Sclera (White)
      const eyeWhite = new THREE.Mesh(
        new THREE.SphereGeometry(0.038, 12, 10),
        new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.1, metalness: 0.0 })
      );
      eyeWhite.scale.set(1.0, 0.7, 0.5);
      eyeWhite.position.set(eyeX, 0.05, 0.23);
      headGroup.add(eyeWhite);

      // Iris (Hazel / Dark Brown)
      const iris = new THREE.Mesh(
        new THREE.CircleGeometry(0.02, 12),
        new THREE.MeshStandardMaterial({ color: 0x3d2314, roughness: 0.2 })
      );
      iris.position.set(eyeX, 0.05, 0.252);
      headGroup.add(iris);

      // Pupil
      const pupil = new THREE.Mesh(
        new THREE.CircleGeometry(0.009, 10),
        new THREE.MeshBasicMaterial({ color: 0x050505 })
      );
      pupil.position.set(eyeX, 0.05, 0.254);
      headGroup.add(pupil);

      // Eyebrow
      const brow = new THREE.Mesh(
        new THREE.BoxGeometry(0.07, 0.015, 0.02),
        new THREE.MeshStandardMaterial({ color: 0x271911, roughness: 0.9 })
      );
      brow.position.set(eyeX, 0.09, 0.238);
      brow.rotation.z = eyeX > 0 ? -0.1 : 0.1;
      headGroup.add(brow);
    });

    // Realistic Sculpted Nose
    const noseGeo = new THREE.ConeGeometry(0.032, 0.08, 12);
    const nose = new THREE.Mesh(noseGeo, this.mats.heroSkin);
    nose.rotation.x = Math.PI / 2.3;
    nose.position.set(0, 0.01, 0.265);
    headGroup.add(nose);

    // Realistic Mouth / Lips
    const mouthGeo = new THREE.BoxGeometry(0.08, 0.02, 0.02);
    const mouth = new THREE.Mesh(mouthGeo, new THREE.MeshStandardMaterial({ color: 0xb57863, roughness: 0.6 }));
    mouth.position.set(0, -0.075, 0.235);
    headGroup.add(mouth);

    // Defined Chin & Jawline
    const chinGeo = new THREE.SphereGeometry(0.065, 12, 10);
    const chin = new THREE.Mesh(chinGeo, this.mats.heroSkin);
    chin.scale.set(1.0, 0.8, 1.1);
    chin.position.set(0, -0.12, 0.2);
    headGroup.add(chin);

    // Ears
    [-0.24, 0.24].forEach((ex) => {
      const earGeo = new THREE.SphereGeometry(0.055, 12, 10);
      const ear = new THREE.Mesh(earGeo, this.mats.heroSkin);
      ear.scale.set(0.45, 1.2, 0.8);
      ear.position.set(ex, 0, 0.02);
      headGroup.add(ear);
    });

    // Clear Protective Safety Glasses / Visor with realistic wrap frame
    const frameGeo = new THREE.BoxGeometry(0.4, 0.03, 0.22);
    const gFrame = new THREE.Mesh(frameGeo, this.mats.carbonSteel);
    gFrame.position.set(0, 0.085, 0.16);
    headGroup.add(gFrame);

    const gogglesGeo = new THREE.BoxGeometry(0.38, 0.1, 0.18);
    const goggles = new THREE.Mesh(gogglesGeo, this.mats.gogglesLens);
    goggles.position.set(0, 0.05, 0.17);
    headGroup.add(goggles);

    // Safety Hardhat Helmet Dome (Heavy-duty ribbed ABS)
    const helmetGeo = new THREE.SphereGeometry(0.31, 24, 18, 0, Math.PI * 2, 0, Math.PI * 0.52);
    this.heroHelmet = new THREE.Mesh(helmetGeo, this.mats.heroHelmet);
    this.heroHelmet.position.set(0, 0.07, -0.02);
    headGroup.add(this.heroHelmet);

    // Hardhat Center Reinforcing Spine Rib
    const spineGeo = new THREE.BoxGeometry(0.06, 0.08, 0.58);
    const spine = new THREE.Mesh(spineGeo, this.mats.heroHelmet);
    spine.position.set(0, 0.36, -0.02);
    headGroup.add(spine);

    // Hardhat Front Brim
    const brimGeo = new THREE.CylinderGeometry(0.4, 0.4, 0.04, 20, 1, false, -Math.PI / 3, (2 * Math.PI) / 3);
    const brim = new THREE.Mesh(brimGeo, this.mats.heroHelmet);
    brim.position.set(0, 0.07, 0.04);
    headGroup.add(brim);

    // Hardhat Flared Rear Neck Guard
    const rearBrimGeo = new THREE.CylinderGeometry(0.38, 0.42, 0.05, 16, 1, false, (2 * Math.PI) / 3, (2 * Math.PI) / 3);
    const rearBrim = new THREE.Mesh(rearBrimGeo, this.mats.heroHelmet);
    rearBrim.position.set(0, 0.05, -0.04);
    headGroup.add(rearBrim);

    // Hardhat Safety Logo Badge (Front Emblem)
    const emblemGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.02, 12);
    const emblem = new THREE.Mesh(emblemGeo, this.mats.brassValve);
    emblem.rotation.x = Math.PI / 2;
    emblem.position.set(0, 0.23, 0.3);
    headGroup.add(emblem);

    // LED Headlamp Torch mounted on Helmet Front
    const lampBodyGeo = new THREE.CylinderGeometry(0.06, 0.07, 0.12, 12);
    const lampBody = new THREE.Mesh(lampBodyGeo, this.mats.carbonSteel);
    lampBody.rotation.x = Math.PI / 2;
    lampBody.position.set(0, 0.14, 0.32);
    headGroup.add(lampBody);

    const lampLensGeo = new THREE.CylinderGeometry(0.055, 0.055, 0.02, 12);
    const lampLens = new THREE.Mesh(lampLensGeo, new THREE.MeshBasicMaterial({ color: 0xfffbea }));
    lampLens.rotation.x = Math.PI / 2;
    lampLens.position.set(0, 0.14, 0.38);
    headGroup.add(lampLens);

    // Headlamp PointLight casting real light ahead!
    const headlamp = new THREE.PointLight(0xfffaea, 1.4, 22, 1.6);
    headlamp.position.set(0, 0.14, 0.45);
    headGroup.add(headlamp);

    this.heroGroup.add(headGroup);

    // -------------------------------------------------------------
    // 3. ARMS WITH GLOVES & INSPECTION TABLET
    // -------------------------------------------------------------
    const shoulderOffset = 0.52;
    const armLen = 0.88;

    // Left Arm
    this.heroLeftArm = new THREE.Group();
    this.heroLeftArm.position.set(-shoulderOffset, 1.85, 0);

    const lUpperArmGeo = new THREE.CylinderGeometry(0.12, 0.1, armLen / 2, 12);
    const lUpperArm = new THREE.Mesh(lUpperArmGeo, this.mats.heroSuit);
    lUpperArm.position.set(0, -armLen / 4, 0);
    this.heroLeftArm.add(lUpperArm);

    const lForearmGeo = new THREE.CylinderGeometry(0.1, 0.08, armLen / 2, 12);
    const lForearm = new THREE.Mesh(lForearmGeo, this.mats.heroSuit);
    lForearm.position.set(0, -3 * (armLen / 4), 0);
    this.heroLeftArm.add(lForearm);

    const lGloveGeo = new THREE.BoxGeometry(0.14, 0.18, 0.14);
    const lGlove = new THREE.Mesh(lGloveGeo, this.mats.gloveLeather);
    lGlove.position.set(0, -armLen - 0.04, 0);
    this.heroLeftArm.add(lGlove);

    this.heroGroup.add(this.heroLeftArm);

    // Right Arm (Holding Inspector Tablet)
    this.heroRightArm = new THREE.Group();
    this.heroRightArm.position.set(shoulderOffset, 1.85, 0);

    const rUpperArmGeo = new THREE.CylinderGeometry(0.12, 0.1, armLen / 2, 12);
    const rUpperArm = new THREE.Mesh(rUpperArmGeo, this.mats.heroSuit);
    rUpperArm.position.set(0, -armLen / 4, 0);
    this.heroRightArm.add(rUpperArm);

    const rForearmGeo = new THREE.CylinderGeometry(0.1, 0.08, armLen / 2, 12);
    const rForearm = new THREE.Mesh(rForearmGeo, this.mats.heroSuit);
    rForearm.position.set(0, -3 * (armLen / 4), 0);
    this.heroRightArm.add(rForearm);

    const rGloveGeo = new THREE.BoxGeometry(0.14, 0.18, 0.14);
    const rGlove = new THREE.Mesh(rGloveGeo, this.mats.gloveLeather);
    rGlove.position.set(0, -armLen - 0.04, 0);
    this.heroRightArm.add(rGlove);

    // Industrial Digital Inspector Tablet in Right Hand
    const tabletGeo = new THREE.BoxGeometry(0.35, 0.03, 0.48);
    const tabletFrame = new THREE.Mesh(tabletGeo, this.mats.carbonSteel);
    tabletFrame.position.set(0.1, -armLen - 0.02, 0.22);
    tabletFrame.rotation.x = -Math.PI / 4;
    this.heroRightArm.add(tabletFrame);

    const tabletScreenMesh = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.42), this.mats.tabletScreen);
    tabletScreenMesh.rotation.x = -Math.PI / 2;
    tabletScreenMesh.position.set(0.1, -armLen - 0.005, 0.22);
    this.heroRightArm.add(tabletScreenMesh);

    this.heroGroup.add(this.heroRightArm);

    // -------------------------------------------------------------
    // 4. LEGS & STEEL-TOE SAFETY BOOTS
    // -------------------------------------------------------------
    const legLen = 0.95;
    const legOffset = 0.24;

    // Left Leg
    this.heroLeftLeg = new THREE.Group();
    this.heroLeftLeg.position.set(-legOffset, 0.95, 0);

    const lLegGeo = new THREE.CylinderGeometry(0.16, 0.14, legLen, 12);
    const lLeg = new THREE.Mesh(lLegGeo, this.mats.heroSuit);
    lLeg.position.set(0, -legLen / 2, 0);
    this.heroLeftLeg.add(lLeg);

    // Knee pad
    const lKneePad = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.18, 0.1), this.mats.heroBoots);
    lKneePad.position.set(0, -legLen / 2 + 0.1, 0.1);
    this.heroLeftLeg.add(lKneePad);

    // Reflective tape on calf
    const lTape = new THREE.Mesh(new THREE.CylinderGeometry(0.162, 0.162, 0.08, 12), this.mats.reflectiveSilver);
    lTape.position.set(0, -legLen / 2 - 0.15, 0);
    this.heroLeftLeg.add(lTape);

    // Boot
    const lBootGroup = new THREE.Group();
    lBootGroup.position.set(0, -legLen, 0.06);

    const lBootSole = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.12, 0.52), this.mats.heroBoots);
    lBootSole.position.set(0, -0.06, 0);
    lBootGroup.add(lBootSole);

    const lBootUpper = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.22, 0.42), this.mats.heroBoots);
    lBootUpper.position.set(0, 0.1, -0.02);
    lBootGroup.add(lBootUpper);

    const lBootCap = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 10, 0, Math.PI * 2, 0, Math.PI / 2), this.mats.carbonSteel);
    lBootCap.position.set(0, 0.02, 0.15);
    lBootGroup.add(lBootCap);

    this.heroLeftLeg.add(lBootGroup);
    this.heroGroup.add(this.heroLeftLeg);

    // Right Leg
    this.heroRightLeg = new THREE.Group();
    this.heroRightLeg.position.set(legOffset, 0.95, 0);

    const rLegGeo = new THREE.CylinderGeometry(0.16, 0.14, legLen, 12);
    const rLeg = new THREE.Mesh(rLegGeo, this.mats.heroSuit);
    rLeg.position.set(0, -legLen / 2, 0);
    this.heroRightLeg.add(rLeg);

    // Knee pad
    const rKneePad = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.18, 0.1), this.mats.heroBoots);
    rKneePad.position.set(0, -legLen / 2 + 0.1, 0.1);
    this.heroRightLeg.add(rKneePad);

    // Reflective tape on calf
    const rTape = new THREE.Mesh(new THREE.CylinderGeometry(0.162, 0.162, 0.08, 12), this.mats.reflectiveSilver);
    rTape.position.set(0, -legLen / 2 - 0.15, 0);
    this.heroRightLeg.add(rTape);

    // Boot
    const rBootGroup = new THREE.Group();
    rBootGroup.position.set(0, -legLen, 0.06);

    const rBootSole = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.12, 0.52), this.mats.heroBoots);
    rBootSole.position.set(0, -0.06, 0);
    rBootGroup.add(rBootSole);

    const rBootUpper = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.22, 0.42), this.mats.heroBoots);
    rBootUpper.position.set(0, 0.1, -0.02);
    rBootGroup.add(rBootUpper);

    const rBootCap = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 10, 0, Math.PI * 2, 0, Math.PI / 2), this.mats.carbonSteel);
    rBootCap.position.set(0, 0.02, 0.15);
    rBootGroup.add(rBootCap);

    this.heroRightLeg.add(rBootGroup);
    this.heroGroup.add(this.heroRightLeg);

    this.group.add(this.heroGroup);
  }

  // -------------------------------------------------------------
  // 11. QUESTS & PLANT INSPECTION SYSTEM
  // -------------------------------------------------------------
  private initQuests() {
    const ci = this.campusInfo;
    const blk = (id: string) => ci.blocks.find((b: any) => b.id === id);
    const at = (id: string) => {
      const b = blk(id);
      const sgn = b.side === 'left' ? 1 : -1;
      return new THREE.Vector3(sgn * (ci.AH + 6), 0, (b.minZ + b.maxZ) / 2);
    };
    const k401 = ci.deckBays.find((x: any) => x.key === 'K-401');
    const Q = (id: string, titleAr: string, titleEn: string, tag: string, pos: THREE.Vector3, r: number, d: string, minY?: number): GameQuest =>
      ({ id, titleAr, titleEn, targetTag: tag, position: pos, targetRadius: r, completed: false, descriptionAr: d, minY });
    this.quests = [
      Q('q_reception', '1. تسجيل الدخول في بوابة الاستعلامات', '1. Check-in at Plant Reception', 'Gate_Reception',
        new THREE.Vector3(0, 0, ci.Z_GATE), 12, 'تأكيد ارتداء معدات الوقاية (PPE) ثم امشِ في الشارع الرئيسي.'),
      Q('q_cooling', '2. برج التبريد (يمين الشارع) ومضخات الماء', '2. Cooling Tower & Pumps', 'cooling_tower',
        at('cooling'), 30, 'فحص حوض الماء البارد والمراوح ومضخات ماء التبريد.'),
      Q('q_sec1', '3. القسم الأول (يسار الشارع): الهيتر H-101 وإزالة الكبريت والمفاعل الأولي والمدخنة', '3. Section 1 — Reforming', 'h-101',
        at('sec1'), 30, 'تفقد الهيتر ومفاعلي إزالة الكبريت والفرن الأولي ومنطقة الحمل الحراري والمدخنة.'),
      Q('q_sec2', '4. القسم الثاني: برجا كاتاكارب T-201 و T-202', '4. Section 2 — CO2 Removal', 't-201',
        at('sec2'), 30, 'مراقبة مستوى المحلول في T-201 وضغط التجريد في T-202.'),
      Q('q_sec4', '5. القسم الرابع (مقابل القسمين 1 و 2): مفاعل التخليق R-401', '5. Section 4 — Synthesis', 'r-401',
        at('sec4'), 30, 'فحص المفاعل R-401 والمكثف E-412 ومستقبل التثليج V-408.'),
      Q('q_comp', '6. اصعد الدرج إلى قسم الضاغطات وافحص K-401 و K-301', '6. Compressor Deck', 'k-401',
        new THREE.Vector3(ci.hallCx, 10.5, ci.hallCz + (k401 ? k401.z : 0)), 26, 'اصعد أحد السلالم الثلاثة وتفقد الضاغطات الخمس وبطاقة بيانات كل واحدة.', 5),
      Q('q_ccr', '7. غرفة السيطرة: شاشات الأقسام ومكتب مسؤول قسم الأمونيا', '7. Central Control Room', 'control_room',
        new THREE.Vector3(0, 0, ci.Z_CCR + 24), 20, 'ادخل غرفة السيطرة وتجول بين شاشات الأقسام ومناطق الجلوس.'),
    ];
  }

  // -------------------------------------------------------------
  // 12. INPUTS & CONTROLS (DESKTOP + MOBILE TOUCH)
  // -------------------------------------------------------------
  private setupEventListeners() {
    window.addEventListener('keydown', (e) => {
      if (!this.isActive) return;
      this.keys[e.key.toLowerCase()] = true;
      if (e.key === 'Shift') this.isRunning = true;
      if (e.key.toLowerCase() === 'e') this.interactWithNearbyEquipment();
      if (e.key.toLowerCase() === 'v' || e.key.toLowerCase() === 'c') this.toggleCameraMode();
    });

    window.addEventListener('keyup', (e) => {
      if (!this.isActive) return;
      this.keys[e.key.toLowerCase()] = false;
      if (e.key === 'Shift') this.isRunning = false;
    });

    // Mouse & Touch Orbiting for 3rd-person camera
    this.domElement.addEventListener('pointerdown', (e) => {
      if (!this.isActive) return;
      this.isPointerDown = true;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;
      this.initAudioContext();
    });

    window.addEventListener('pointermove', (e) => {
      if (!this.isActive || !this.isPointerDown) return;
      const dx = e.clientX - this.lastPointerX;
      const dy = e.clientY - this.lastPointerY;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;

      // Orbit camera around hero
      this.camYaw -= dx * 0.005;
      this.camPitch = Math.max(0.05, Math.min(Math.PI / 2 - 0.1, this.camPitch - dy * 0.005));
    });

    window.addEventListener('pointerup', () => {
      this.isPointerDown = false;
    });

    // Mouse Wheel zoom
    this.domElement.addEventListener('wheel', (e) => {
      if (!this.isActive) return;
      e.preventDefault();
      this.camDistance = Math.max(4.0, Math.min(22.0, this.camDistance + e.deltaY * 0.01));
    }, { passive: false });
  }

  // -------------------------------------------------------------
  // 13. SOUND SYNTHESIZER (WEB AUDIO API)
  // -------------------------------------------------------------
  private initAudioContext() {
    if (this.audioCtx) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      this.audioCtx = new AudioCtx();

      // Continuous Industrial Plant Hum (Brown noise + filtered low drone)
      const bufferSize = this.audioCtx.sampleRate * 2;
      const noiseBuffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        output[i] = (lastOut + 0.02 * white) / 1.02;
        lastOut = output[i];
        output[i] *= 1.8;
      }

      const whiteNoise = this.audioCtx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      const filter = this.audioCtx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 160;

      this.ambientSoundGain = this.audioCtx.createGain();
      this.ambientSoundGain.gain.value = this.isMuted ? 0 : 0.28;

      whiteNoise.connect(filter);
      filter.connect(this.ambientSoundGain);
      this.ambientSoundGain.connect(this.audioCtx.destination);
      whiteNoise.start();
    } catch (_) {}
  }

  private playFootstepSound() {
    if (!this.audioCtx || this.isMuted) return;
    const now = performance.now();
    if (now - this.lastFootstepTime < (this.isRunning ? 260 : 380)) return;
    this.lastFootstepTime = now;

    try {
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();
      osc.type = 'sine';
      // Low thud on concrete/asphalt or metal grating
      const freq = this.currentElevation > 5 ? 240 : 120;
      osc.frequency.setValueAtTime(freq, this.audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(30, this.audioCtx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.08, this.audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0.001, this.audioCtx.currentTime + 0.08);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);
      osc.start();
      osc.stop(this.audioCtx.currentTime + 0.09);
    } catch (_) {}
  }

  private playSuccessChime() {
    if (!this.audioCtx || this.isMuted) return;
    try {
      [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
        const osc = this.audioCtx!.createOscillator();
        const gain = this.audioCtx!.createGain();
        osc.type = 'triangle';
        osc.frequency.value = freq;
        const start = this.audioCtx!.currentTime + idx * 0.09;
        gain.gain.setValueAtTime(0.12, start);
        gain.gain.exponentialRampToValueAtTime(0.001, start + 0.35);
        osc.connect(gain);
        gain.connect(this.audioCtx!.destination);
        osc.start(start);
        osc.stop(start + 0.36);
      });
    } catch (_) {}
  }

  // -------------------------------------------------------------
  // 14. PHYSICS, STAIR CLIMBING & HERO MOVEMENT UPDATE
  // -------------------------------------------------------------
  public update(delta: number) {
    if (!this.isActive) return;

    // Movement calculation
    let moveForward = 0;
    let turnSide = 0;

    // Keyboard inputs:
    // W/Up: Move forward, S/Down: Move backward
    // A/Left: Strafe left (-X in screen relative space), D/Right: Strafe right (+X)
    if (this.keys['w'] || this.keys['arrowup']) moveForward += 1;
    if (this.keys['s'] || this.keys['arrowdown']) moveForward -= 1;
    if (this.keys['a'] || this.keys['arrowleft']) turnSide -= 1;
    if (this.keys['d'] || this.keys['arrowright']) turnSide += 1;

    // Touch Virtual Joystick input
    if (Math.abs(this.joystickVec.y) > 0.1) moveForward += this.joystickVec.y;
    if (Math.abs(this.joystickVec.x) > 0.1) turnSide += this.joystickVec.x;

    this.isMoving = Math.abs(moveForward) > 0.05 || Math.abs(turnSide) > 0.05;

    // Determine target movement direction relative to camera angle
    // In our coordinate space with camera facing along camYaw:
    // forward is +Z relative to camYaw, right is +X relative to camYaw.
    if (this.isMoving) {
      // Notice: turnSide > 0 is Right, turnSide < 0 is Left
      // atan2(turnSide, moveForward) yields positive angle for right, negative for left
      const moveAngle = Math.atan2(-turnSide, moveForward); // D = يمين الشاشة
      const targetRotationY = this.camYaw + moveAngle;
      // Smoothly rotate hero towards moving heading
      this.heroRotationY = THREE.MathUtils.lerp(this.heroRotationY, targetRotationY, Math.min(1.0, 14 * delta));
      this.heroGroup.rotation.y = this.heroRotationY;

      // Calculate speed
      const baseSpeed = this.isRunning ? 18 : 8.5;
      const moveSpeed = baseSpeed * Math.min(1.0, Math.hypot(moveForward, turnSide));

      this.heroPosition.x += Math.sin(targetRotationY) * moveSpeed * delta;
      this.heroPosition.z += Math.cos(targetRotationY) * moveSpeed * delta;

      // Bound player within plant perimeters (open spacious exploration bounds)
      this.heroPosition.x = Math.max(this.worldBounds.minX, Math.min(this.worldBounds.maxX, this.heroPosition.x));
      this.heroPosition.z = Math.max(this.worldBounds.minZ, Math.min(this.worldBounds.maxZ, this.heroPosition.z));

      // Play Footsteps
      this.playFootstepSound();

      // Walk animation cycle
      this.walkAnimPhase += (this.isRunning ? 14 : 8) * delta;
      const legAngle = Math.sin(this.walkAnimPhase) * (this.isRunning ? 0.75 : 0.45);
      const armAngle = -legAngle;

      this.heroLeftLeg.rotation.x = legAngle;
      this.heroRightLeg.rotation.x = -legAngle;
      this.heroLeftArm.rotation.x = armAngle;
      this.heroRightArm.rotation.x = -armAngle;
      this.heroTorso.position.y = 1.5 + Math.abs(Math.sin(this.walkAnimPhase * 2)) * 0.06;
    } else {
      // Idle pose with subtle breathing
      this.walkAnimPhase += 2.0 * delta;
      this.heroLeftLeg.rotation.x = 0;
      this.heroRightLeg.rotation.x = 0;
      this.heroLeftArm.rotation.x = 0;
      this.heroRightArm.rotation.x = 0;
      this.heroTorso.position.y = 1.5 + Math.sin(this.walkAnimPhase) * 0.02;
    }

    // ---------------------------------------------------------
    // VERTICAL STAIR CLIMBING & ELEVATED MEZZANINE DECK PHYSICS
    // ---------------------------------------------------------
    let targetY = 0; // Default Ground level

    // Check if hero is on any of the 3 staircases to the elevated 2nd floor
    let onStair = false;
    for (const stair of this.staircases) {
      if (
        this.heroPosition.x >= stair.minX &&
        this.heroPosition.x <= stair.maxX &&
        this.heroPosition.z >= stair.minZ &&
        this.heroPosition.z <= stair.maxZ
      ) {
        onStair = true;
        // Interpolate elevation based on Z or X position along the stair
        const raw = (this.heroPosition.x - stair.minX) / (stair.maxX - stair.minX);
        const progress = Math.max(0, Math.min(1, stair.dir > 0 ? raw : 1 - raw));
        targetY = THREE.MathUtils.lerp(stair.startY, stair.endY, progress);
        break;
      }
    }

    // Check if hero is walking on the Elevated 2nd-Floor Compressor Deck (height 10.5m)
    if (!onStair) {
      if (
        this.heroPosition.x >= this.deckBounds.minX &&
        this.heroPosition.x <= this.deckBounds.maxX &&
        this.heroPosition.z >= this.deckBounds.minZ &&
        this.heroPosition.z <= this.deckBounds.maxZ &&
        this.heroPosition.y > 4.0 // Must have climbed up via stairs
      ) {
        targetY = this.deckBounds.height;
      } else if (
        this.heroPosition.x >= this.crBounds.minX && this.heroPosition.x <= this.crBounds.maxX &&
        this.heroPosition.z >= this.crBounds.minZ && this.heroPosition.z <= this.crBounds.maxZ
      ) {
        targetY = this.crBounds.y;
      }
    }

    // Smoothly adjust hero elevation
    this.heroPosition.y = THREE.MathUtils.lerp(this.heroPosition.y, targetY, 14 * delta);
    this.currentElevation = this.heroPosition.y;
    this.heroGroup.position.copy(this.heroPosition);

    // ---------------------------------------------------------
    // CAMERA FOLLOW RIG (3rd Person & 1st Person)
    // ---------------------------------------------------------
    if (this.cameraMode === 'third_person') {
      const offsetX = Math.sin(this.camYaw) * Math.cos(this.camPitch) * this.camDistance;
      const offsetY = Math.sin(this.camPitch) * this.camDistance;
      const offsetZ = Math.cos(this.camYaw) * Math.cos(this.camPitch) * this.camDistance;

      this.targetCamPos.set(
        this.heroPosition.x - offsetX,
        this.heroPosition.y + 2.4 + offsetY,
        this.heroPosition.z - offsetZ
      );
      this.targetCamLookAt.set(this.heroPosition.x, this.heroPosition.y + 2.1, this.heroPosition.z);

      this.camera.position.lerp(this.targetCamPos, 10 * delta);
      this.camera.lookAt(this.targetCamLookAt);
    } else {
      // First-person view (Inside helmet)
      this.targetCamPos.set(
        this.heroPosition.x,
        this.heroPosition.y + 2.36,
        this.heroPosition.z
      );
      this.targetCamLookAt.set(
        this.heroPosition.x + Math.sin(this.camYaw) * 10,
        this.heroPosition.y + 2.36 - Math.sin(this.camPitch) * 10,
        this.heroPosition.z + Math.cos(this.camYaw) * 10
      );
      this.camera.position.copy(this.targetCamPos);
      this.camera.lookAt(this.targetCamLookAt);
    }

    // ---------------------------------------------------------
    // MASTER 3D MODULES ANIMATION & INTERNAL DYNAMICS (High Performance)
    // ---------------------------------------------------------
    if (this.coolingTower) {
      this.coolingTower.update(delta);
    }
    if (this.reforming100) {
      this.reforming100.update(delta);
    }
    if (this.co2Removal200) {
      this.co2Removal200.update(delta);
    }
    if (this.synthesis400) {
      this.synthesis400.update(delta);
    }
    if (this.syngasK301) {
      this.syngasK301.update(delta);
    }
    if (this.steamSystem) this.steamSystem.update(delta);
    if (this.campusControlRoom) this.campusControlRoom.update(this.clock.getElapsedTime());
    animateDrains(delta);
    this.labelFrame++;
    if (this.labelFrame % 6 === 0) this.updateLabels();

    // Proximity and mini-map checks every 3 frames for zero CPU overhead
    this.frameCounter = (this.frameCounter || 0) + 1;
    if (this.frameCounter % 3 === 0) {
      this.checkEquipmentProximity();
      this.checkQuestProgress();
      this.updateMiniMap();
    }
  }

  private frameCounter: number = 0;

  private checkEquipmentProximity() {
    let nearest: EquipmentInfo | null = null;
    let minDist = 16.0;
    const onDeck = this.heroPosition.y > 4;
    for (const w of this.worldEquip) {
      if (w.deck !== onDeck) continue;
      const dist = Math.hypot(this.heroPosition.x - w.x, this.heroPosition.z - w.z);
      if (dist < minDist) {
        minDist = dist;
        nearest = w.eq;
      }
    }

    this.currentNearbyEquipment = nearest;

    if (this.inspectPrompt) {
      if (nearest) {
        this.inspectPrompt.style.display = 'flex';
        this.inspectPrompt.innerHTML = `
          <div style="font-size:18px;">🔍</div>
          <div>
            <b>${nearest.tag}</b>: ${nearest.arabicName}<br>
            <span style="font-size:11px;color:#94a3b8;">اضغط [E] أو انقر هنا لتعديل/حفظ/حذف المعادلة والضغط والحرارة</span>
          </div>
        `;
      } else {
        this.inspectPrompt.style.display = 'none';
      }
    }
  }

  private checkQuestProgress() {
    const activeQuest = this.quests[this.currentQuestIndex];
    if (!activeQuest || activeQuest.completed) return;

    const dist = Math.hypot(
      this.heroPosition.x - activeQuest.position.x,
      this.heroPosition.z - activeQuest.position.z
    );

    if (activeQuest.minY && this.heroPosition.y < activeQuest.minY) return;
    if (dist < activeQuest.targetRadius) {
      activeQuest.completed = true;
      this.playSuccessChime();
      if (this.onQuestCompletedCallback) {
        this.onQuestCompletedCallback(activeQuest);
      }
      this.currentQuestIndex++;
      this.updateQuestBanner();
    }
  }

  public interactWithNearbyEquipment() {
    if (!this.currentNearbyEquipment) return;
    this.playSuccessChime();
    this.inspectedTags.add(this.currentNearbyEquipment.tag);
    if (this.onInspectCallback) {
      this.onInspectCallback(this.currentNearbyEquipment);
    }
    // Directly open the chemical equations, pressure, temperature editor & manager!
    EquipmentCustomDataManager.getInstance().openEditor(this.currentNearbyEquipment);
  }

  public toggleCameraMode() {
    this.cameraMode = this.cameraMode === 'third_person' ? 'first_person' : 'third_person';
    // Hide/show hero mesh when in first person
    this.heroHead.visible = this.cameraMode === 'third_person';
    this.heroHelmet.visible = this.cameraMode === 'third_person';
  }

  // -------------------------------------------------------------
  // 15. GAME HUD (MINIMAP, QUEST BANNER, TOUCH CONTROLS)
  // -------------------------------------------------------------
  private createGameHUD() {
    // Remove old HUD if exists
    const oldHud = document.getElementById('ammonia-game-hud');
    if (oldHud) oldHud.remove();

    this.hudContainer = document.createElement('div');
    this.hudContainer.id = 'ammonia-game-hud';
    this.hudContainer.style.cssText = `
      position: absolute;
      inset: 0;
      pointer-events: none;
      z-index: 100;
      font-family: 'Cairo', system-ui, -apple-system, sans-serif;
      display: none;
    `;

    // 1. Sleek Floating Top Action Bar
    const topBar = document.createElement('div');
    topBar.style.cssText = `
      position: absolute;
      top: 10px;
      left: 10px;
      right: 10px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      z-index: 105;
      pointer-events: none;
    `;

    // Right side: Main Home Return + Title Badge
    const rightBox = document.createElement('div');
    rightBox.style.cssText = `
      display: flex;
      align-items: center;
      gap: 8px;
      pointer-events: auto;
    `;

    const homeBtn = document.createElement('button');
    homeBtn.innerHTML = '<span>🏠</span><span>الرئيسية</span>';
    homeBtn.style.cssText = `
      background: rgba(15, 23, 42, 0.9);
      border: 1px solid #38bdf8;
      color: #ffffff;
      padding: 6px 14px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 800;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.5);
      font-family: inherit;
    `;
    homeBtn.addEventListener('click', () => {
      if ((window as any).closeAllOverlaysAndGoHome) {
        (window as any).closeAllOverlaysAndGoHome();
      }
    });
    rightBox.appendChild(homeBtn);

    const badge = document.createElement('div');
    badge.innerHTML = '<span>🎮</span><span style="color:#38bdf8;font-weight:900;">Ammonia Game 3D</span>';
    badge.style.cssText = `
      background: rgba(15, 23, 42, 0.9);
      border: 1px solid rgba(56, 189, 248, 0.4);
      color: #ffffff;
      padding: 6px 12px;
      border-radius: 8px;
      font-size: 11.5px;
      display: flex;
      align-items: center;
      gap: 6px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.4);
    `;
    rightBox.appendChild(badge);
    topBar.appendChild(rightBox);

    // Left side: Utility Toggles (Camera mode, Mute, Lighting)
    const leftBox = document.createElement('div');
    leftBox.style.cssText = `
      display: flex;
      align-items: center;
      gap: 6px;
      pointer-events: auto;
    `;

    const camToggleBtn = document.createElement('button');
    camToggleBtn.innerHTML = '👁️ منظور';
    camToggleBtn.title = 'تبديل منظور الكاميرا بين الشخص الأول والثالث (V)';
    camToggleBtn.style.cssText = `
      background: rgba(15, 23, 42, 0.9);
      border: 1px solid #a855f7;
      color: #d8b4fe;
      padding: 6px 10px;
      border-radius: 8px;
      font-size: 11px;
      font-weight: bold;
      cursor: pointer;
      font-family: inherit;
    `;
    camToggleBtn.addEventListener('click', () => this.toggleCameraMode());
    leftBox.appendChild(camToggleBtn);

    const audioToggleBtn = document.createElement('button');
    audioToggleBtn.innerHTML = '🔊 صوت';
    audioToggleBtn.title = 'تشغيل/كتم أكسجين المحاكاة والأصوات الصناعية';
    audioToggleBtn.style.cssText = `
      background: rgba(15, 23, 42, 0.9);
      border: 1px solid #10b981;
      color: #6ee7b7;
      padding: 6px 10px;
      border-radius: 8px;
      font-size: 11px;
      font-weight: bold;
      cursor: pointer;
      font-family: inherit;
    `;
    audioToggleBtn.addEventListener('click', () => {
      this.isMuted = !this.isMuted;
      audioToggleBtn.innerHTML = this.isMuted ? '🔇 مكتوم' : '🔊 صوت';
    });
    leftBox.appendChild(audioToggleBtn);

    const tpBtn = document.createElement('button');
    tpBtn.innerHTML = '🚀 انتقال سريع';
    tpBtn.style.cssText = `background: rgba(15,23,42,0.9);border:1px solid #f59e0b;color:#fcd34d;padding:6px 10px;border-radius:8px;font-size:11px;font-weight:bold;cursor:pointer;font-family:inherit;`;
    const tpMenu = document.createElement('div');
    tpMenu.style.cssText = `position:absolute;top:44px;left:10px;display:none;flex-direction:column;gap:4px;background:rgba(15,23,42,0.95);border:1px solid #f59e0b;border-radius:10px;padding:8px;pointer-events:auto;z-index:120;max-height:60vh;overflow:auto;`;
    this.waypoints.forEach((wp) => {
      const b = document.createElement('button');
      b.textContent = wp.nameAr;
      b.style.cssText = `background:#1e293b;color:#fff;border:1px solid #334155;border-radius:6px;padding:6px 10px;font-size:12px;cursor:pointer;text-align:right;font-family:inherit;`;
      b.addEventListener('click', () => { this.teleportTo(wp.id); tpMenu.style.display = 'none'; });
      tpMenu.appendChild(b);
    });
    tpBtn.addEventListener('click', () => { tpMenu.style.display = tpMenu.style.display === 'none' ? 'flex' : 'none'; });
    leftBox.appendChild(tpBtn);
    this.hudContainer.appendChild(tpMenu);

    topBar.appendChild(leftBox);
    this.hudContainer.appendChild(topBar);

    // 2. Ultra-clean Minimal Top Quest Pill with Toggle
    this.questBanner = document.createElement('div');
    this.questBanner.style.cssText = `
      position: absolute;
      top: 50px;
      left: 10px;
      background: rgba(15, 23, 42, 0.85);
      backdrop-filter: blur(8px);
      border: 1px solid rgba(56, 189, 248, 0.4);
      border-radius: 8px;
      padding: 6px 12px;
      color: #ffffff;
      text-align: right;
      box-shadow: 0 4px 14px rgba(0,0,0,0.4);
      pointer-events: auto;
      max-width: 260px;
      z-index: 104;
      transition: all 0.2s ease;
    `;
    this.hudContainer.appendChild(this.questBanner);

    // 3. Inspection Prompt Button (Bottom Center Pill)
    this.inspectPrompt = document.createElement('div');
    this.inspectPrompt.style.cssText = `
      position: absolute;
      bottom: 85px;
      left: 50%;
      transform: translateX(-50%);
      background: linear-gradient(135deg, rgba(2, 132, 199, 0.95), rgba(37, 99, 235, 0.95));
      color: #ffffff;
      border: 1.5px solid #38bdf8;
      border-radius: 30px;
      padding: 8px 20px;
      display: none;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      pointer-events: auto;
      box-shadow: 0 4px 18px rgba(2,132,199,0.6);
      font-size: 12px;
      text-align: right;
      z-index: 106;
    `;
    this.inspectPrompt.addEventListener('click', () => {
      this.interactWithNearbyEquipment();
    });
    this.hudContainer.appendChild(this.inspectPrompt);

    // 4. Compact Mini-Map in Top Right (Collapsible)
    const mapCard = document.createElement('div');
    const isSmallScreen = window.innerWidth < 768;
    const mapDim = isSmallScreen ? 85 : 110;

    mapCard.style.cssText = `
      position: absolute;
      top: 50px;
      right: 10px;
      width: ${mapDim}px;
      height: ${Math.round(mapDim * 1.7)}px;
      background: rgba(15, 23, 42, 0.85);
      backdrop-filter: blur(8px);
      border: 1.5px solid rgba(56, 189, 248, 0.5);
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 14px rgba(0,0,0,0.4);
      pointer-events: auto;
      z-index: 104;
    `;
    this.miniMapCanvas = document.createElement('canvas');
    this.miniMapCanvas.width = mapDim;
    this.miniMapCanvas.height = Math.round(mapDim * 1.7);
    this.miniMapCtx = this.miniMapCanvas.getContext('2d')!;
    mapCard.appendChild(this.miniMapCanvas);
    this.hudContainer.appendChild(mapCard);

    // 5. Mobile Virtual Touch Controls (Left Joystick & Right Action Buttons)
    const isMobile = window.innerWidth < 1024 || /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    if (isMobile) {
      this.createTouchControls();
    }
    // 6. Desktop Quick Controls Hint Bar
    const hintBar = document.createElement('div');
    hintBar.style.cssText = `
      position: absolute;
      bottom: 12px;
      left: 14px;
      background: rgba(15, 23, 42, 0.82);
      border: 1px solid rgba(51, 65, 85, 0.7);
      border-radius: 8px;
      padding: 4px 10px;
      font-size: 10px;
      color: #94a3b8;
      pointer-events: auto;
      z-index: 104;
    `;
    hintBar.innerHTML = `
      <b style="color:#38bdf8;">WASD</b> تحرك | <b style="color:#facc15;">Shift</b> ركض | <b style="color:#00e5aa;">E</b> فحص | <b style="color:#a855f7;">V</b> منظور كاميرا
    `;
    this.hudContainer.appendChild(hintBar);

    this.domElement.parentElement?.appendChild(this.hudContainer);
    this.updateQuestBanner();
  }

  private createTouchControls() {
    // Virtual Joystick on bottom left
    const joyZone = document.createElement('div');
    joyZone.style.cssText = `
      position: absolute;
      bottom: 24px;
      left: 20px;
      width: 105px;
      height: 105px;
      background: rgba(15, 23, 42, 0.65);
      border: 2px solid rgba(56, 189, 248, 0.65);
      border-radius: 50%;
      pointer-events: auto;
      touch-action: none;
      z-index: 108;
    `;
    const joyKnob = document.createElement('div');
    joyKnob.style.cssText = `
      position: absolute;
      top: 30px;
      left: 30px;
      width: 45px;
      height: 45px;
      background: #38bdf8;
      border-radius: 50%;
      box-shadow: 0 0 14px rgba(56,189,248,0.9);
      pointer-events: none;
    `;
    joyZone.appendChild(joyKnob);

    let joyTouchId: number | null = null;
    let joyCenter = { x: 0, y: 0 };

    joyZone.addEventListener('touchstart', (e) => {
      const touch = e.changedTouches[0];
      joyTouchId = touch.identifier;
      const rect = joyZone.getBoundingClientRect();
      joyCenter = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    }, { passive: true });

    joyZone.addEventListener('touchmove', (e) => {
      for (let i = 0; i < e.changedTouches.length; i++) {
        const touch = e.changedTouches[i];
        if (touch.identifier === joyTouchId) {
          const dx = touch.clientX - joyCenter.x;
          const dy = touch.clientY - joyCenter.y;
          const dist = Math.min(40, Math.hypot(dx, dy));
          const angle = Math.atan2(dy, dx);

          joyKnob.style.transform = `translate(${Math.cos(angle) * dist}px, ${Math.sin(angle) * dist}px)`;
          this.joystickVec.x = (Math.cos(angle) * dist) / 40;
          this.joystickVec.y = -(Math.sin(angle) * dist) / 40;
        }
      }
    }, { passive: true });

    const resetJoy = () => {
      joyTouchId = null;
      joyKnob.style.transform = 'translate(0px, 0px)';
      this.joystickVec.set(0, 0);
    };

    joyZone.addEventListener('touchend', resetJoy);
    joyZone.addEventListener('touchcancel', resetJoy);
    this.hudContainer?.appendChild(joyZone);

    // Action Buttons on bottom right
    const actionGroup = document.createElement('div');
    actionGroup.style.cssText = `
      position: absolute;
      bottom: 24px;
      right: 20px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      pointer-events: auto;
      z-index: 108;
    `;

    const sprintBtn = document.createElement('button');
    sprintBtn.textContent = '🏃‍♂️ ركض';
    sprintBtn.style.cssText = `
      width: 58px;
      height: 58px;
      border-radius: 50%;
      background: rgba(245, 158, 11, 0.9);
      color: #fff;
      font-weight: bold;
      border: 2px solid #facc15;
      font-size: 12px;
      font-family: inherit;
      box-shadow: 0 4px 12px rgba(245, 158, 11, 0.5);
    `;
    sprintBtn.addEventListener('touchstart', (e) => { e.preventDefault(); this.isRunning = true; });
    sprintBtn.addEventListener('touchend', (e) => { e.preventDefault(); this.isRunning = false; });
    actionGroup.appendChild(sprintBtn);

    const camBtn = document.createElement('button');
    camBtn.textContent = '📷 كاميرا';
    camBtn.style.cssText = `
      width: 58px;
      height: 58px;
      border-radius: 50%;
      background: rgba(168, 85, 247, 0.9);
      color: #fff;
      font-weight: bold;
      border: 2px solid #c084fc;
      font-size: 12px;
      font-family: inherit;
      box-shadow: 0 4px 12px rgba(168, 85, 247, 0.5);
    `;
    camBtn.addEventListener('click', () => { this.toggleCameraMode(); });
    actionGroup.appendChild(camBtn);

    this.hudContainer?.appendChild(actionGroup);
  }

  private updateQuestBanner() {
    if (!this.questBanner) return;
    const activeQuest = this.quests[this.currentQuestIndex];
    if (activeQuest) {
      this.questBanner.innerHTML = `
        <div style="font-size:10px;color:#38bdf8;font-weight:bold;letter-spacing:0.5px;">الهدف الحالي في الجولة</div>
        <div style="font-size:13px;font-weight:bold;margin:1px 0;color:#ffffff;">${activeQuest.titleAr}</div>
        <div style="font-size:10.5px;color:#cbd5e1;line-height:1.3;">${activeQuest.descriptionAr}</div>
      `;
    } else {
      this.questBanner.innerHTML = `
        <div style="font-size:14px;color:#22c55e;font-weight:bold;">🎉 اكتملت جولة التفتيش بالكامل!</div>
        <div style="font-size:10.5px;color:#cbd5e1;">تم فحص جميع الأقسام وطابق الضاغطات الخمسة وغرفة السيطرة بنجاح.</div>
      `;
    }
  }

  private updateMiniMap() {
    if (!this.miniMapCtx || !this.miniMapCanvas) return;
    const ctx = this.miniMapCtx;
    const w = this.miniMapCanvas.width;
    const h = this.miniMapCanvas.height;
    const wb = this.worldBounds;
    ctx.fillStyle = '#060d17';
    ctx.fillRect(0, 0, w, h);
    // forward (+Z) is UP, screen-right is -X (same as the player's view)
    const sx = w / (wb.maxX - wb.minX), sz = h / (wb.maxZ - wb.minZ);
    const mx = (x: number) => (wb.maxX - x) * sx;
    const my = (z: number) => h - (z - wb.minZ) * sz;
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(mx(13), 0, 26 * sx, h);
    this.zones.forEach((zn) => {
      ctx.fillStyle = zn.color + '88';
      ctx.fillRect(mx(zn.maxX), my(zn.maxZ), (zn.maxX - zn.minX) * sx, (zn.maxZ - zn.minZ) * sz);
    });
    const q = this.quests[this.currentQuestIndex];
    if (q) {
      ctx.fillStyle = '#facc15';
      ctx.beginPath(); ctx.arc(mx(q.position.x), my(q.position.z), 4, 0, Math.PI * 2); ctx.fill();
    }
    const hX = mx(this.heroPosition.x), hY = my(this.heroPosition.z);
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath(); ctx.arc(hX, hY, 3.5, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(hX, hY);
    ctx.lineTo(hX - Math.sin(this.heroRotationY) * 9, hY - Math.cos(this.heroRotationY) * 9);
    ctx.stroke();
  }

  // -------------------------------------------------------------
  // 16. ACTIVATION & DEACTIVATION
  // -------------------------------------------------------------
  public activate() {
    this.isActive = true;
    this.group.visible = true;
    if (this.hudContainer) this.hudContainer.style.display = 'block';
    const overlay = document.getElementById('view3d-overlay');
    if (overlay) overlay.classList.add('ammonia-game-active');
    this.clock.start();
    this.initAudioContext();
    const fog = this.scene.fog as any;
    if (fog && fog.density !== undefined) { this.savedFogDensity = fog.density; fog.density = 0.0009; }
  }

  public deactivate() {
    this.isActive = false;
    this.group.visible = false;
    if (this.hudContainer) this.hudContainer.style.display = 'none';
    const overlay = document.getElementById('view3d-overlay');
    if (overlay) overlay.classList.remove('ammonia-game-active');
    const fog = this.scene.fog as any;
    if (fog && this.savedFogDensity !== undefined) fog.density = this.savedFogDensity;
  }

  public isControllingCamera(): boolean {
    return this.isActive;
  }
}

import * as THREE from 'three';
import { MASTER_EQUIPMENT_DATA } from './PlantDiagramData';
import {
  createFloorTileTexture, createCeilingTexture, createVintageGreenPanelTexture,
  createDCSMonitorTexture, createIraqiFlagTexture,
} from './TextureGenerator';
import { CampusMats, canvasPlane, makeLabelSprite, lookupName } from './CampusKit';

/**
 * غرفة السيطرة المركزية (CCR) — مبنى كبير بسقف عالٍ (15م)
 *  • واجهة زجاجية تطل على المعمل
 *  • شاشة تعريف كبيرة مقابل كل قسم (على نفس الجهة التي يقع فيها القسم)
 *  • محطات تشغيل (كراسي + ميز + شاشات DCS) تحت كل شاشة
 *  • منصة مكتب مسؤول قسم الأمونيا + كرسي
 *  • لوحة الرسم البياني اليابانية (MHI) على الجدار الخلفي
 *  • مناطق جلوس (صالات) وطاولة اجتماعات ومحطة قهوة
 */

export interface PlantSectionInfo {
  id: string;
  num: string;
  nameAr: string;
  nameEn: string;
  side: 'left' | 'right';  // بالنسبة لمن يمشي في الشارع الرئيسي نحو غرفة السيطرة
  accent: string;
  dwg: string;
  items: [string, string][];
  kpiTags: string[];
}

export const PLANT_SECTIONS: PlantSectionInfo[] = [
  {
    id: 'cooling', num: 'UTILITY', nameAr: 'برج التبريد ومضخات الماء', nameEn: 'COOLING TOWER & CIRCULATION PUMPS',
    side: 'right', accent: '#38bdf8', dwg: 'COOLING WATER SYSTEM',
    items: [['CT-01…09', 'خلايا برج التبريد التسع'], ['FAN-1…9', 'مراوح السحب (Induced Draft)'], ['P-711 A…J', 'مضخات ماء التبريد الرئيسية'],
      ['BASIN-01', 'حوض الماء البارد'], ['E-711', 'المكثف السطحي'], ['WCR LINE', 'خط ماء التبريد الراجع']],
    kpiTags: ['E-711', 'E-112'],
  },
  {
    id: 'sec4', num: 'SECTION 400', nameAr: 'القسم الرابع — تخليق الأمونيا', nameEn: 'AMMONIA SYNTHESIS & REFRIGERATION',
    side: 'right', accent: '#34d399', dwg: 'DWG 6112P 100-400-00',
    items: [['R-401', 'مفاعل تخليق الأمونيا'], ['E-401…403', 'مبادلات المفاعل / تسخين'], ['E-404 A/B', 'المكثف المائي'], ['E-405 / E-406', 'مبردات الأمونيا'],
      ['V-401 / V-402', 'فواصل الأمونيا'], ['V-409', 'خزان التنفيس (Let-down)'], ['H-401', 'مسخن بدء التشغيل'], ['E-412 / V-408', 'مكثف ومستقبل التثليج'],
      ['P-401 A/B', 'مضخات منتج الأمونيا'], ['V-451 B', 'خزان الأمونيا المبرد']],
    kpiTags: ['R-401', 'E-412', 'V-408'],
  },
  {
    id: 'sec3', num: 'SECTION 300', nameAr: 'قسم الضاغطات (الطابق العلوي)', nameEn: 'COMPRESSORS — 2ND FLOOR HALL',
    side: 'right', accent: '#f59e0b', dwg: 'DWG 6112P 100-300 / 301',
    items: [['K-303', 'ضاغط الغاز الطبيعي'], ['K-302', 'ضاغط هواء العمليات'], ['K-301', 'ضاغط غاز التخليق (3 أجسام)'], ['K-401', 'ضاغط التثليج'],
      ['K-501', 'ضاغط CO₂ (اليوريا)'], ['K-30xT', 'التوربينات البخارية الدافعة'], ['E-301…308', 'المبردات البينية'], ['V-301…310', 'فواصل السحب']],
    kpiTags: ['K-301', 'K-302', 'K-303', 'K-401'],
  },
  {
    id: 'sec1', num: 'SECTION 100', nameAr: 'القسم الأول — الإصلاح والتحويل', nameEn: 'REFORMING & SHIFT CONVERSION',
    side: 'left', accent: '#ef4444', dwg: 'DWG 6112P 300-101-00',
    items: [['H-101', 'مسخن الغاز / الهيتر'], ['R-102 A/B', 'مفاعلا إزالة الكبريت'], ['R-101', 'فرن الإصلاح الأولي'], ['E-101…105', 'منطقة الحمل الحراري'],
      ['STACK-101', 'المدخنة الرئيسية'], ['R-103', 'المصلح الثانوي'], ['E-108 / E-109', 'مراجل استرجاع الحرارة'], ['R-104 / R-105', 'محولات CO العالي والمنخفض'],
      ['V-102A / V-109', 'درامات البخار']],
    kpiTags: ['H-101', 'R-101', 'R-103', 'R-104'],
  },
  {
    id: 'sec2', num: 'SECTION 200', nameAr: 'القسم الثاني — إزالة CO₂ (كاتاكارب)', nameEn: 'CO₂ REMOVAL — CATACARB',
    side: 'left', accent: '#10b981', dwg: 'DWG 6112P 200-00',
    items: [['T-201', 'برج امتصاص CO₂'], ['T-202', 'برج التجريد'], ['P-201 HT', 'التوربين الهيدروليكي'], ['P-201 A/B', 'مضخات المحلول شبه النقي'],
      ['E-201 / E-202', 'معيدات الغليان'], ['V-201 / V-203 / V-204', 'فواصل'], ['P-203 / P-205 / P-206', 'مضخات المحلول والمكثفات'], ['V-205 / V-206', 'خزانات كاتاكارب ومانع الرغوة']],
    kpiTags: ['T-201', 'T-202', 'P-201 HT'],
  },
  {
    id: 'steam', num: 'UTILITY', nameAr: 'منظومة البخار وماء التغذية', nameEn: 'STEAM HEADERS & BOILER FEED WATER',
    side: 'left', accent: '#a78bfa', dwg: 'DWG 6112P 100-103 / 104',
    items: [['S-65', 'مجمع البخار عالي الضغط'], ['S-39', 'مجمع البخار المتوسط'], ['S-12', 'مجمع البخار المنخفض'], ['S-3', 'مجمع البخار المنخفض جداً'],
      ['V-102 / V-102A', 'درامات البخار'], ['V-103', 'برج نزع الغازات'], ['P-101', 'مضخات ماء المراجل'], ['E-103 A/B', 'محمصات البخار']],
    kpiTags: ['V-102A', 'V-103', 'P-101'],
  },
];

const short = (s: string | undefined, n: number) => (s ? (s.length > n ? s.slice(0, n - 1) + '…' : s) : '—');

function kpiFor(tag: string): [string, string] {
  const key = tag.replace(/\s+/g, '').toUpperCase();
  const e = MASTER_EQUIPMENT_DATA.find((x) => x.tag.replace(/\s+/g, '').toUpperCase() === key);
  if (e) return [tag, `${short(e.operatingPress, 26)}  |  ${short(e.operatingTemp, 22)}`];
  const n = lookupName(tag);
  return [tag, n ? short(n.ar || n.en, 40) : '—'];
}

export class CampusControlRoom {
  public group = new THREE.Group();
  public width = 184;
  public depth = 60;
  public height = 15;
  public screenMeshes: { info: PlantSectionInfo; x: number }[] = [];

  private screens: { ctx: CanvasRenderingContext2D; tex: THREE.CanvasTexture; info: PlantSectionInfo; hist: number[][]; w: number; h: number }[] = [];
  private lamps: THREE.Mesh[] = [];
  private clockCtx?: CanvasRenderingContext2D;
  private clockTex?: THREE.CanvasTexture;
  private lastTick = -1;
  private mats: CampusMats;
  private labelStore: THREE.Sprite[];

  private matWhite = new THREE.MeshStandardMaterial({ color: 0xe5e7eb, roughness: 0.6 });
  private matDark = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.5, metalness: 0.3 });
  private matWood = new THREE.MeshStandardMaterial({ color: 0x6b4423, roughness: 0.55, metalness: 0.05 });
  private matLeather = new THREE.MeshStandardMaterial({ color: 0x2a1a12, roughness: 0.45, metalness: 0.1 });
  private matFabric = new THREE.MeshStandardMaterial({ color: 0x1e3a5f, roughness: 0.9 });
  private matSofa = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.9 });
  private matPlastic = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.4, metalness: 0.2 });

  constructor(mats: CampusMats, labelStore: THREE.Sprite[]) {
    this.mats = mats;
    this.labelStore = labelStore;
    this.group.name = 'Campus_Control_Room';
    this.buildShell();
    this.buildFacade();
    this.buildCeiling();
    this.buildSectionScreensAndConsoles();
    this.buildMimicWall();
    this.buildManagerPlatform();
    this.buildLounges();
    this.buildMeetingArea();
    this.buildClock();
    this.buildExterior();
    this.buildInteriorLights();
  }

  // -------------------------------------------------------------------
  private buildShell() {
    const W = this.width, D = this.depth, H = this.height;
    // foundation slab + floor
    const slab = new THREE.Mesh(new THREE.BoxGeometry(W + 6, 0.6, D + 6), this.mats.concretePlinth);
    slab.position.set(0, 0.1, D / 2);
    this.group.add(slab);
    const ft = createFloorTileTexture();
    ft.wrapS = ft.wrapT = THREE.RepeatWrapping;
    ft.repeat.set(W / 5, D / 5);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(W, D), new THREE.MeshStandardMaterial({ map: ft, roughness: 0.22, metalness: 0.15 }));
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(0, 0.42, D / 2);
    this.group.add(floor);
    // side & back walls
    const wallMat = new THREE.MeshStandardMaterial({ color: 0xcfd6dd, roughness: 0.8 });
    [-1, 1].forEach((s) => {
      const w = new THREE.Mesh(new THREE.BoxGeometry(0.8, H, D), wallMat);
      w.position.set(s * (W / 2), H / 2 + 0.4, D / 2);
      this.group.add(w);
    });
    const back = new THREE.Mesh(new THREE.BoxGeometry(W, H, 0.8), wallMat);
    back.position.set(0, H / 2 + 0.4, D);
    this.group.add(back);
    // roof slab + parapet
    const roof = new THREE.Mesh(new THREE.BoxGeometry(W + 3, 0.9, D + 3), this.mats.concretePlinth);
    roof.position.set(0, H + 0.9, D / 2);
    this.group.add(roof);
    const para = new THREE.Mesh(new THREE.BoxGeometry(W + 3, 1.6, 0.6), this.mats.safetyBlue);
    para.position.set(0, H + 2.2, -1.2);
    this.group.add(para);
    // rooftop AC units
    for (let i = 0; i < 8; i++) {
      const ac = new THREE.Mesh(new THREE.BoxGeometry(6, 2.4, 3.4), this.matWhite);
      ac.position.set(-W / 2 + 16 + i * ((W - 32) / 7), H + 2.6, D * 0.55);
      this.group.add(ac);
      const fan = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 0.12, 16), this.matDark);
      fan.position.set(ac.position.x, H + 3.85, ac.position.z);
      this.group.add(fan);
    }
  }

  private buildFacade() {
    const W = this.width, H = this.height;
    // concrete spandrel band + glass curtain wall with mullions
    const band = new THREE.Mesh(new THREE.BoxGeometry(W, 1.4, 0.8), this.mats.concretePlinth);
    band.position.set(0, 1.1, 0);
    this.group.add(band);
    const glassMat = new THREE.MeshStandardMaterial({ color: 0x7dd3fc, roughness: 0.05, metalness: 0.9, transparent: true, opacity: 0.32, side: THREE.DoubleSide });
    const panelW = 8;
    const n = Math.floor(W / panelW);
    for (let i = 0; i < n; i++) {
      const x = -W / 2 + panelW / 2 + i * panelW;
      if (Math.abs(x) < 7) continue; // entrance opening
      const glass = new THREE.Mesh(new THREE.BoxGeometry(panelW - 0.25, H - 1.6, 0.18), glassMat);
      glass.position.set(x, 1.8 + (H - 1.6) / 2, 0);
      this.group.add(glass);
    }
    for (let i = 0; i <= n; i++) {
      const x = -W / 2 + i * panelW;
      const mu = new THREE.Mesh(new THREE.BoxGeometry(0.3, H - 0.6, 0.5), this.mats.carbonSteel);
      mu.position.set(x, H / 2 + 0.9, 0);
      this.group.add(mu);
    }
    const head = new THREE.Mesh(new THREE.BoxGeometry(W, 0.5, 0.9), this.mats.carbonSteel);
    head.position.set(0, H + 0.4, 0);
    this.group.add(head);
    // entrance: canopy, columns, steps, doors
    const canopy = new THREE.Mesh(new THREE.BoxGeometry(24, 0.6, 9), this.mats.safetyBlue);
    canopy.position.set(0, 7.2, -4.5);
    this.group.add(canopy);
    [-10, 10].forEach((x) => {
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 6.9, 16), this.mats.alloySteel);
      col.position.set(x, 3.8, -8);
      this.group.add(col);
    });
    for (let i = 0; i < 4; i++) {
      const st = new THREE.Mesh(new THREE.BoxGeometry(22 - i * 1.2, 0.18, 2.4), this.mats.sidewalk);
      st.position.set(0, 0.18 + i * 0.0, -2 - (3 - i) * 2.4 + 2.4);
      st.position.y = 0.3 - i * 0.07;
      this.group.add(st);
    }
    [-3.2, 3.2].forEach((x) => {
      const door = new THREE.Mesh(new THREE.BoxGeometry(5.6, 6.4, 0.2), glassMat);
      door.position.set(x, 3.8, 0);
      this.group.add(door);
    });
  }

  private buildCeiling() {
    const W = this.width, D = this.depth, H = this.height;
    const ct = createCeilingTexture();
    ct.wrapS = ct.wrapT = THREE.RepeatWrapping;
    ct.repeat.set(W / 6, D / 6);
    const ceil = new THREE.Mesh(new THREE.PlaneGeometry(W, D), new THREE.MeshStandardMaterial({ map: ct, roughness: 0.9, side: THREE.DoubleSide }));
    ceil.rotation.x = Math.PI / 2;
    ceil.position.set(0, H + 0.2, D / 2);
    this.group.add(ceil);
    // exposed steel trusses + light troffers
    for (let x = -W / 2 + 10; x <= W / 2 - 10; x += 20) {
      const tr = new THREE.Mesh(new THREE.BoxGeometry(0.6, 1.0, D - 2), this.mats.carbonSteel);
      tr.position.set(x, H - 0.4, D / 2);
      this.group.add(tr);
    }
    const lightMat = new THREE.MeshBasicMaterial({ color: 0xfff7e0 });
    for (let x = -W / 2 + 6; x <= W / 2 - 6; x += 10) {
      for (let z = 8; z <= D - 6; z += 12) {
        const l = new THREE.Mesh(new THREE.BoxGeometry(5, 0.12, 1.2), lightMat);
        l.position.set(x, H - 0.1, z);
        this.group.add(l);
      }
    }
  }

  private buildInteriorLights() {
    const W = this.width, D = this.depth;
    for (let i = 0; i < 5; i++) {
      const p = new THREE.PointLight(0xfff1d6, 1.2, 70, 1.6);
      p.position.set(-W / 2 + 20 + i * ((W - 40) / 4), 11, D * 0.45);
      this.group.add(p);
    }
  }

  // -------------------------------------------------------------------
  private chair(color: THREE.Material, high = false): THREE.Group {
    const c = new THREE.Group();
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.12, 0.6), color);
    seat.position.y = 0.55;
    c.add(seat);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.58, high ? 1.1 : 0.7, 0.1), color);
    back.position.set(0, high ? 1.15 : 0.95, -0.27);
    back.rotation.x = -0.08;
    c.add(back);
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.4, 8), this.matPlastic);
    stem.position.y = 0.3;
    c.add(stem);
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      const sp = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.04, 0.05), this.matPlastic);
      sp.position.set(Math.cos(a) * 0.2, 0.1, Math.sin(a) * 0.2);
      sp.rotation.y = -a;
      c.add(sp);
    }
    [-1, 1].forEach((s) => {
      const arm = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.05, 0.4), this.matPlastic);
      arm.position.set(s * 0.33, 0.8, -0.05);
      c.add(arm);
    });
    return c;
  }

  private monitor(title: string, tag: string, w = 1.3, h = 0.85): THREE.Group {
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.1), this.matPlastic);
    g.add(body);
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(w - 0.1, h - 0.1), new THREE.MeshBasicMaterial({ map: createDCSMonitorTexture(title, tag), toneMapped: false }));
    scr.position.z = 0.06;
    g.add(scr);
    const stand = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.35, 0.1), this.matPlastic);
    stand.position.y = -h / 2 - 0.15;
    g.add(stand);
    return g;
  }

  private desk(w: number, d: number, topMat: THREE.Material): THREE.Group {
    const g = new THREE.Group();
    const top = new THREE.Mesh(new THREE.BoxGeometry(w, 0.1, d), topMat);
    top.position.y = 1.0;
    g.add(top);
    [-1, 1].forEach((s) => {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.0, d * 0.9), this.matDark);
      leg.position.set(s * (w / 2 - 0.1), 0.5, 0);
      g.add(leg);
    });
    const modesty = new THREE.Mesh(new THREE.BoxGeometry(w - 0.3, 0.6, 0.05), this.matDark);
    modesty.position.set(0, 0.65, -d / 2 + 0.1);
    g.add(modesty);
    return g;
  }

  // -------------------------------------------------------------------
  private drawScreen(s: { ctx: CanvasRenderingContext2D; info: PlantSectionInfo; hist: number[][]; w: number; h: number }, t: number) {
    const { ctx, info, w, h } = s;
    ctx.save();
    ctx.fillStyle = '#050d18'; ctx.fillRect(0, 0, w, h);
    const grad = ctx.createLinearGradient(0, 0, w, 0);
    grad.addColorStop(0, info.accent); grad.addColorStop(1, '#0b1a2c');
    ctx.fillStyle = grad; ctx.fillRect(0, 0, w, 150);
    ctx.fillStyle = '#031019';
    ctx.textAlign = 'left';
    ctx.font = 'bold 50px monospace';
    ctx.fillText(info.num, 40, 62);
    ctx.font = '28px monospace';
    ctx.fillText(info.nameEn, 40, 112);
    ctx.textAlign = 'right';
    ctx.direction = 'rtl';
    ctx.font = 'bold 62px "Segoe UI", Tahoma, sans-serif';
    ctx.fillText(info.nameAr, w - 40, 96);
    ctx.direction = 'ltr';
    ctx.strokeStyle = info.accent; ctx.lineWidth = 8; ctx.strokeRect(4, 4, w - 8, h - 8);

    // equipment list (two columns)
    ctx.textAlign = 'left';
    ctx.font = 'bold 26px monospace';
    ctx.fillStyle = info.accent;
    ctx.fillText('MAIN EQUIPMENT  |  المعدات الرئيسية', 40, 200);
    const colW = 560;
    info.items.forEach((it, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 40 + col * colW, y = 250 + row * 62;
      ctx.fillStyle = info.accent; ctx.font = 'bold 28px monospace'; ctx.textAlign = 'left';
      ctx.fillText(it[0], x, y);
      ctx.fillStyle = '#e2e8f0'; ctx.font = '25px "Segoe UI", Tahoma, sans-serif';
      ctx.fillText(it[1].length > 30 ? it[1].slice(0, 29) + '…' : it[1], x + 3, y + 28);
    });

    // KPIs
    const kx = 1190;
    ctx.fillStyle = info.accent; ctx.font = 'bold 26px monospace'; ctx.textAlign = 'left';
    ctx.fillText('KEY PARAMETERS', kx, 200);
    info.kpiTags.slice(0, 4).forEach((tg, i) => {
      const [k, v] = kpiFor(tg);
      const y = 232 + i * 70;
      ctx.fillStyle = 'rgba(30,41,59,0.9)'; ctx.fillRect(kx, y, 370, 58);
      ctx.fillStyle = info.accent; ctx.font = 'bold 24px monospace'; ctx.fillText(k, kx + 10, y + 24);
      ctx.fillStyle = '#f1f5f9'; ctx.font = '18px monospace'; ctx.fillText(v.length > 44 ? v.slice(0, 43) + '…' : v, kx + 10, y + 47);
    });

    // live trend (animated)
    const cx = 40, cy = 530, cw = 1100, ch = 150;
    ctx.fillStyle = 'rgba(15,23,42,0.9)'; ctx.fillRect(cx, cy, cw, ch);
    ctx.strokeStyle = 'rgba(148,163,184,0.25)'; ctx.lineWidth = 1;
    for (let i = 1; i < 4; i++) { ctx.beginPath(); ctx.moveTo(cx, cy + (ch / 4) * i); ctx.lineTo(cx + cw, cy + (ch / 4) * i); ctx.stroke(); }
    s.hist.forEach((line, li) => {
      ctx.strokeStyle = li === 0 ? info.accent : li === 1 ? '#facc15' : '#f472b6';
      ctx.lineWidth = 3; ctx.beginPath();
      line.forEach((v, i) => {
        const x = cx + (i / (line.length - 1)) * cw, y = cy + ch - v * ch;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.stroke();
    });
    ctx.fillStyle = '#94a3b8'; ctx.font = '20px monospace';
    ctx.fillText('LIVE TREND  PV / SP / OUT', cx + 10, cy + 24);

    // status LED + clock
    const on = Math.floor(t * 2) % 2 === 0;
    ctx.fillStyle = on ? '#22c55e' : '#14532d';
    ctx.beginPath(); ctx.arc(1210, 650, 14, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#22c55e'; ctx.font = 'bold 26px monospace'; ctx.fillText('RUN — NORMAL', 1235, 659);
    ctx.fillStyle = '#64748b'; ctx.font = '22px monospace';
    ctx.fillText(info.dwg, 1190, 700);
    ctx.restore();
  }

  private buildSectionScreensAndConsoles() {
    const D = this.depth;
    const bySide: Record<'left' | 'right', PlantSectionInfo[]> = { left: [], right: [] };
    PLANT_SECTIONS.forEach((s) => bySide[s.side].push(s));
    const SPACING = 28;
    (['left', 'right'] as const).forEach((side) => {
      // world +X is the "left" column, world -X is the "right" column (as seen walking down the avenue)
      const sgn = side === 'left' ? 1 : -1;
      bySide[side].forEach((info, k) => {
        const x = sgn * (26 + k * SPACING);
        this.buildOneScreen(info, x);
        this.buildConsoleCluster(info, x);
        this.screenMeshes.push({ info, x });
        // exterior sign above facade
        const sp = makeLabelSprite(info.num, `قبالة ${info.nameAr}`, info.accent, 2.6);
        sp.position.set(x, this.height + 3.6, -2);
        this.group.add(sp);
        this.labelStore.push(sp);
      });
    });
    void D;
  }

  private buildOneScreen(info: PlantSectionInfo, x: number) {
    const W = 20, H = 9;
    const px = 1600, py = 720;
    const c = document.createElement('canvas');
    c.width = px; c.height = py;
    const ctx = c.getContext('2d')!;
    const hist = [0, 1, 2].map((li) => Array.from({ length: 70 }, (_, i) => 0.5 + 0.25 * Math.sin(i * 0.2 + li * 1.7)));
    const tex = new THREE.CanvasTexture(c);
    tex.anisotropy = 4;
    const entry = { ctx, tex, info, hist, w: px, h: py };
    this.drawScreen(entry, 0);
    tex.needsUpdate = true;
    this.screens.push(entry);

    const grp = new THREE.Group();
    grp.position.set(x, 0, 7);
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(W, H), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false }));
    scr.position.set(0, 7.4, 0.16);
    grp.add(scr);
    const frame = new THREE.Mesh(new THREE.BoxGeometry(W + 0.8, H + 0.8, 0.3), this.matPlastic);
    frame.position.set(0, 7.4, 0);
    grp.add(frame);
    [-1, 1].forEach((s) => {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.5, 3.4, 0.5), this.mats.carbonSteel);
      post.position.set(s * (W / 2 - 2), 1.9, 0);
      grp.add(post);
    });
    this.group.add(grp);
  }

  private buildConsoleCluster(info: PlantSectionInfo, x: number) {
    for (let i = -1; i <= 1; i++) {
      const g = new THREE.Group();
      g.position.set(x + i * 6.6, 0.42, 15.5 - Math.abs(i) * 0.9);
      g.rotation.y = i * -0.1;
      const d = this.desk(5.6, 1.6, this.matWood);
      g.add(d);
      const tag = info.num.replace('SECTION ', 'S');
      [-1.4, 1.4].forEach((mx, mi) => {
        const m = this.monitor(`${tag} OP${i + 2}.${mi + 1}`, info.nameEn.slice(0, 14));
        m.position.set(mx, 1.75, -0.15);
        g.add(m);
      });
      const kb = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.04, 0.38), this.matPlastic);
      kb.position.set(0, 1.07, 0.35);
      g.add(kb);
      const ch = this.chair(this.matFabric);
      ch.position.set(0, 0, 1.9);
      ch.rotation.y = Math.PI;   // operator faces the screens / plant (-Z)
      g.add(ch);
      this.group.add(g);
    }
  }

  // -------------------------------------------------------------------
  private buildMimicWall() {
    const D = this.depth;
    const titles: [string, string][] = [['REFORMING', 'I'], ['CO2 REMOVAL', 'II'], ['COMPRESSORS', 'III'], ['SYNTHESIS', 'IV'], ['REFRIGERATION', 'V'], ['UTILITIES', 'VI']];
    const pw = 14;
    titles.forEach(([t, id], i) => {
      const tex = createVintageGreenPanelTexture(t, id);
      const m = new THREE.Mesh(new THREE.PlaneGeometry(pw - 0.3, 8.4), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.6 }));
      m.rotation.y = Math.PI;
      m.position.set((i - 2.5) * pw, 5.4, D - 0.6);
      this.group.add(m);
      const fr = new THREE.Mesh(new THREE.BoxGeometry(pw - 0.1, 8.8, 0.3), this.mats.carbonSteel);
      fr.position.set((i - 2.5) * pw, 5.4, D - 0.4);
      this.group.add(fr);
    });
    // annunciator lamp strip (blinking)
    for (let i = 0; i < 36; i++) {
      const lamp = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.6, 0.2), new THREE.MeshStandardMaterial({ color: 0x111111, emissive: 0x22c55e, emissiveIntensity: 0.8 }));
      lamp.position.set(-42 + i * 2.4, 10.4, D - 0.9);
      this.group.add(lamp);
      this.lamps.push(lamp);
    }
    // console desk in front of the mimic panel
    const sg = makeLabelSprite('MHI GRAPHIC PANEL', 'لوحة الرسم البياني الرئيسية', '#86efac', 2.4);
    sg.position.set(0, 11.6, D - 1.2);
    this.group.add(sg);
    this.labelStore.push(sg);
  }

  private buildManagerPlatform() {
    const D = this.depth;
    const g = new THREE.Group();
    g.position.set(0, 0.42, 34);
    const plat = new THREE.Mesh(new THREE.BoxGeometry(18, 0.4, 11), new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 }));
    plat.position.y = 0.2;
    g.add(plat);
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(15, 8), new THREE.MeshStandardMaterial({ color: 0x7f1d1d, roughness: 0.95 }));
    rug.rotation.x = -Math.PI / 2;
    rug.position.y = 0.42;
    g.add(rug);
    // executive L-shaped desk
    const main = new THREE.Mesh(new THREE.BoxGeometry(5.4, 0.16, 2.2), this.matWood);
    main.position.set(0, 1.45, 0.4);
    g.add(main);
    const wing = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.16, 3.4), this.matWood);
    wing.position.set(-3.3, 1.45, 1.0);
    g.add(wing);
    [[-2.5, 0.4], [2.5, 0.4], [-3.9, 2.4]].forEach(([lx, lz]) => {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.4, 1.8), this.matDark);
      leg.position.set(lx, 0.75, lz);
      g.add(leg);
    });
    // PC monitors, lamp, phone, papers
    const m1 = this.monitor('AMMONIA HEAD', 'PLANT OVERVIEW', 1.6, 1.0);
    m1.position.set(-0.8, 2.25, 0.0);
    g.add(m1);
    const m2 = this.monitor('SHIFT REPORT', 'LOG', 1.6, 1.0);
    m2.position.set(1.1, 2.25, 0.0);
    g.add(m2);
    const lamp = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.2, 0.9, 12), this.mats.safetyYellow);
    lamp.position.set(2.2, 1.95, 0.4);
    g.add(lamp);
    const phone = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 0.35), this.matPlastic);
    phone.position.set(-2.0, 1.58, 0.9);
    g.add(phone);
    const papers = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.05, 1.1), this.matWhite);
    papers.position.set(0.3, 1.56, 1.0);
    papers.rotation.y = 0.2;
    g.add(papers);
    // manager's high-back leather chair (behind the desk, facing the plant)
    const boss = this.chair(this.matLeather, true);
    boss.scale.setScalar(1.45);
    boss.position.set(0, 0, 2.0);
    boss.rotation.y = Math.PI;
    g.add(boss);
    // visitor chairs
    [-1.4, 1.4].forEach((vx) => {
      const vc = this.chair(this.matFabric);
      vc.scale.setScalar(1.2);
      vc.position.set(vx, 0, -2.6);
      g.add(vc);
    });
    // nameplate + sign
    const np = canvasPlane(1.9, 0.5, 512, 128, (ctx, w, h) => {
      ctx.fillStyle = '#c9a227'; ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = '#1c1405'; ctx.textAlign = 'center'; ctx.direction = 'rtl';
      ctx.font = 'bold 44px "Segoe UI", Tahoma, sans-serif';
      ctx.fillText('مسؤول قسم الأمونيا', w / 2, 58);
      ctx.font = '26px monospace'; ctx.direction = 'ltr';
      ctx.fillText('AMMONIA SECTION HEAD', w / 2, 100);
    });
    np.position.set(0, 1.75, -0.5);
    np.rotation.y = Math.PI;
    np.rotation.x = 0.4;
    g.add(np);
    const sg = makeLabelSprite('AMMONIA HEAD', 'مكتب مسؤول قسم الأمونيا', '#facc15', 2.2);
    sg.position.set(0, 6.0, -1.0);
    g.add(sg);
    this.labelStore.push(sg);
    this.group.add(g);
    void D;
  }

  private buildLounges() {
    const D = this.depth, W = this.width;
    [-1, 1].forEach((side) => {
      const lg = new THREE.Group();
      lg.position.set(side * (W / 2 - 22), 0.42, D - 14);
      const rug = new THREE.Mesh(new THREE.PlaneGeometry(22, 12), new THREE.MeshStandardMaterial({ color: side < 0 ? 0x1e3a5f : 0x14532d, roughness: 0.95 }));
      rug.rotation.x = -Math.PI / 2; rug.position.y = 0.02; lg.add(rug);
      // L sofa
      const base1 = new THREE.Mesh(new THREE.BoxGeometry(9, 0.7, 2.2), this.matSofa); base1.position.set(0, 0.45, -4.2); lg.add(base1);
      const back1 = new THREE.Mesh(new THREE.BoxGeometry(9, 1.0, 0.5), this.matSofa); back1.position.set(0, 1.1, -5.1); lg.add(back1);
      const base2 = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.7, 6), this.matSofa); base2.position.set(-5.4, 0.45, -1.3); lg.add(base2);
      const back2 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1.0, 6), this.matSofa); back2.position.set(-6.3, 1.1, -1.3); lg.add(back2);
      // coffee table (ميز)
      const tt = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.12, 2.2), this.matWood); tt.position.set(0.5, 0.75, -0.8); lg.add(tt);
      [[-1.8, -1.6], [2.8, -1.6], [-1.8, 0.0], [2.8, 0.0]].forEach(([lx, lz]) => {
        const l = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.7, 0.12), this.matDark); l.position.set(lx, 0.38, lz); lg.add(l);
      });
      // armchairs
      [[3.8, 1.8, 0.6], [-1.2, 2.4, -0.3]].forEach(([ax, az, rot]) => {
        const ac = this.chair(this.matSofa); ac.scale.setScalar(1.5); ac.position.set(ax, 0, az); ac.rotation.y = Math.PI + rot; lg.add(ac);
      });
      // potted plant
      const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.4, 0.8, 12), this.mats.concretePlinth); pot.position.set(6.6, 0.4, -4.6); lg.add(pot);
      const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.95, 12, 10), new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.9 })); leaf.position.set(6.6, 1.6, -4.6); lg.add(leaf);
      const sg = makeLabelSprite('LOUNGE', 'منطقة جلوس واستراحة المشغّلين', '#7dd3fc', 1.6);
      sg.position.set(0, 4.2, -2); lg.add(sg); this.labelStore.push(sg);
      this.group.add(lg);
    });
  }

  private buildMeetingArea() {
    const D = this.depth;
    const g = new THREE.Group();
    g.position.set(0, 0.42, D - 12);
    const table = new THREE.Mesh(new THREE.BoxGeometry(12, 0.16, 3.0), this.matWood);
    table.position.y = 1.0;
    g.add(table);
    [-5, 5].forEach((x) => {
      const l = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.0, 2.4), this.matDark); l.position.set(x, 0.5, 0); g.add(l);
    });
    for (let i = 0; i < 6; i++) {
      [-1, 1].forEach((s) => {
        const c = this.chair(this.matFabric);
        c.position.set(-5 + i * 2, 0, s * 2.1);
        c.rotation.y = s > 0 ? Math.PI : 0;
        g.add(c);
      });
    }
    // coffee station
    const counter = new THREE.Mesh(new THREE.BoxGeometry(5, 1.1, 1.2), this.matWhite);
    counter.position.set(-18, 0.55, 4);
    g.add(counter);
    const mach = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.9, 0.7), this.matPlastic);
    mach.position.set(-19, 1.55, 4);
    g.add(mach);
    // lockers
    for (let i = 0; i < 8; i++) {
      const lk = new THREE.Mesh(new THREE.BoxGeometry(1.0, 3.0, 0.8), new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.5, metalness: 0.6 }));
      lk.position.set(16 + i * 1.05, 1.5, 6);
      g.add(lk);
    }
    const sg = makeLabelSprite('MEETING', 'طاولة الاجتماعات واستلام النوبة', '#fda4af', 1.6);
    sg.position.set(0, 4.4, 0);
    g.add(sg);
    this.labelStore.push(sg);
    this.group.add(g);
  }

  private buildClock() {
    const c = document.createElement('canvas');
    c.width = 512; c.height = 192;
    this.clockCtx = c.getContext('2d')!;
    this.clockTex = new THREE.CanvasTexture(c);
    const m = new THREE.Mesh(new THREE.PlaneGeometry(6, 2.25), new THREE.MeshBasicMaterial({ map: this.clockTex, toneMapped: false }));
    m.position.set(0, 12.2, 1.2);
    this.group.add(m);
  }

  private buildExterior() {
    const W = this.width;
    const sign = canvasPlane(34, 6.4, 1536, 288, (ctx, w, h) => {
      ctx.fillStyle = '#0b1b2e'; ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = '#38bdf8'; ctx.lineWidth = 10; ctx.strokeRect(8, 8, w - 16, h - 16);
      ctx.fillStyle = '#38bdf8'; ctx.textAlign = 'center'; ctx.direction = 'rtl';
      ctx.font = 'bold 96px "Segoe UI", Tahoma, sans-serif';
      ctx.fillText('غرفة السيطرة المركزية — مجمع الأمونيا', w / 2, 125);
      ctx.fillStyle = '#e2e8f0'; ctx.direction = 'ltr';
      ctx.font = 'bold 58px monospace';
      ctx.fillText('CENTRAL CONTROL ROOM (CCR)', w / 2, 220);
    });
    sign.rotation.y = Math.PI;
    sign.position.set(0, this.height + 2.2, -1.6);
    this.group.add(sign);
    // flag pole
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.2, 18, 10), this.mats.alloySteel);
    pole.position.set(W / 2 - 8, 9, -14);
    this.group.add(pole);
    const flag = new THREE.Mesh(new THREE.PlaneGeometry(6, 4), new THREE.MeshBasicMaterial({ map: createIraqiFlagTexture(), side: THREE.DoubleSide }));
    flag.position.set(W / 2 - 8 - 3.1, 15.4, -14);
    flag.rotation.y = Math.PI / 2;
    this.group.add(flag);
  }

  // -------------------------------------------------------------------
  public update(t: number) {
    const tick = Math.floor(t * 2);
    if (tick === this.lastTick) return;
    this.lastTick = tick;
    this.screens.forEach((s, si) => {
      s.hist.forEach((line, li) => {
        line.shift();
        const last = line[line.length - 1];
        line.push(Math.max(0.08, Math.min(0.92, last + (Math.random() - 0.5) * 0.12 + Math.sin(t * 0.7 + si + li) * 0.015)));
      });
      this.drawScreen(s, t);
      s.tex.needsUpdate = true;
    });
    this.lamps.forEach((l, i) => {
      (l.material as THREE.MeshStandardMaterial).emissiveIntensity = (Math.sin(t * 1.3 + i * 0.7) > 0.93) ? 1.8 : 0.5;
    });
    if (this.clockCtx && this.clockTex) {
      const d = new Date();
      const ctx = this.clockCtx;
      ctx.fillStyle = '#04070d'; ctx.fillRect(0, 0, 512, 192);
      ctx.fillStyle = '#ff4d3d'; ctx.font = 'bold 110px monospace'; ctx.textAlign = 'center';
      ctx.fillText(d.toTimeString().slice(0, 8), 256, 120);
      ctx.fillStyle = '#9ca3af'; ctx.font = '30px monospace';
      ctx.fillText('CCR — AMMONIA PLANT', 256, 172);
      this.clockTex.needsUpdate = true;
    }
  }
}

/**
 * SecurityGuard.ts
 * Enterprise Security & Intellectual Property Protection Suite
 * Enforces:
 *   1. Anti-Tampering & Anti-Scraping Guards (Shortcuts, Context Menu, Drag & Drop)
 *   2. Resilient Dynamic Watermark Guard via MutationObserver
 *   3. Console Security Banner & Protection Notices
 *   4. Safe Context Notifications
 * All Rights Reserved © 2026 Eng. Ali Saif Al-Deen Haider Al-Nawfal
 */

import { securityWatermark } from './securityWatermark';

export class SecurityGuard {
  private static instance: SecurityGuard | null = null;
  private observer: MutationObserver | null = null;
  private isToastActive: boolean = false;

  public static getInstance(): SecurityGuard {
    if (!SecurityGuard.instance) {
      SecurityGuard.instance = new SecurityGuard();
    }
    return SecurityGuard.instance;
  }

  private constructor() {}

  public init() {
    if (typeof window === 'undefined' || typeof document === 'undefined') return;

    this.setupConsoleBanner();
    this.setupKeyboardGuards();
    this.setupContextMenuGuards();
    this.setupDragGuards();
    this.setupWatermarkTamperObserver();
  }

  /**
   * Log high-visibility security and intellectual property protection warning
   */
  private setupConsoleBanner() {
    try {
      console.log(
        '%c🛡️ نظام أمان المنصة وحماية الملكية الفكرية\n' +
        '%cجميع الحقوق محفوظة © 2026 Eng. Ali Saif Al-Deen Haider Al-Nawfal\n' +
        '%cهذا التطبيق ومجسمات المحاكاة ثلاثية الأبعاد والمخططات الهندسية مسجلة ومحمية بموجب قوانين حماية المصنفات الرقمية والملكية الفكرية. يُمنع التلاعب أو النسخ أو الهندسة العكسية.',
        'color: #00c8ef; font-size: 16px; font-weight: 900;',
        'color: #facc15; font-size: 13px; font-weight: 700;',
        'color: #94a3b8; font-size: 11px; line-height: 1.6;'
      );
    } catch (_) {}
  }

  /**
   * Disable source inspection and devtools shortcut keys
   */
  private setupKeyboardGuards() {
    window.addEventListener('keydown', (e: KeyboardEvent) => {
      // F12 DevTools
      if (e.key === 'F12') {
        e.preventDefault();
        this.showSecurityToast('تم تعطيل أدوات الفحص لحماية البرمجيات الهندسية');
        return;
      }

      const isCtrlOrMeta = e.ctrlKey || e.metaKey;

      // Ctrl+Shift+I / Ctrl+Shift+J / Ctrl+Shift+C (DevTools)
      if (isCtrlOrMeta && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.key === 'J' || e.key === 'j' || e.key === 'C' || e.key === 'c')) {
        e.preventDefault();
        this.showSecurityToast('تم حظر فتح أدوات المطورين للحفاظ على أمان المنصة');
        return;
      }

      // Ctrl+U (View Source)
      if (isCtrlOrMeta && (e.key === 'u' || e.key === 'U')) {
        e.preventDefault();
        this.showSecurityToast('عرض المصدر محمي بموجب حقوق النشر والملكية الفكرية');
        return;
      }

      // Ctrl+S (Save Webpage)
      if (isCtrlOrMeta && (e.key === 's' || e.key === 'S')) {
        // Allow within input elements
        const target = e.target as HTMLElement;
        if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
          return;
        }
        e.preventDefault();
        this.showSecurityToast('حفظ صفحات المحاكاة مقيد لأسباب أمنية وحماية البيانات');
        return;
      }
    });
  }

  /**
   * Guard right-click on 3D canvas and diagrams to prevent asset scraping
   */
  private setupContextMenuGuards() {
    document.addEventListener('contextmenu', (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      // Allow context menu only on inputs or textareas for paste/copy of names
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }

      // If user right clicks on 3D viewport, canvas, svg diagrams or exam cards
      if (
        target.closest('#view3d-canvas') ||
        target.closest('#diagram-canvas') ||
        target.closest('.view3d-overlay') ||
        target.closest('.diagram-wrapper') ||
        target.closest('#v3d-printable-cert')
      ) {
        e.preventDefault();
        this.showSecurityToast('المحتوى الهندسي والمحاكاة ثلاثية الأبعاد محمية بحقوق الملكية الفكرية © 2026 Eng. Ali Saif');
      }
    });
  }

  /**
   * Guard against dragging image and diagram assets out of the window
   */
  private setupDragGuards() {
    document.addEventListener('dragstart', (e: DragEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'IMG' || target.tagName === 'CANVAS' || target.tagName === 'SVG')) {
        e.preventDefault();
      }
    });
  }

  private isRestoringWatermark: boolean = false;
  private watermarkDebounceTimer: any = null;

  /**
   * MutationObserver to ensure the dynamic watermark overlay cannot be deleted or hidden by inspect element
   * Highly optimized: avoids subtree attribute watching on document.body
   */
  private setupWatermarkTamperObserver() {
    if (typeof MutationObserver === 'undefined' || !document.body) return;

    const restoreWatermark = () => {
      if (this.isRestoringWatermark) return;
      clearTimeout(this.watermarkDebounceTimer);
      this.watermarkDebounceTimer = setTimeout(() => {
        try {
          const cachedUser = localStorage.getItem('nh3_cached_user');
          if (!cachedUser) return;
          const userObj = JSON.parse(cachedUser);
          if (!userObj?.email) return;

          const watermarkEl = document.getElementById('v3d-security-watermark-overlay');
          if (!watermarkEl || watermarkEl.style.display === 'none' || watermarkEl.style.visibility === 'hidden') {
            this.isRestoringWatermark = true;
            securityWatermark.update(userObj.email);
            setTimeout(() => {
              this.isRestoringWatermark = false;
              // Re-attach direct observer to freshly restored element
              attachWatermarkAttributeObserver();
            }, 250);
          }
        } catch (_) {}
      }, 350);
    };

    // 1. Observe document.body ONLY for direct child addition/removal (subtree: false)
    this.observer = new MutationObserver((mutations) => {
      for (let i = 0; i < mutations.length; i++) {
        const m = mutations[i];
        if (m.type === 'childList') {
          for (let j = 0; j < m.removedNodes.length; j++) {
            const node = m.removedNodes[j] as HTMLElement;
            if (node.id === 'v3d-security-watermark-overlay') {
              restoreWatermark();
              return;
            }
          }
        }
      }
    });

    this.observer.observe(document.body, {
      childList: true,
      subtree: false
    });

    // 2. Observe the watermark overlay element directly for its own style changes
    let watermarkAttrObserver: MutationObserver | null = null;
    const attachWatermarkAttributeObserver = () => {
      const el = document.getElementById('v3d-security-watermark-overlay');
      if (!el) return;
      if (watermarkAttrObserver) watermarkAttrObserver.disconnect();
      watermarkAttrObserver = new MutationObserver(() => {
        if (el.style.display === 'none' || el.style.visibility === 'hidden' || el.style.opacity === '0') {
          restoreWatermark();
        }
      });
      watermarkAttrObserver.observe(el, {
        attributes: true,
        attributeFilter: ['style', 'hidden', 'class']
      });
    };

    attachWatermarkAttributeObserver();
  }

  /**
   * Show elegant, subtle Arabic security toast notification
   */
  public showSecurityToast(message: string) {
    if (this.isToastActive) return;
    this.isToastActive = true;

    let toast = document.getElementById('app-security-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'app-security-toast';
      toast.style.cssText = `
        position: fixed;
        bottom: 24px;
        left: 50%;
        transform: translateX(-50%) translateY(20px);
        background: rgba(15, 23, 42, 0.95);
        border: 1px solid rgba(56, 189, 248, 0.4);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7), 0 0 15px rgba(56, 189, 248, 0.2);
        color: #f8fafc;
        padding: 10px 20px;
        border-radius: 9999px;
        font-family: 'Cairo', system-ui, sans-serif;
        font-size: 12.5px;
        font-weight: 700;
        z-index: 9999999;
        pointer-events: none;
        opacity: 0;
        transition: all 0.28s cubic-bezier(0.16, 1, 0.3, 1);
        display: flex;
        align-items: center;
        gap: 8px;
        direction: rtl;
        max-width: 90vw;
        text-align: center;
      `;
      document.body.appendChild(toast);
    }

    toast.innerHTML = `<span>🛡️</span> <span>${message}</span>`;
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(-50%) translateY(0)';

    setTimeout(() => {
      if (toast) {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(-50%) translateY(20px)';
      }
      setTimeout(() => {
        this.isToastActive = false;
      }, 300);
    }, 2800);
  }
}

export const securityGuard = SecurityGuard.getInstance();

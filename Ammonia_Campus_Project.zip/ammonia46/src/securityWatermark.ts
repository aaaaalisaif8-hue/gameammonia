/**
 * securityWatermark.ts
 * Subtle full-screen dynamic security watermark with user email and copyright
 * Pointer-events: none, low opacity, covers the screen on login.
 */

import { escapeHtml } from './securityUtils';

export class SecurityWatermark {
  private static instance: SecurityWatermark | null = null;
  private containerEl: HTMLElement | null = null;

  public static getInstance(): SecurityWatermark {
    if (!SecurityWatermark.instance) {
      SecurityWatermark.instance = new SecurityWatermark();
    }
    return SecurityWatermark.instance;
  }

  private constructor() {
    if (typeof document !== 'undefined') {
      if (document.body) {
        this.initDOM();
      } else {
        document.addEventListener('DOMContentLoaded', () => this.initDOM());
      }
    }
  }

  private initDOM() {
    if (typeof document === 'undefined' || !document.body) return;
    let el = document.getElementById('v3d-security-watermark-overlay');
    if (!el) {
      el = document.createElement('div');
      el.id = 'v3d-security-watermark-overlay';
      el.style.cssText = `
        position: fixed;
        inset: 0;
        z-index: 999980;
        pointer-events: none;
        user-select: none;
        overflow: hidden;
        display: none;
        opacity: 0.045;
        color: #ffffff;
        font-family: 'IBM Plex Mono', monospace;
        font-size: 13px;
        font-weight: 700;
        line-height: 1.4;
      `;
      document.body.appendChild(el);
    }
    this.containerEl = el;
  }

  public update(userEmail: string | null | undefined) {
    if (!this.containerEl) this.initDOM();
    if (!this.containerEl) return;

    if (!userEmail) {
      this.containerEl.style.display = 'none';
      this.containerEl.innerHTML = '';
      return;
    }

    const safeEmail = escapeHtml(userEmail);
    const label = `${safeEmail} • CONFIDENTIAL © 2026 ENG. ALI SAIF AL-DEEN HAIDER AL-NAWFAL`;
    
    // Hardware-accelerated SVG pattern tile (0 DOM child elements, single GPU texture pass)
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="420" height="220"><text x="25" y="140" fill="white" font-family="monospace" font-size="12.5" font-weight="bold" transform="rotate(-22 25 140)">${label}</text></svg>`;
    const dataUrl = `url("data:image/svg+xml;utf8,${encodeURIComponent(svg)}")`;

    this.containerEl.innerHTML = '';
    this.containerEl.style.backgroundImage = dataUrl;
    this.containerEl.style.backgroundRepeat = 'repeat';
    this.containerEl.style.display = 'block';
  }
}

export const securityWatermark = SecurityWatermark.getInstance();

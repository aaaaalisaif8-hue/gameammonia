/**
 * UserDirectoryUI.ts
 * Verified Engineers & Users Directory Modal + Onboarding Registration
 * Tamper-proof, privacy-first, community prestige for registered engineers.
 * All Rights Reserved © 2026 Eng. Ali Saif Al-Deen Haider Al-Nawfal
 */

import { 
  auth, 
  DirectoryUserProfile, 
  saveUserDirectoryProfile, 
  fetchUserDirectoryProfile, 
  fetchUserDirectoryOnce,
  listenToUserDirectory 
} from './firebase';
import { escapeHtml, sanitizeUrl } from './securityUtils';
import { securityGuard } from './SecurityGuard';

export const IRAQ_GOVERNORATES = [
  'البصرة',
  'بغداد',
  'ذي قار',
  'ميسان',
  'النجف الأشرف',
  'كربلاء المقدسة',
  'بابل',
  'نينوى',
  'أربيل',
  'السليمانية',
  'كركوك',
  'الأنبار',
  'واسط',
  'ديالى',
  'القادسية (الديوانية)',
  'المثنى (السماوة)',
  'دهوك',
  'صلاح الدين',
  'خارج العراق'
];

export const ENGINEERING_DEPARTMENTS = [
  'هندسة كيمياوية',
  'هندسة ميكانيكية',
  'هندسة تقنيات النفط والغاز',
  'هندسة السيطرة والنظم والأجهزة الدقيقة',
  'هندسة العمليات والصناعات البتروكيمياوية',
  'هندسة كهربائية وإلكترونية',
  'هندسة المواد والتآكل',
  'هندسة البيئة والسلامة الصناعية (HSE)',
  'هندسة مدنية وإنشائية',
  'هندسة الحاسوب والبرمجيات الصناعية',
  'تخصص هندسي / علمي آخر'
];

export const COMMON_UNIVERSITIES = [
  'جامعة البصرة - كلية الهندسة',
  'جامعة البصرة للنفط والغاز',
  'الكلية التقنية الهندسية - البصرة',
  'جامعة بغداد - كلية الهندسة',
  'الجامعة التكنولوجية - بغداد',
  'جامعة النهرين - كلية الهندسة',
  'جامعة الكرخ للعلوم',
  'جامعة الموصل - كلية الهندسة',
  'جامعة بابل - كلية الهندسة',
  'جامعة واسط - كلية الهندسة',
  'جامعة كركوك - كلية الهندسة',
  'جامعة ميسان - كلية الهندسة',
  'جامعة ذي قار - كلية الهندسة',
  'جامعة كربلاء - كلية الهندسة',
  'جامعة الكوفة - كلية الهندسة',
  'جامعة الأنبار - كلية الهندسة',
  'جامعة تكريت - كلية الهندسة',
  'الجامعة المستنصرية - كلية الهندسة',
  'الكلية التقنية الهندسية - بغداد',
  'كلية المنصور الجامعة',
  'كلية دجلة الجامعة',
  'كلية الرافدين الجامعة',
  'جامعة / مؤسسة أكاديمية أخرى'
];

export class UserDirectoryUI {
  private static instance: UserDirectoryUI | null = null;
  private directoryModalEl: HTMLElement | null = null;
  private registerModalEl: HTMLElement | null = null;
  private allUsers: DirectoryUserProfile[] = [];
  private searchQuery: string = '';
  private selectedGovFilter: string = 'all';
  private selectedDeptFilter: string = 'all';
  private directoryUnsub: (() => void) | null = null;
  private hasPromptedRegistration: boolean = false;

  public static getInstance(): UserDirectoryUI {
    if (!UserDirectoryUI.instance) {
      UserDirectoryUI.instance = new UserDirectoryUI();
    }
    return UserDirectoryUI.instance;
  }

  private constructor() {
    if (typeof window !== 'undefined') {
      (window as any).userDirectoryUI = this;
      if (document.body) {
        this.init();
      } else {
        document.addEventListener('DOMContentLoaded', () => this.init());
      }
    }
  }

  public init() {
    this.injectStyles();
    this.createDirectoryModalDOM();
    this.createRegisterModalDOM();

    // Start directory fetching and real-time syncing
    this.startDirectoryListener();
  }

  public startDirectoryListener() {
    if (this.directoryUnsub) {
      this.directoryUnsub();
      this.directoryUnsub = null;
    }

    // Direct fetch to immediately populate registered users
    fetchUserDirectoryOnce().then((users) => {
      if (users && users.length) {
        this.allUsers = users;
        this.updateDirectoryCountBadges();
        if (this.directoryModalEl && this.directoryModalEl.style.display !== 'none') {
          this.renderDirectoryGrid();
        }
      }
    }).catch((err) => {
      console.warn("Could not perform initial directory fetch:", err);
    });

    // Real-time listener to keep directory and counters updated whenever anyone joins
    this.directoryUnsub = listenToUserDirectory((users) => {
      this.allUsers = users;
      this.updateDirectoryCountBadges();
      if (this.directoryModalEl && this.directoryModalEl.style.display !== 'none') {
        this.renderDirectoryGrid();
      }
    });
  }

  /**
   * Called whenever user logs in or out
   */
  public async onAuthChange(uid: string | null) {
    // Re-ensure directory listener is active upon auth change
    this.startDirectoryListener();

    if (!uid) {
      this.hasPromptedRegistration = false;
      return;
    }

    // Check if user has completed directory registration
    try {
      const existingProfile = await fetchUserDirectoryProfile(uid);
      if (!existingProfile && !this.hasPromptedRegistration) {
        this.hasPromptedRegistration = true;
        // Prompt them after a short delay so login UI finishes animating
        setTimeout(() => {
          this.openRegistrationModal(false);
        }, 1200);
      }
    } catch (_) {}
  }

  private updateDirectoryCountBadges() {
    const count = this.allUsers.length;
    const countStr = count > 0 ? `${count} مهندس` : 'دليل المهندسين';

    // Sidebar badge
    const sidebarBadge = document.getElementById('sidebar-user-dir-count');
    if (sidebarBadge) {
      sidebarBadge.textContent = count > 0 ? `${count}` : '0';
    }

    // Dashboard card or any other badge
    const heroBadge = document.getElementById('hero-user-dir-count');
    if (heroBadge) {
      heroBadge.textContent = countStr;
    }
  }

  private injectStyles() {
    if (document.getElementById('user-directory-styles')) return;

    const style = document.createElement('style');
    style.id = 'user-directory-styles';
    style.textContent = `
      /* User Directory Modal Backdrop */
      .dir-modal-backdrop {
        position: fixed;
        inset: 0;
        z-index: 999950;
        background: rgba(8, 10, 16, 0.94);
        display: none;
        align-items: center;
        justify-content: center;
        padding: 16px;
        direction: rtl;
        font-family: 'Cairo', system-ui, sans-serif;
      }

      .dir-modal-card {
        background: #0f172a;
        border: 1px solid rgba(56, 189, 248, 0.3);
        box-shadow: 0 25px 60px -15px rgba(0, 0, 0, 0.85), 0 0 30px rgba(56, 189, 248, 0.15);
        border-radius: 20px;
        width: 100%;
        max-width: 960px;
        max-height: 92vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        animation: dirModalFade 0.25s ease-out;
      }

      @keyframes dirModalFade {
        from { opacity: 0; transform: scale(0.96) translateY(12px); }
        to { opacity: 1; transform: scale(1) translateY(0); }
      }

      .dir-modal-header {
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.98), rgba(30, 41, 59, 0.95));
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding: 18px 24px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        flex-wrap: wrap;
      }

      .dir-modal-title-box h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 900;
        color: #38bdf8;
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .dir-modal-title-box p {
        margin: 4px 0 0;
        font-size: 12px;
        color: #94a3b8;
      }

      .dir-modal-actions {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .dir-btn-edit {
        background: rgba(14, 165, 233, 0.15);
        border: 1px solid rgba(14, 165, 233, 0.4);
        color: #38bdf8;
        font-size: 12px;
        font-weight: 700;
        padding: 8px 14px;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s;
      }

      .dir-btn-edit:hover {
        background: rgba(14, 165, 233, 0.3);
        transform: translateY(-1px);
      }

      .dir-btn-close {
        background: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.15);
        color: #e2e8f0;
        width: 34px;
        height: 34px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.2s;
      }

      .dir-btn-close:hover {
        background: rgba(239, 68, 68, 0.25);
        border-color: #ef4444;
        color: #ef4444;
      }

      /* Metric Stat Tiles */
      .dir-stats-row {
        display: flex;
        gap: 12px;
        padding: 12px 24px;
        background: rgba(15, 23, 42, 0.7);
        border-bottom: 1px solid rgba(255, 255, 255, 0.06);
        overflow-x: auto;
      }

      .dir-stat-tile {
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        padding: 8px 14px;
        display: flex;
        align-items: center;
        gap: 10px;
        white-space: nowrap;
      }

      .dir-stat-tile .num {
        font-size: 18px;
        font-weight: 900;
        color: #38bdf8;
        font-family: 'IBM Plex Mono', monospace;
      }

      .dir-stat-tile .lbl {
        font-size: 11px;
        color: #94a3b8;
      }

      /* Search & Filter Toolbar */
      .dir-toolbar {
        padding: 14px 24px;
        background: rgba(15, 23, 42, 0.5);
        border-bottom: 1px solid rgba(255, 255, 255, 0.06);
        display: flex;
        flex-direction: column;
        gap: 12px;
      }

      .dir-search-line {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
      }

      .dir-search-input-wrap {
        position: relative;
        flex: 1;
        min-width: 220px;
      }

      .dir-search-input-wrap input {
        width: 100%;
        padding: 10px 36px 10px 14px;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(56, 189, 248, 0.25);
        border-radius: 10px;
        color: #ffffff;
        font-size: 13px;
        outline: none;
        transition: all 0.2s;
        box-sizing: border-box;
      }

      .dir-search-input-wrap input:focus {
        border-color: #38bdf8;
        background: rgba(255, 255, 255, 0.08);
        box-shadow: 0 0 12px rgba(56, 189, 248, 0.2);
      }

      .dir-search-icon {
        position: absolute;
        right: 12px;
        top: 50%;
        transform: translateY(-50%);
        font-size: 14px;
        color: #38bdf8;
        pointer-events: none;
      }

      .dir-filter-select {
        padding: 10px 14px;
        background: #1e293b;
        border: 1px solid rgba(56, 189, 248, 0.25);
        border-radius: 10px;
        color: #e2e8f0;
        font-size: 12px;
        outline: none;
        cursor: pointer;
        min-width: 160px;
      }

      .dir-filter-select:focus {
        border-color: #38bdf8;
      }

      /* Directory Cards Grid */
      .dir-body-scroll {
        flex: 1;
        overflow-y: auto;
        padding: 20px 24px;
        scrollbar-width: thin;
        scrollbar-color: rgba(56, 189, 248, 0.3) rgba(15, 23, 42, 0.5);
      }

      .dir-cards-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 16px;
      }

      .dir-user-card {
        background: linear-gradient(145deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.8) 100%);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 14px;
        padding: 16px;
        display: flex;
        flex-direction: column;
        gap: 12px;
        position: relative;
        transition: all 0.25s ease;
      }

      .dir-user-card:hover {
        border-color: rgba(56, 189, 248, 0.4);
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
      }

      .dir-card-header {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .dir-user-avatar {
        width: 46px;
        height: 46px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid #38bdf8;
        background: #1e293b;
        flex-shrink: 0;
      }

      .dir-avatar-placeholder {
        width: 46px;
        height: 46px;
        border-radius: 50%;
        background: linear-gradient(135deg, #0284c7, #0369a1);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        font-size: 18px;
        font-weight: 800;
        border: 2px solid #38bdf8;
        flex-shrink: 0;
      }

      .dir-user-info {
        flex: 1;
        min-width: 0;
      }

      .dir-user-name {
        margin: 0;
        font-size: 14px;
        font-weight: 800;
        color: #f8fafc;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .dir-verified-badge {
        font-size: 13px;
        color: #38bdf8;
      }

      .dir-user-dept {
        margin: 2px 0 0;
        font-size: 11px;
        color: #38bdf8;
        font-weight: 700;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .dir-card-details {
        background: rgba(0, 0, 0, 0.25);
        border-radius: 8px;
        padding: 8px 10px;
        display: flex;
        flex-direction: column;
        gap: 6px;
        font-size: 11.5px;
        color: #cbd5e1;
      }

      .dir-detail-row {
        display: flex;
        align-items: center;
        gap: 6px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .dir-detail-icon {
        color: #94a3b8;
        font-size: 12px;
        flex-shrink: 0;
      }

      .dir-card-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-top: 8px;
        border-top: 1px solid rgba(255, 255, 255, 0.06);
        font-size: 10.5px;
        color: #64748b;
      }

      .dir-user-num {
        background: rgba(56, 189, 248, 0.12);
        color: #38bdf8;
        padding: 2px 6px;
        border-radius: 4px;
        font-weight: 700;
        font-family: 'IBM Plex Mono', monospace;
      }

      /* Empty State */
      .dir-empty-state {
        text-align: center;
        padding: 48px 20px;
        color: #94a3b8;
      }

      .dir-empty-state span {
        font-size: 42px;
        display: block;
        margin-bottom: 12px;
      }

      /* Registration / Onboarding Modal */
      .reg-form-grid {
        display: flex;
        flex-direction: column;
        gap: 14px;
        padding: 20px 24px;
      }

      .reg-form-group label {
        display: block;
        font-size: 12px;
        font-weight: 700;
        color: #cbd5e1;
        margin-bottom: 6px;
      }

      .reg-form-group input,
      .reg-form-group select {
        width: 100%;
        padding: 10px 14px;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(56, 189, 248, 0.25);
        border-radius: 10px;
        color: #ffffff;
        font-size: 13px;
        outline: none;
        box-sizing: border-box;
      }

      .reg-form-group input:focus,
      .reg-form-group select:focus {
        border-color: #38bdf8;
        box-shadow: 0 0 12px rgba(56, 189, 248, 0.2);
      }

      .reg-form-notice {
        background: rgba(56, 189, 248, 0.08);
        border: 1px solid rgba(56, 189, 248, 0.2);
        border-radius: 10px;
        padding: 12px 14px;
        font-size: 11.5px;
        color: #94a3b8;
        line-height: 1.6;
      }

      .reg-btn-submit {
        background: linear-gradient(135deg, #0284c7, #0369a1);
        border: 1px solid #38bdf8;
        color: #ffffff;
        font-size: 14px;
        font-weight: 800;
        padding: 12px;
        border-radius: 10px;
        cursor: pointer;
        width: 100%;
        margin-top: 10px;
        box-shadow: 0 4px 15px rgba(2, 132, 199, 0.4);
        transition: all 0.2s;
      }

      .reg-btn-submit:hover {
        background: linear-gradient(135deg, #0369a1, #075985);
        transform: translateY(-1px);
      }
    `;
    document.head.appendChild(style);
  }

  private createDirectoryModalDOM() {
    let el = document.getElementById('v3d-user-directory-modal');
    if (!el) {
      el = document.createElement('div');
      el.id = 'v3d-user-directory-modal';
      el.className = 'dir-modal-backdrop';
      document.body.appendChild(el);
    }
    this.directoryModalEl = el;

    el.addEventListener('click', (e) => {
      if (e.target === el) this.closeDirectory();
    });
  }

  private createRegisterModalDOM() {
    let el = document.getElementById('v3d-user-register-modal');
    if (!el) {
      el = document.createElement('div');
      el.id = 'v3d-user-register-modal';
      el.className = 'dir-modal-backdrop';
      document.body.appendChild(el);
    }
    this.registerModalEl = el;

    el.addEventListener('click', (e) => {
      if (e.target === el) this.closeRegistrationModal();
    });
  }

  /**
   * Open the full Engineers & Users Directory
   */
  public openDirectory() {
    if (!this.directoryModalEl) this.createDirectoryModalDOM();
    if (!this.directoryModalEl) return;

    const govOptions = IRAQ_GOVERNORATES.map(g => `<option value="${escapeHtml(g)}">${escapeHtml(g)}</option>`).join('');
    const deptOptions = ENGINEERING_DEPARTMENTS.map(d => `<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join('');

    this.directoryModalEl.innerHTML = `
      <div class="dir-modal-card">
        <!-- Header -->
        <div class="dir-modal-header">
          <div class="dir-modal-title-box">
            <h2><span>👥</span> دليل المهندسين والباحثين المعتمدين</h2>
            <p>سجل الكفاءات والكوادر الأكاديمية والهندسية المسجلة في منصة المحاكاة الرقمية</p>
          </div>
          <div class="dir-modal-actions">
            ${auth.currentUser ? `
              <button class="dir-btn-edit" id="dir-edit-my-profile-btn">
                <span>✏️</span> تعديل بياناتي
              </button>
            ` : ''}
            <button class="dir-btn-close" id="dir-modal-close-btn" title="إغلاق">✕</button>
          </div>
        </div>

        <!-- Metric Stat Tiles -->
        <div class="dir-stats-row">
          <div class="dir-stat-tile">
            <span class="num" id="dir-stat-total">${this.allUsers.length}</span>
            <span class="lbl">إجمالي المهندسين والباحثين</span>
          </div>
          <div class="dir-stat-tile">
            <span class="num" id="dir-stat-unis">${this.getUniqueUnisCount()}</span>
            <span class="lbl">الجامعات والمؤسسات الممثلة</span>
          </div>
          <div class="dir-stat-tile">
            <span class="num" id="dir-stat-govs">${this.getUniqueGovsCount()}</span>
            <span class="lbl">المحافظات المشاركة</span>
          </div>
        </div>

        <!-- Search & Filter Toolbar -->
        <div class="dir-toolbar">
          <div class="dir-search-line">
            <div class="dir-search-input-wrap">
              <span class="dir-search-icon">🔍</span>
              <input type="text" id="dir-search-input" value="${escapeHtml(this.searchQuery)}" placeholder="ابحث باسم المهندس، الجامعة، المحافظة، أو القسم الهندسي..." />
            </div>
            <select id="dir-gov-filter" class="dir-filter-select">
              <option value="all">📍 جميع المحافظات</option>
              ${govOptions}
            </select>
            <select id="dir-dept-filter" class="dir-filter-select">
              <option value="all">⚙️ جميع الأقسام الهندسية</option>
              ${deptOptions}
            </select>
          </div>
        </div>

        <!-- Scrollable Cards Grid -->
        <div class="dir-body-scroll">
          <div class="dir-cards-grid" id="dir-cards-grid">
            <!-- Injected via renderDirectoryGrid -->
          </div>
        </div>
      </div>
    `;

    this.directoryModalEl.style.display = 'flex';

    // Bind events
    document.getElementById('dir-modal-close-btn')?.addEventListener('click', () => this.closeDirectory());
    document.getElementById('dir-edit-my-profile-btn')?.addEventListener('click', () => {
      this.closeDirectory();
      this.openRegistrationModal(true);
    });

    const searchInput = document.getElementById('dir-search-input') as HTMLInputElement;
    searchInput?.addEventListener('input', (e) => {
      this.searchQuery = (e.target as HTMLInputElement).value.trim();
      this.renderDirectoryGrid();
    });

    const govFilter = document.getElementById('dir-gov-filter') as HTMLSelectElement;
    govFilter?.addEventListener('change', (e) => {
      this.selectedGovFilter = (e.target as HTMLSelectElement).value;
      this.renderDirectoryGrid();
    });

    const deptFilter = document.getElementById('dir-dept-filter') as HTMLSelectElement;
    deptFilter?.addEventListener('change', (e) => {
      this.selectedDeptFilter = (e.target as HTMLSelectElement).value;
      this.renderDirectoryGrid();
    });

    this.renderDirectoryGrid();

    // Re-verify latest users from cloud database
    fetchUserDirectoryOnce().then((users) => {
      if (users && users.length) {
        this.allUsers = users;
        this.updateDirectoryCountBadges();
        this.renderDirectoryGrid();
      }
    }).catch((e) => {
      console.warn("Could not refresh directory:", e);
    });
  }

  public closeDirectory() {
    if (this.directoryModalEl) {
      this.directoryModalEl.style.display = 'none';
    }
  }

  private getUniqueUnisCount(): number {
    const set = new Set(this.allUsers.map(u => u.university.trim()).filter(Boolean));
    return Math.max(1, set.size);
  }

  private getUniqueGovsCount(): number {
    const set = new Set(this.allUsers.map(u => u.governorate.trim()).filter(Boolean));
    return Math.max(1, set.size);
  }

  private renderDirectoryGrid() {
    const grid = document.getElementById('dir-cards-grid');
    if (!grid) return;

    let filtered = this.allUsers.filter((u) => {
      // Gov filter
      if (this.selectedGovFilter !== 'all' && u.governorate !== this.selectedGovFilter) {
        return false;
      }
      // Dept filter
      if (this.selectedDeptFilter !== 'all' && u.department !== this.selectedDeptFilter) {
        return false;
      }
      // Search query
      if (this.searchQuery) {
        const q = this.searchQuery.toLowerCase();
        const inName = u.displayName.toLowerCase().includes(q);
        const inUni = u.university.toLowerCase().includes(q);
        const inGov = u.governorate.toLowerCase().includes(q);
        const inDept = u.department.toLowerCase().includes(q);
        return inName || inUni || inGov || inDept;
      }
      return true;
    });

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div class="dir-empty-state" style="grid-column: 1 / -1;">
          <span>🔍</span>
          <h3 style="color:#ffffff;margin:0 0 6px;">لا توجد نتائج مطابقة لبحثك</h3>
          <p style="font-size:12px;margin:0;">جرب تغيير خيارات الفلترة أو البحث باسم آخر</p>
        </div>
      `;
      return;
    }

    grid.innerHTML = filtered.map((u, idx) => {
      const initial = (u.displayName || 'م')[0];
      const safeName = escapeHtml(u.displayName || 'مهندس متدرب');
      const safeUni = escapeHtml(u.university || 'جامعة غير محددة');
      const safeGov = escapeHtml(u.governorate || 'البصرة');
      const safeDept = escapeHtml(u.department || 'هندسة كيمياوية');
      const joinDate = u.joinedAt ? new Date(u.joinedAt).toLocaleDateString('ar-IQ') : 'مسجل حديثاً';
      const userNum = u.userNumber ? `#${String(u.userNumber).padStart(3, '0')}` : `#${String(idx + 1).padStart(3, '0')}`;
      
      const avatarHtml = u.photoURL ? 
        `<img src="${sanitizeUrl(u.photoURL, '')}" alt="${safeName}" class="dir-user-avatar" onerror="this.outerHTML='<div class=\\'dir-avatar-placeholder\\'>${initial}</div>'" />` :
        `<div class="dir-avatar-placeholder">${initial}</div>`;

      return `
        <div class="dir-user-card">
          <div class="dir-card-header">
            ${avatarHtml}
            <div class="dir-user-info">
              <h3 class="dir-user-name">
                <span>${safeName}</span>
                <span class="dir-verified-badge" title="مهندس معتمد ومسجل">✓</span>
              </h3>
              <div class="dir-user-dept">⚙️ ${safeDept}</div>
            </div>
          </div>

          <div class="dir-card-details">
            <div class="dir-detail-row" title="${safeUni}">
              <span class="dir-detail-icon">🏛️</span>
              <span>${safeUni}</span>
            </div>
            <div class="dir-detail-row" title="${safeGov}">
              <span class="dir-detail-icon">📍</span>
              <span>${safeGov}</span>
            </div>
          </div>

          <div class="dir-card-footer">
            <span>انضم: ${joinDate}</span>
            <span class="dir-user-num">${userNum}</span>
          </div>
        </div>
      `;
    }).join('');
  }

  /**
   * Open the Registration / Onboarding Modal
   */
  public async openRegistrationModal(isEditing: boolean = false) {
    if (!this.registerModalEl) this.createRegisterModalDOM();
    if (!this.registerModalEl) return;

    const user = auth.currentUser;
    if (!user) {
      securityGuard.showSecurityToast('يجب تسجيل الدخول بـ Google أولاً لتسجيل بياناتك في الدليل');
      return;
    }

    let defaultName = user.displayName || localStorage.getItem('nh3_student_name') || '';
    let defaultUni = localStorage.getItem('nh3_student_uni') || 'جامعة البصرة - كلية الهندسة';
    let defaultGov = localStorage.getItem('nh3_student_gov') || 'البصرة';
    let defaultDept = localStorage.getItem('nh3_student_dept') || 'هندسة كيمياوية';

    // If existing in cloud
    try {
      const existing = await fetchUserDirectoryProfile(user.uid);
      if (existing) {
        defaultName = existing.displayName || defaultName;
        defaultUni = existing.university || defaultUni;
        defaultGov = existing.governorate || defaultGov;
        defaultDept = existing.department || defaultDept;
      }
    } catch (_) {}

    const govOptions = IRAQ_GOVERNORATES.map(g => `
      <option value="${escapeHtml(g)}" ${g === defaultGov ? 'selected' : ''}>${escapeHtml(g)}</option>
    `).join('');

    const deptOptions = ENGINEERING_DEPARTMENTS.map(d => `
      <option value="${escapeHtml(d)}" ${d === defaultDept ? 'selected' : ''}>${escapeHtml(d)}</option>
    `).join('');

    const uniOptions = COMMON_UNIVERSITIES.map(u => `
      <option value="${escapeHtml(u)}" ${u === defaultUni ? 'selected' : ''}>${escapeHtml(u)}</option>
    `).join('');

    this.registerModalEl.innerHTML = `
      <div class="dir-modal-card" style="max-width: 540px;">
        <!-- Header -->
        <div class="dir-modal-header">
          <div class="dir-modal-title-box">
            <h2><span>🎓</span> ${isEditing ? 'تعديل بيانات المهندس في الدليل' : 'تسجيل المهندس في الدليل المعتمد'}</h2>
            <p>سجل بياناتك للانضمام إلى دليل الكفاءات الهندسية والأكاديمية لمصنع الأمونيا الرقمي</p>
          </div>
          <button class="dir-btn-close" id="reg-modal-close-btn" title="إغلاق">✕</button>
        </div>

        <form id="dir-reg-form" class="reg-form-grid">
          <div class="reg-form-notice">
            🔒 <b>حماية وخصوصية عالية:</b> لن يتم نشر بريدك الإلكتروني أو أي بيانات حساسة؛ فقط اسمك وجامعتك وقسمك ومحافظتك ليتم توثيق شهاداتك في المنصة.
          </div>

          <div class="reg-form-group">
            <label for="reg-input-name">الاسم الثلاثي أو اللقب الهندسي الكامل: *</label>
            <input type="text" id="reg-input-name" required value="${escapeHtml(defaultName)}" placeholder="مثال: م. علي سيف الدين" maxlength="100" />
          </div>

          <div class="reg-form-group">
            <label for="reg-select-uni">الجامعة / الكلية / المؤسسة الأكاديمية: *</label>
            <select id="reg-select-uni">
              ${uniOptions}
            </select>
            <input type="text" id="reg-input-uni-custom" placeholder="أو اكتب اسم جامعتك إذا لم تكن في القائمة..." style="margin-top:6px;display:none;" maxlength="100" />
          </div>

          <div class="reg-form-group">
            <label for="reg-select-gov">المحافظة: *</label>
            <select id="reg-select-gov">
              ${govOptions}
            </select>
          </div>

          <div class="reg-form-group">
            <label for="reg-select-dept">القسم الهندسي التخصصي: *</label>
            <select id="reg-select-dept">
              ${deptOptions}
            </select>
            <input type="text" id="reg-input-dept-custom" placeholder="أو اكتب تخصصك الهندسي هنا..." style="margin-top:6px;display:none;" maxlength="100" />
          </div>

          <button type="submit" class="reg-btn-submit" id="reg-btn-submit">
            💾 تثبيت التسجيل في دليل المهندسين
          </button>
        </form>
      </div>
    `;

    this.registerModalEl.style.display = 'flex';

    // Events
    document.getElementById('reg-modal-close-btn')?.addEventListener('click', () => this.closeRegistrationModal());

    const uniSelect = document.getElementById('reg-select-uni') as HTMLSelectElement;
    const uniCustom = document.getElementById('reg-input-uni-custom') as HTMLInputElement;
    uniSelect?.addEventListener('change', () => {
      if (uniSelect.value.includes('أخرى')) {
        uniCustom.style.display = 'block';
        uniCustom.focus();
      } else {
        uniCustom.style.display = 'none';
      }
    });

    const deptSelect = document.getElementById('reg-select-dept') as HTMLSelectElement;
    const deptCustom = document.getElementById('reg-input-dept-custom') as HTMLInputElement;
    deptSelect?.addEventListener('change', () => {
      if (deptSelect.value.includes('آخر')) {
        deptCustom.style.display = 'block';
        deptCustom.focus();
      } else {
        deptCustom.style.display = 'none';
      }
    });

    const form = document.getElementById('dir-reg-form') as HTMLFormElement;
    form?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = document.getElementById('reg-btn-submit') as HTMLButtonElement;
      submitBtn.disabled = true;
      submitBtn.textContent = '⏳ جاري حفظ وتوثيق البيانات...';

      const nameVal = (document.getElementById('reg-input-name') as HTMLInputElement).value.trim();
      let uniVal = uniSelect.value;
      if (uniSelect.value.includes('أخرى') && uniCustom.value.trim()) {
        uniVal = uniCustom.value.trim();
      }

      const govVal = (document.getElementById('reg-select-gov') as HTMLSelectElement).value;
      let deptVal = deptSelect.value;
      if (deptSelect.value.includes('آخر') && deptCustom.value.trim()) {
        deptVal = deptCustom.value.trim();
      }

      try {
        await saveUserDirectoryProfile({
          displayName: nameVal,
          university: uniVal,
          governorate: govVal,
          department: deptVal,
          photoURL: user.photoURL || undefined
        });

        securityGuard.showSecurityToast('تم تسجيلك بنجاح في دليل المهندسين والباحثين!');
        this.closeRegistrationModal();
        this.openDirectory();
      } catch (err: any) {
        console.error("Error saving directory profile:", err);
        securityGuard.showSecurityToast('تعذر الحفظ السحابي، تأكد من اتصال الإنترنت');
        submitBtn.disabled = false;
        submitBtn.textContent = '💾 تثبيت التسجيل في دليل المهندسين';
      }
    });
  }

  public closeRegistrationModal() {
    if (this.registerModalEl) {
      this.registerModalEl.style.display = 'none';
    }
  }
}

export const userDirectoryUI = UserDirectoryUI.getInstance();

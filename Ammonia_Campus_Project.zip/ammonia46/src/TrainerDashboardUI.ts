/**
 * TrainerDashboardUI.ts
 * Academic & Field Trainer Control Panel (لوحة المدرب والمشرف الأكاديمي)
 * Strictly accessible only if admins/{uid} document exists for authenticated user.
 */

import { fetchAllProgressForAdmin, checkIsAdmin } from './firebase';
import { escapeHtml } from './securityUtils';
import { SECTION_100_EXAM_QUESTIONS } from './three/Section100MasterExam';
import { SECTION_200_EXAM_QUESTIONS } from './three/Section200MasterExam';
import { SECTION_300_EXAM_QUESTIONS } from './three/Section300MasterExam';
import { SECTION_400_EXAM_QUESTIONS } from './three/Section400MasterExam';
import { K302_EXAM_QUESTIONS } from './three/K302AirExamMaster';
import { K303_EXAM_QUESTIONS } from './three/K303GasExamMaster';

export interface TraineeRow {
  uid: string;
  email: string;
  userName: string;
  sec100Score: number | null;
  sec200Score: number | null;
  sec300Score: number | null;
  sec400Score: number | null;
  k302Score: number | null;
  k303Score: number | null;
  lastUpdated: string;
}

export class TrainerDashboardUI {
  private static instance: TrainerDashboardUI | null = null;
  private modalEl: HTMLElement | null = null;
  private buttonEl: HTMLElement | null = null;
  private isAdminUser: boolean = false;
  private currentUID: string | null = null;

  public static getInstance(): TrainerDashboardUI {
    if (!TrainerDashboardUI.instance) {
      TrainerDashboardUI.instance = new TrainerDashboardUI();
    }
    return TrainerDashboardUI.instance;
  }

  private constructor() {
    if (typeof document !== 'undefined') {
      if (document.body) {
        this.initDOM();
      } else {
        document.addEventListener('DOMContentLoaded', () => this.initDOM());
      }
    }
  }

  private initDOM() {
    if (typeof document === 'undefined' || !document.body) return;

    // 1. Create Fixed Trainer Button
    let btn = document.getElementById('v3d-trainer-fixed-btn');
    if (!btn) {
      btn = document.createElement('button');
      btn.id = 'v3d-trainer-fixed-btn';
      btn.className = 'v3d-trainer-btn';
      btn.style.display = 'none';
      btn.innerHTML = '📊 لوحة المدرب';
      btn.title = 'لوحة تحكم المشرف والمدرب الأكاديمي لمتابعة نتائج المتدربين';
      btn.addEventListener('click', () => this.open());
      document.body.appendChild(btn);
    }
    this.buttonEl = btn;

    // 2. Create Modal DOM
    let modal = document.getElementById('v3d-trainer-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'v3d-trainer-modal';
      modal.className = 'v3d-trainer-modal';
      modal.style.display = 'none';
      document.body.appendChild(modal);
    }
    this.modalEl = modal;

    this.injectStyles();
  }

  public async onAuthChange(uid: string | null) {
    this.currentUID = uid;
    if (!uid) {
      this.isAdminUser = false;
      if (this.buttonEl) this.buttonEl.style.display = 'none';
      this.close();
      return;
    }

    try {
      this.isAdminUser = await checkIsAdmin(uid);
      if (this.buttonEl) {
        this.buttonEl.style.display = this.isAdminUser ? 'flex' : 'none';
      }
    } catch (_) {
      this.isAdminUser = false;
      if (this.buttonEl) this.buttonEl.style.display = 'none';
    }
  }

  public async open() {
    if (!this.isAdminUser) {
      alert('عذراً، هذا القسم مخصص للمدربين والمشرفين الأكاديميين المعتمدين فقط.');
      return;
    }

    if (this.modalEl) {
      this.modalEl.style.display = 'flex';
      await this.render();
    }
  }

  public close() {
    if (this.modalEl) {
      this.modalEl.style.display = 'none';
    }
  }

  private calculateScore(answers: number[] | undefined, questionBank: { correctIndex: number }[]): number | null {
    if (!answers || !Array.isArray(answers) || answers.length === 0) return null;
    let correct = 0;
    const len = Math.min(answers.length, questionBank.length);
    for (let i = 0; i < len; i++) {
      if (answers[i] === questionBank[i].correctIndex) {
        correct++;
      }
    }
    return correct;
  }

  public async render() {
    if (!this.modalEl) return;

    this.modalEl.innerHTML = `
      <div class="v3d-trainer-card">
        <div class="v3d-trainer-header">
          <div>
            <h2>📊 لوحة متابعة وتقييم المتدربين (لوحة المدرب الأكاديمي)</h2>
            <small>مجمع تصنيع وتخليق الأمونيا — سجل نتائج الاختبارات الحية الموثقة سحابياً</small>
          </div>
          <div style="display:flex;gap:10px;align-items:center;">
            <button id="v3d-trainer-refresh-btn" class="v3d-tr-btn-refresh">🔄 تحديث البيانات</button>
            <button id="v3d-trainer-close-btn" class="v3d-tr-btn-close">✕</button>
          </div>
        </div>

        <div class="v3d-trainer-body" id="v3d-trainer-table-wrap">
          <div style="text-align:center;padding:40px;color:#94a3b8;">
            <div style="font-size:24px;margin-bottom:8px;">⏳</div>
            جاري جلب سجلات الاختبارات والتقدم للمتدربين من قاعدة البيانات السحابية...
          </div>
        </div>
      </div>
    `;

    document.getElementById('v3d-trainer-close-btn')?.addEventListener('click', () => this.close());
    document.getElementById('v3d-trainer-refresh-btn')?.addEventListener('click', () => this.render());

    try {
      const records = await fetchAllProgressForAdmin();
      this.buildTraineeTable(records);
    } catch (err: any) {
      const wrap = document.getElementById('v3d-trainer-table-wrap');
      if (wrap) {
        wrap.innerHTML = `
          <div style="background:rgba(239,68,68,0.15);border:1px solid #ef4444;border-radius:10px;padding:20px;color:#fca5a5;text-align:center;">
            ⚠️ تعذر تحميل سجلات المتدربين: ${escapeHtml(err?.message || 'خطأ في جلب البيانات')}
          </div>
        `;
      }
    }
  }

  private buildTraineeTable(records: any[]) {
    const wrap = document.getElementById('v3d-trainer-table-wrap');
    if (!wrap) return;

    if (!records || records.length === 0) {
      wrap.innerHTML = `
        <div style="text-align:center;padding:40px;color:#94a3b8;font-size:14px;">
          لا توجد سجلات امتحانات مسجلة حتى الآن في السحابة. عند قيام المتدربين بحل الأسئلة ستظهر نتائجهم هنا تلقائياً.
        </div>
      `;
      return;
    }

    // Aggregate by UID
    const traineesMap: Record<string, TraineeRow> = {};

    records.forEach((rec) => {
      const uid = rec.uid || 'unknown';
      if (!traineesMap[uid]) {
        traineesMap[uid] = {
          uid,
          email: rec.email || 'بدون بريد',
          userName: rec.userName || 'متدرب',
          sec100Score: null,
          sec200Score: null,
          sec300Score: null,
          sec400Score: null,
          k302Score: null,
          k303Score: null,
          lastUpdated: rec.updatedAt || '',
        };
      }

      const answers: number[] = rec.answers || [];
      const section = rec.section;

      if (section === 'sec_100') {
        traineesMap[uid].sec100Score = this.calculateScore(answers, SECTION_100_EXAM_QUESTIONS);
      } else if (section === 'sec_200') {
        traineesMap[uid].sec200Score = this.calculateScore(answers, SECTION_200_EXAM_QUESTIONS);
      } else if (section === 'sec_300') {
        traineesMap[uid].sec300Score = this.calculateScore(answers, SECTION_300_EXAM_QUESTIONS);
      } else if (section === 'sec_400') {
        traineesMap[uid].sec400Score = this.calculateScore(answers, SECTION_400_EXAM_QUESTIONS);
      } else if (section === 'k302') {
        traineesMap[uid].k302Score = this.calculateScore(answers, K302_EXAM_QUESTIONS);
      } else if (section === 'k303') {
        traineesMap[uid].k303Score = this.calculateScore(answers, K303_EXAM_QUESTIONS);
      }

      if (rec.updatedAt && rec.updatedAt > traineesMap[uid].lastUpdated) {
        traineesMap[uid].lastUpdated = rec.updatedAt;
      }
    });

    const rows = Object.values(traineesMap);

    wrap.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <span style="font-size:12px;color:#94a3b8;">إجمالي المتدربين المسجلين: <b style="color:#38bdf8;">${rows.length}</b></span>
        <span style="font-size:11px;color:#cbd5e1;background:rgba(56,189,248,0.1);padding:3px 8px;border-radius:4px;border:1px solid #0284c7;">
          🛡️ معتمد وموثق سحابياً للمدربين فقط
        </span>
      </div>

      <div class="v3d-trainer-table-scroll">
        <table class="v3d-trainer-table">
          <thead>
            <tr>
              <th>#</th>
              <th>اسم المتدرب</th>
              <th>البريد الإلكتروني</th>
              <th>القسم 100</th>
              <th>القسم 200</th>
              <th>القسم 300</th>
              <th>القسم 400</th>
              <th>ضاغط K-302</th>
              <th>ضاغط K-303</th>
              <th>المجموع الكلي</th>
              <th>آخر تحديث</th>
            </tr>
          </thead>
          <tbody>
            ${rows.map((t, idx) => {
              const scores = [t.sec100Score, t.sec200Score, t.sec300Score, t.sec400Score, t.k302Score, t.k303Score];
              const completedCount = scores.filter(s => s !== null).length;
              const totalCorrect = scores.reduce((acc: number, s) => acc + (s !== null ? s : 0), 0);
              const maxPossible = completedCount * 100;
              const percentage = maxPossible > 0 ? Math.round((totalCorrect / maxPossible) * 100) : 0;

              const formatScore = (val: number | null) => {
                if (val === null) return `<span class="score-none">-</span>`;
                const color = val >= 75 ? '#34d399' : (val >= 50 ? '#fbbf24' : '#f87171');
                return `<b style="color:${color};">${val}/100</b>`;
              };

              return `
                <tr>
                  <td>${idx + 1}</td>
                  <td><b>${escapeHtml(t.userName)}</b></td>
                  <td dir="ltr" style="font-family:'IBM Plex Mono',monospace;font-size:11px;color:#94a3b8;">${escapeHtml(t.email)}</td>
                  <td>${formatScore(t.sec100Score)}</td>
                  <td>${formatScore(t.sec200Score)}</td>
                  <td>${formatScore(t.sec300Score)}</td>
                  <td>${formatScore(t.sec400Score)}</td>
                  <td>${formatScore(t.k302Score)}</td>
                  <td>${formatScore(t.k303Score)}</td>
                  <td>
                    ${completedCount > 0 ? `<span style="font-weight:bold;color:#38bdf8;">${totalCorrect} (${percentage}%)</span>` : '<span class="score-none">لا امتحانات</span>'}
                  </td>
                  <td style="font-size:10.5px;color:#64748b;" dir="ltr">
                    ${t.lastUpdated ? escapeHtml(t.lastUpdated.split('T')[0]) : '-'}
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  private injectStyles() {
    if (document.getElementById('v3d-trainer-dashboard-styles')) return;

    const style = document.createElement('style');
    style.id = 'v3d-trainer-dashboard-styles';
    style.textContent = `
      .v3d-trainer-btn {
        position: fixed;
        bottom: 80px;
        left: 20px;
        z-index: 99990;
        background: linear-gradient(135deg, #0284c7, #0369a1);
        color: #ffffff;
        border: 2px solid #38bdf8;
        border-radius: 30px;
        padding: 10px 18px;
        font-family: 'Cairo', system-ui, sans-serif;
        font-weight: 800;
        font-size: 13px;
        cursor: pointer;
        box-shadow: 0 8px 24px rgba(2, 132, 199, 0.4), 0 0 16px rgba(56, 189, 248, 0.3);
        display: flex;
        align-items: center;
        gap: 8px;
        transition: all 0.2s ease;
      }
      .v3d-trainer-btn:hover {
        transform: translateY(-2px) scale(1.03);
        background: #0284c7;
        box-shadow: 0 12px 30px rgba(2, 132, 199, 0.6);
      }

      .v3d-trainer-modal {
        position: fixed;
        inset: 0;
        z-index: 999995;
        background: rgba(3, 7, 18, 0.94);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        font-family: 'Cairo', system-ui, sans-serif;
        direction: rtl;
      }

      .v3d-trainer-card {
        width: 100%;
        max-width: 1100px;
        max-height: 90vh;
        background: #0f172a;
        border: 2px solid #0284c7;
        border-radius: 16px;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.9);
      }

      .v3d-trainer-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 20px;
        background: #0b1120;
        border-bottom: 1px solid #1e293b;
      }

      .v3d-trainer-header h2 {
        margin: 0;
        font-size: 16px;
        color: #38bdf8;
      }

      .v3d-trainer-header small {
        color: #94a3b8;
        font-size: 11px;
      }

      .v3d-tr-btn-refresh {
        background: #1e293b;
        color: #e2e8f0;
        border: 1px solid #334155;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 12px;
        cursor: pointer;
      }
      .v3d-tr-btn-refresh:hover {
        background: #334155;
      }

      .v3d-tr-btn-close {
        background: transparent;
        border: none;
        color: #cbd5e1;
        font-size: 18px;
        font-weight: bold;
        cursor: pointer;
        padding: 4px 8px;
      }
      .v3d-tr-btn-close:hover {
        color: #ef4444;
      }

      .v3d-trainer-body {
        padding: 20px;
        overflow-y: auto;
        flex: 1;
      }

      .v3d-trainer-table-scroll {
        overflow-x: auto;
        border: 1px solid #1e293b;
        border-radius: 8px;
      }

      .v3d-trainer-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 12px;
        text-align: right;
      }

      .v3d-trainer-table th {
        background: #1e293b;
        color: #38bdf8;
        padding: 10px 12px;
        font-weight: 700;
        border-bottom: 1px solid #334155;
        white-space: nowrap;
      }

      .v3d-trainer-table td {
        padding: 10px 12px;
        border-bottom: 1px solid #1e293b;
        color: #e2e8f0;
        white-space: nowrap;
      }

      .v3d-trainer-table tr:hover td {
        background: rgba(30, 41, 59, 0.5);
      }

      .score-none {
        color: #64748b;
        font-style: italic;
      }
    `;
    document.head.appendChild(style);
  }
}

export const trainerDashboardUI = TrainerDashboardUI.getInstance();

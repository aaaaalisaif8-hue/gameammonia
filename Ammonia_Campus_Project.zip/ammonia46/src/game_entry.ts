import { Engine3D } from './three/Engine3D';

const host = document.getElementById('app') as HTMLElement;
const engine = new Engine3D(host);
engine.start();
engine.setViewMode('ammonia_game');
const onResize = () => engine.resize();
window.addEventListener('resize', onResize);
window.addEventListener('orientationchange', () => setTimeout(onResize, 300));
setTimeout(onResize, 100);
(window as any).__engine = engine;
document.getElementById('loading')?.remove();

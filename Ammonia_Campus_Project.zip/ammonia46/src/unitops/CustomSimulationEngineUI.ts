/**
 * CustomSimulationEngineUI.ts
 * محرك المحاكاة المخصص ومصمم السيناريوهات الهندسية المتقدمة
 * يسمح للمهندس والمتدرب بإنشاء وتعديل نماذج وحركية التفاعل والتحكم وضبط المعادلات الرياضية للعمليات.
 */

import { escapeHtml } from '../securityUtils';

export interface CustomSimulationModel {
  id: string;
  nameAr: string;
  nameEn: string;
  description: string;
  feedFlow: number; // Nm3/h
  reformTemp: number; // °C
  scRatio: number; // mol/mol
  synLoopPress: number; // kg/cm2
  compressorSpeed: number; // RPM
  catacarbFlow: number; // m3/h
  activationEnergy: number; // kJ/mol
  pidKp: number;
  pidTi: number;
}

export class CustomSimulationEngineUI {
  private static instance: CustomSimulationEngineUI | null = null;
  private modalEl: HTMLElement | null = null;
  private buttonEl: HTMLElement | null = null;
  private currentModel: CustomSimulationModel = {
    id: 'custom_preset_1',
    nameAr: 'نموذج مصنع أمونيا البصرة - المحسن (Basra Advanced Model)',
    nameEn: 'Basra Ammonia Advanced Custom Model',
    description: 'نموذج محاكاة حركي متقدم مع تعديل ثوابت أرهينيوس وتفاعلات الإصلاح الأولي وحلقة التخليق.',
    feedFlow: 25000,
    reformTemp: 798.5,
    scRatio: 3.85,
    synLoopPress: 245.0,
    compressorSpeed: 10100,
    catacarbFlow: 340,
    activationEnergy: 125.4,
    pidKp: 2.0,
    pidTi: 15.0
  };
  private isRunningCustomSim: boolean = false;
  private simulationTimer: number | null = null;

  public static getInstance(): CustomSimulationEngineUI {
    if (!CustomSimulationEngineUI.instance) {
      CustomSimulationEngineUI.instance = new CustomSimulationEngineUI();
    }
    return CustomSimulationEngineUI.instance;
  }

  private constructor() {
    if (typeof document !== 'undefined') {
      if (document.body) {
        this.initDOM();
      } else {
        document.addEventListener('DOMContentLoaded', () => this.initDOM());
      }
    }
  }

  private initDOM() {
    if (typeof document === 'undefined' || !document.body) return;

    // 1. Floating Button
    let btn = document.getElementById('v3d-custom-sim-fixed-btn');
    if (!btn) {
      btn = document.createElement('button');
      btn.id = 'v3d-custom-sim-fixed-btn';
      btn.className = 'v3d-custom-sim-btn';
      btn.innerHTML = '⚙️ محرك المحاكاة الخاص';
      btn.title = 'فتح محرك المحاكاة المخصص ومصمم السيناريوهات الهندسية';
      btn.addEventListener('click', () => this.open());
      document.body.appendChild(btn);
    }
    this.buttonEl = btn;

    // 2. Modal
    let modal = document.getElementById('v3d-custom-sim-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'v3d-custom-sim-modal';
      modal.className = 'v3d-custom-sim-modal';
      modal.style.display = 'none';
      document.body.appendChild(modal);
    }
    this.modalEl = modal;

    this.injectStyles();
  }

  public open() {
    if (this.modalEl) {
      this.modalEl.style.display = 'flex';
      this.render();
    }
  }

  public close() {
    if (this.modalEl) {
      this.modalEl.style.display = 'none';
    }
  }

  private render() {
    if (!this.modalEl) return;

    const conv = (99.2 * (1 - Math.exp(-(this.currentModel.reformTemp - 700) * 0.015 * (this.currentModel.scRatio / 3.8)))).toFixed(2);
    const prodRate = (this.currentModel.feedFlow * 0.038 * (this.currentModel.synLoopPress / 245)).toFixed(1);

    this.modalEl.innerHTML = `
      <div class="v3d-cs-card">
        <div class="v3d-cs-header">
          <div style="display:flex;align-items:center;gap:12px;">
            <span style="font-size:24px;">⚙️</span>
            <div>
              <h2>محرك المحاكاة المخصص ومصمم السيناريوهات الرياضية (Custom Simulation Engine)</h2>
              <small>إدارة وتعديل نماذج حركية التفاعل، الثوابت الحرارية، سرعة الضواغط، وضبط معاملات السيطرة PID</small>
            </div>
          </div>
          <button id="v3d-cs-close-btn" class="v3d-cs-btn-close">✕</button>
        </div>

        <div class="v3d-cs-body">
          <div class="v3d-cs-grid">
            <!-- Left Panel: Parameters Form -->
            <div class="v3d-cs-form-panel">
              <h3>🎛 معاملات وحركية النموذج الرياضي</h3>
              
              <div class="v3d-cs-field">
                <label>اسم النموذج المخصص (Model Name):</label>
                <input type="text" id="cs-name" value="${escapeHtml(this.currentModel.nameAr)}" />
              </div>

              <div class="v3d-cs-row">
                <div class="v3d-cs-field">
                  <label>تدفق الغاز المغذي (Nm³/h):</label>
                  <input type="number" id="cs-feed" value="${this.currentModel.feedFlow}" step="500" min="10000" max="35000" />
                </div>
                <div class="v3d-cs-field">
                  <label>حرارة الإصلاح الأولي (°C):</label>
                  <input type="number" id="cs-temp" value="${this.currentModel.reformTemp}" step="0.5" min="700" max="850" />
                </div>
              </div>

              <div class="v3d-cs-row">
                <div class="v3d-cs-field">
                  <label>نسبة البخار للكربون (S/C):</label>
                  <input type="number" id="cs-sc" value="${this.currentModel.scRatio}" step="0.05" min="2.5" max="5.0" />
                </div>
                <div class="v3d-cs-field">
                  <label>ضغط حلقة التخليق (kg/cm²):</label>
                  <input type="number" id="cs-press" value="${this.currentModel.synLoopPress}" step="1" min="150" max="300" />
                </div>
              </div>

              <div class="v3d-cs-row">
                <div class="v3d-cs-field">
                  <label>سرعة ضاغط التخليق K-301 (RPM):</label>
                  <input type="number" id="cs-rpm" value="${this.currentModel.compressorSpeed}" step="100" min="6000" max="11500" />
                </div>
                <div class="v3d-cs-field">
                  <label>طاقة التفعيل Ea (kJ/mol):</label>
                  <input type="number" id="cs-ea" value="${this.currentModel.activationEnergy}" step="1" min="80" max="180" />
                </div>
              </div>

              <div class="v3d-cs-row">
                <div class="v3d-cs-field">
                  <label>مسيطر Kp (Proportional Gain):</label>
                  <input type="number" id="cs-kp" value="${this.currentModel.pidKp}" step="0.1" min="0.1" max="10" />
                </div>
                <div class="v3d-cs-field">
                  <label>مسيطر Ti (Integral Time s):</label>
                  <input type="number" id="cs-ti" value="${this.currentModel.pidTi}" step="1" min="1" max="60" />
                </div>
              </div>

              <div style="display:flex;gap:10px;margin-top:16px;">
                <button id="cs-save-btn" class="v3d-cs-btn-primary">💾 تطبيق وحفظ النموذج</button>
                <button id="cs-run-sim-btn" class="v3d-cs-btn-action">${this.isRunningCustomSim ? '⏹ إيقاف المحاكاة الحية' : '▶ تشغيل المحاكاة الديناميكية'}</button>
              </div>
            </div>

            <!-- Right Panel: Live Calculation & Results -->
            <div class="v3d-cs-result-panel">
              <h3>📈 نتائج ومخرجات المحرك الرياضي (Live Process Output)</h3>
              
              <div class="v3d-cs-metrics-box">
                <div class="v3d-cs-metric">
                  <span class="v3d-csm-lbl">نسبة تحويل الميثان (CH4 Conversion)</span>
                  <span class="v3d-csm-val" style="color:#38bdf8;">${conv} %</span>
                </div>
                <div class="v3d-cs-metric">
                  <span class="v3d-csm-lbl">معدل إنتاج الأمونيا المقدر (MT/Day)</span>
                  <span class="v3d-csm-val" style="color:#34d399;">${prodRate} طن/يوم</span>
                </div>
                <div class="v3d-cs-metric">
                  <span class="v3d-csm-lbl">حالة استقرار الحلقات (PID Stability)</span>
                  <span class="v3d-csm-val" style="color:#fbbf24;">مستقر (Optimal)</span>
                </div>
                <div class="v3d-cs-metric">
                  <span class="v3d-csm-lbl">معامل الأمان الحراري (Coking Margin)</span>
                  <span class="v3d-csm-val" style="color:#a855f7;">آمن (S/C > 3.2)</span>
                </div>
              </div>

              <div style="background:#090d16;border:1px solid #1e293b;border-radius:8px;padding:14px;margin-top:16px;">
                <div style="font-size:12px;color:#38bdf8;font-weight:bold;margin-bottom:6px;">💡 ملاحظة هندسية للمحرك المخصص:</div>
                <p style="font-size:11.5px;color:#94a3b8;line-height:1.6;margin:0;">
                  يستخدم هذا المحرك معادلات حركية تفاعلية تعتمد على قانون أرهينيوس مع خوارزميات الحساب العددي لمطابقة سلوك مصنع أمونيا البصرة الحقيقي في خور الزبير. يمكنك تعديل المعلمات أعلاه ورؤية الاستجابة الفورية للمخرجات.
                </p>
              </div>

              <div style="display:flex;gap:10px;margin-top:16px;">
                <button id="cs-export-btn" class="v3d-cs-btn-secondary">📤 تصدير ملف JSON للنموذج</button>
                <button id="cs-reset-btn" class="v3d-cs-btn-secondary">🔄 استعادة الإعدادات الافتراضية</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    document.getElementById('v3d-cs-close-btn')?.addEventListener('click', () => this.close());
    document.getElementById('cs-save-btn')?.addEventListener('click', () => this.saveParameters());
    document.getElementById('cs-run-sim-btn')?.addEventListener('click', () => this.toggleLiveSimulation());
    document.getElementById('cs-reset-btn')?.addEventListener('click', () => this.resetParameters());
    document.getElementById('cs-export-btn')?.addEventListener('click', () => this.exportModel());
  }

  private saveParameters() {
    const nameEl = document.getElementById('cs-name') as HTMLInputElement;
    const feedEl = document.getElementById('cs-feed') as HTMLInputElement;
    const tempEl = document.getElementById('cs-temp') as HTMLInputElement;
    const scEl = document.getElementById('cs-sc') as HTMLInputElement;
    const pressEl = document.getElementById('cs-press') as HTMLInputElement;
    const rpmEl = document.getElementById('cs-rpm') as HTMLInputElement;
    const eaEl = document.getElementById('cs-ea') as HTMLInputElement;
    const kpEl = document.getElementById('cs-kp') as HTMLInputElement;
    const tiEl = document.getElementById('cs-ti') as HTMLInputElement;

    if (nameEl) this.currentModel.nameAr = nameEl.value;
    if (feedEl) this.currentModel.feedFlow = parseFloat(feedEl.value) || 25000;
    if (tempEl) this.currentModel.reformTemp = parseFloat(tempEl.value) || 795;
    if (scEl) this.currentModel.scRatio = parseFloat(scEl.value) || 3.8;
    if (pressEl) this.currentModel.synLoopPress = parseFloat(pressEl.value) || 245;
    if (rpmEl) this.currentModel.compressorSpeed = parseFloat(rpmEl.value) || 10000;
    if (eaEl) this.currentModel.activationEnergy = parseFloat(eaEl.value) || 125;
    if (kpEl) this.currentModel.pidKp = parseFloat(kpEl.value) || 2.0;
    if (tiEl) this.currentModel.pidTi = parseFloat(tiEl.value) || 15.0;

    alert('✅ تم حفظ وضبط نموذج المحاكاة المخصص بنجاح وتم تحديث معادلات الأداء.');
    this.render();
  }

  private toggleLiveSimulation() {
    this.isRunningCustomSim = !this.isRunningCustomSim;
    if (this.isRunningCustomSim) {
      this.simulationTimer = window.setInterval(() => {
        this.currentModel.reformTemp += (Math.random() - 0.5) * 0.4;
        this.currentModel.feedFlow += (Math.random() - 0.5) * 50;
        this.render();
      }, 1000);
    } else {
      if (this.simulationTimer) {
        clearInterval(this.simulationTimer);
        this.simulationTimer = null;
      }
    }
    this.render();
  }

  private resetParameters() {
    this.currentModel = {
      id: 'custom_preset_1',
      nameAr: 'نموذج مصنع أمونيا البصرة - الافتراضي',
      nameEn: 'Basra Ammonia Default Model',
      description: 'نموذج قياسي مطابق لتصميم MHI الياباني.',
      feedFlow: 24500,
      reformTemp: 795.0,
      scRatio: 3.80,
      synLoopPress: 245.0,
      compressorSpeed: 10000,
      catacarbFlow: 330,
      activationEnergy: 125.0,
      pidKp: 2.0,
      pidTi: 15.0
    };
    alert('🔄 تمت استعادة الإعدادات الافتراضية للنموذج.');
    this.render();
  }

  private exportModel() {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(this.currentModel, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "basra_ammonia_custom_simulation_model.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  }

  private injectStyles() {
    if (document.getElementById('v3d-custom-sim-styles')) return;

    const style = document.createElement('style');
    style.id = 'v3d-custom-sim-styles';
    style.textContent = `
      .v3d-custom-sim-btn {
        position: fixed;
        bottom: 135px;
        left: 20px;
        z-index: 99990;
        background: linear-gradient(135deg, #059669, #047857);
        color: #ffffff;
        border: 2px solid #34d399;
        border-radius: 30px;
        padding: 10px 18px;
        font-family: 'Cairo', system-ui, sans-serif;
        font-weight: 800;
        font-size: 13px;
        cursor: pointer;
        box-shadow: 0 8px 24px rgba(5, 150, 105, 0.4), 0 0 16px rgba(52, 211, 153, 0.3);
        display: flex;
        align-items: center;
        gap: 8px;
        transition: all 0.2s ease;
      }
      .v3d-custom-sim-btn:hover {
        transform: translateY(-2px) scale(1.03);
        background: #059669;
        box-shadow: 0 12px 30px rgba(5, 150, 105, 0.6);
      }

      .v3d-custom-sim-modal {
        position: fixed;
        inset: 0;
        z-index: 999995;
        background: rgba(3, 7, 18, 0.94);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        font-family: 'Cairo', system-ui, sans-serif;
        direction: rtl;
      }

      .v3d-cs-card {
        width: 100%;
        max-width: 1050px;
        max-height: 90vh;
        background: #0f172a;
        border: 2px solid #059669;
        border-radius: 16px;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.9);
      }

      .v3d-cs-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 20px;
        background: #0b1120;
        border-bottom: 1px solid #1e293b;
      }

      .v3d-cs-header h2 {
        margin: 0;
        font-size: 16px;
        color: #34d399;
      }

      .v3d-cs-header small {
        color: #94a3b8;
        font-size: 11px;
      }

      .v3d-cs-btn-close {
        background: transparent;
        border: none;
        color: #cbd5e1;
        font-size: 18px;
        font-weight: bold;
        cursor: pointer;
        padding: 4px 8px;
      }
      .v3d-cs-btn-close:hover {
        color: #ef4444;
      }

      .v3d-cs-body {
        padding: 24px;
        overflow-y: auto;
        flex: 1;
      }

      .v3d-cs-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 24px;
      }
      @media(max-width: 768px) {
        .v3d-cs-grid { grid-template-columns: 1fr; }
      }

      .v3d-cs-form-panel h3, .v3d-cs-result-panel h3 {
        margin: 0 0 16px 0;
        font-size: 14px;
        color: #38bdf8;
        border-bottom: 1px solid #1e293b;
        padding-bottom: 8px;
      }

      .v3d-cs-field {
        margin-bottom: 14px;
      }

      .v3d-cs-field label {
        display: block;
        font-size: 12px;
        color: #cbd5e1;
        margin-bottom: 6px;
      }

      .v3d-cs-field input {
        width: 100%;
        background: #090d16;
        border: 1px solid #334155;
        color: #ffffff;
        padding: 8px 12px;
        border-radius: 6px;
        font-family: 'Cairo', system-ui, sans-serif;
        font-size: 13px;
      }
      .v3d-cs-field input:focus {
        border-color: #059669;
        outline: none;
      }

      .v3d-cs-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
      }

      .v3d-cs-btn-primary {
        background: linear-gradient(135deg, #059669, #047857);
        color: #ffffff;
        border: none;
        padding: 10px 16px;
        border-radius: 8px;
        font-weight: bold;
        font-size: 13px;
        cursor: pointer;
        flex: 1;
      }
      .v3d-cs-btn-primary:hover {
        background: #047857;
      }

      .v3d-cs-btn-action {
        background: #1e293b;
        color: #38bdf8;
        border: 1px solid #334155;
        padding: 10px 16px;
        border-radius: 8px;
        font-weight: bold;
        font-size: 13px;
        cursor: pointer;
      }
      .v3d-cs-btn-action:hover {
        background: #334155;
      }

      .v3d-cs-btn-secondary {
        background: #1e293b;
        color: #cbd5e1;
        border: 1px solid #334155;
        padding: 8px 14px;
        border-radius: 6px;
        font-size: 12px;
        cursor: pointer;
      }
      .v3d-cs-btn-secondary:hover {
        background: #334155;
        color: #ffffff;
      }

      .v3d-cs-metrics-box {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
      }

      .v3d-cs-metric {
        background: #090d16;
        border: 1px solid #1e293b;
        border-radius: 8px;
        padding: 14px;
        text-align: center;
      }

      .v3d-csm-lbl {
        display: block;
        font-size: 11px;
        color: #94a3b8;
        margin-bottom: 6px;
      }

      .v3d-csm-val {
        font-size: 18px;
        font-weight: bold;
        font-family: 'IBM Plex Mono', monospace;
      }
    `;
    document.head.appendChild(style);
  }
}

export const customSimulationEngineUI = CustomSimulationEngineUI.getInstance();

/**
 * data_comp_300.ts
 * Process Flow Diagram Data for Process Air Compressor K-302 & Natural Gas Compressor K-303
 * Blueprint: DWG NO. 6112P 100-300-00
 * Project: IRAQ NO. 3 PROJECT / M.O.I. IRAQ - FERTILIZER PROJECT, KHOR AL-ZUBAIR PHASE-1
 * EXCLUSIVELY: PROCESS AIR COMPRESSOR K-302 & NATURAL GAS COMPRESSOR K-303
 * (K-301 is completely separated in DWG NO. 6112P 100-301-00)
 */

import { PFDStreamData, PFDEquipment, PFDSheetInfo } from './types';

export const SHEET_COMP_300_INFO: PFDSheetInfo = {
  id: 'comp_300',
  dwgNo: 'DWG NO. 6112P 100-300-00',
  title: 'PROCESS AIR COMPRESSOR K-302 & NATURAL GAS COMPRESSOR K-303 PFD',
  titleAr: 'مخطط ضواغط الهواء والغاز الطبيعي K-302 و K-303 ومبرداتها وفواصلها',
  orderNo: '563030-012',
  date: '9.19.\'75',
  customer: 'FERTILIZER & AMMONIA COMPLEX - COMPRESSORS SECTION',
  filters: [
    { id: 'all', label: 'All Compressors (K-302 & K-303)', labelAr: 'المخطط الكامل (K-302 و K-303)' },
    { id: 'k302', label: 'Process Air K-302', labelAr: 'ضاغط هواء العمليات K-302' },
    { id: 'k303', label: 'Natural Gas K-303', labelAr: 'ضاغط الغاز الطبيعي K-303' },
    { id: 'coolers_sep', label: 'Coolers & Knockouts', labelAr: 'المبردات والفواصل E-305..308 / V-305..308' }
  ]
};

export const STREAMS_COMP_300: Record<number, PFDStreamData> = {
  7: {
    id: 7,
    name: "PROCESS AIR TO GAS REFORM SECT. (R-102 MIXER)",
    nameAr: "هواء العمليات المضغوط المتجه للمصلح الثانوي R-102 بقسم الإصلاح",
    pressure: "35.0 kg/cm²A (34.0 kg/cm²G)",
    temperature: "167.0",
    flowKgH: "50,590 (Wet) / 50,390 (Dry)",
    dryGasMolH: "1,739.31",
    wetGasMolH: "1,750.50",
    h2oMolH: "11.19",
    dryGasTh: "50.390",
    wetGasTh: "50.590",
    dryMw: "28.97",
    wetMw: "28.90",
    comp: {
      n2: "78.04 % (1,357.36 mol/h)",
      o2: "20.99 % (365.08 mol/h)",
      ar: "0.74 % (16.35 mol/h)",
      co2: "0.03 % (0.52 mol/h)"
    }
  },
  8: {
    id: 8,
    name: "NATURAL GAS FROM B.L (V-115 B.L)",
    nameAr: "الغاز الطبيعي الخام الوارد من حدود البطارية (Battery Limit V-115)",
    pressure: "19.0 (Normal kg/cm²A)",
    temperature: "40.0",
    flowKgH: "27,725 (Wet) / 22,450 (Dry)",
    dryGasMolH: "977.25",
    wetGasMolH: "979.40",
    h2oMolH: "2.15",
    dryGasTh: "22.450",
    wetGasTh: "27.725",
    dryMw: "22.45",
    wetMw: "21.61",
    comp: {
      ch4: "72.46 % (708.11 mol/h)",
      c2h6: "15.40 % (150.50 mol/h)",
      c3h8: "5.89 % (57.56 mol/h)",
      c4h10: "2.23 % (21.79 mol/h)",
      co2: "2.08 % (20.33 mol/h)",
      c5h12: "0.72 % (7.04 mol/h)",
      c6plus: "0.65 % (6.35 mol/h)",
      ar: "0.57 % (5.57 mol/h)"
    }
  },
  9: {
    id: 9,
    name: "NATURAL GAS TO GAS REFORM SECTION (DESULFURIZATION)",
    nameAr: "الغاز الطبيعي المضغوط المتجه لقسم إزالة الكبريت والإصلاح الأولي",
    pressure: "41.0 kg/cm²A (40.0 kg/cm²G)",
    temperature: "117.0",
    flowKgH: "104,226 (Combined Recycle) / 23,610 (Dry Net)",
    dryGasMolH: "1,042.04",
    wetGasMolH: "1,042.26",
    h2oMolH: "0.22",
    dryGasTh: "23.610",
    wetGasTh: "104.226",
    dryMw: "21.61",
    wetMw: "21.61",
    comp: {
      ch4: "68.01 % (708.66 mol/h)",
      c2h6: "14.44 % (150.50 mol/h)",
      c3h8: "5.52 % (57.56 mol/h)",
      h2: "4.60 % (47.93 mol/h)",
      c4h10: "2.09 % (21.79 mol/h)",
      co2: "1.95 % (20.33 mol/h)",
      n2: "1.53 % (16.00 mol/h)",
      c5h12: "0.68 % (7.04 mol/h)",
      c6plus: "0.62 % (6.35 mol/h)",
      ar: "0.56 % (5.83 mol/h)"
    }
  }
};

export const EQUIPMENT_COMP_300: Record<string, PFDEquipment> = {
  // ==========================================
  // PROCESS AIR COMPRESSOR K-302 TRAIN
  // ==========================================
  "K-302": {
    tag: "K-302",
    name: "PROCESS AIR COMPRESSOR TRAIN",
    nameAr: "قطار ضاغط هواء العمليات K-302 (جسمان + 4 مراحل + توربين K-302T)",
    pressIn: "1.00 IN / 1.033 kg/cm²A (Atmospheric)",
    pressOut: "34.0 kg/cm²G (~35.0 kg/cm²A) / 167 °C",
    tempIn: "41.0 °C (Ambient Air)",
    tempOut: "167.0 °C",
    descAr: "ضاغط هواء طرد مركزي مكوّن من كيسين/جسمين (Case 1 & Case 2) وتوربين بخاري دافع K-302T. يسحب الهواء الجوي عبر مدخنة H-301 وفلتر F-301 وفاصل V-308. يُبرّد الهواء مرحلياً عبر E-305 و E-306 و E-307 مع فصل الماء المتكثف في V-305 و V-306 و V-307 وطرحه للمجاري. قبل المرحلة الرابعة تُسحب 3 تفريعات: 1) لوحدة اليوريا (خمولة التآكل)، 2) لأكسدة محلول الكاتاكارب (حماية الفناديوم V5+)، 3) لمجفف هواء الأجهزة (Instrument Air Dryer). يضغط الكباس الهواء في المرحلة 4 إلى 34 kg/cm²G ويُضخ للمصلح الثانوي R-102. يتم التحكم بضغط الطرد عبر سرعة التوربين، وحماية الارتجاف (Anti-Surge) عبر تنفيس الهواء للجو (Atmospheric Blow-off).",
    x: 320,
    y: 440,
    w: 520,
    h: 220
  },
  "K-302-TURB": {
    tag: "K-302 TURBINE",
    name: "STEAM TURBINE DRIVER (K-302T)",
    nameAr: "التوربين البخاري الدافع لضاغط الهواء ومتحكم السرعة",
    pressIn: "39.0 kg/cm²A (S-39 Steam)",
    pressOut: "3.5 kg/cm²A (Exhaust S-3)",
    tempIn: "385 °C",
    descAr: "توربين بخاري يقود كبائن ضغط الهواء ويتحكم بسرعة الدوران (Turbine Speed Control) للحفاظ على ضغط الطرد عند 34 kg/cm²G وتأمين كمية الأكسجين والنيتروجين بدقة لخلّاط المصلح الثانوي R-102.",
    x: 230,
    y: 520,
    w: 80,
    h: 100
  },
  "K-302-C1": {
    tag: "K-302 CASE 1",
    name: "PROCESS AIR COMPRESSOR - CASE 1 (STAGES 1 & 2)",
    nameAr: "الجسم الأول لضاغط الهواء (المرحلة 1 و 2)",
    pressIn: "1.00 IN (Atmospheric)",
    pressOut: "6.52 kg/cm²A",
    tempIn: "41.0 °C",
    tempOut: "194.6 °C / 185.0 °C",
    descAr: "المراحل الأولية لضغط الهواء الجوي مع التبريد البيني عبر المبردات E-305 و E-306 وفصل المياه المتكثفة عبر الفواصل V-305 و V-306 إلى شبكة التصريف (Sewer).",
    x: 340,
    y: 490,
    w: 150,
    h: 135
  },
  "K-302-C2": {
    tag: "K-302 CASE 2",
    name: "PROCESS AIR COMPRESSOR - CASE 2 (STAGES 3 & 4)",
    nameAr: "الجسم الثاني لضاغط الهواء (المرحلة 3 و 4)",
    pressIn: "6.52 kg/cm²A",
    pressOut: "34.0 kg/cm²G (Normal ~35.0 kg/cm²A)",
    tempIn: "43.0 °C",
    tempOut: "167.0 °C",
    descAr: "الجسم الثاني لضاغط الهواء؛ قبل دخوله المرحلة الرابعة يتم سحب حصص الهواء لوحدة اليوريا وأكسدة الكاتاكارب ومجفف هواء الأجهزة (Instrument Air Dryer)، ثم يُكبس تيار الهواء المتبقي في المرحلة الرابعة ليصل إلى 34 kg/cm²G باتجاه المصلح الثانوي R-102.",
    x: 520,
    y: 490,
    w: 150,
    h: 135
  },
  "H-301": {
    tag: "H-301",
    name: "AIR INTAKE STACK & SILENCER",
    nameAr: "برج وسحّاب سحب الهواء الجوي مع كاتم الصوت",
    descAr: "مدخنة سحب هواء مرتفعة مزودة بشبكات حماية وستائر توجيه وكاتم صوت لمنع دخول الأجسام الغريبة وخفض الضجيج الناتج عن سحب كميات هائلة من الهواء الجوي (50.5 طن/ساعة).",
    x: 60,
    y: 380,
    w: 55,
    h: 100
  },
  "F-301": {
    tag: "F-301",
    name: "AIR INTAKE FILTER",
    nameAr: "مرشح سحب هواء العمليات",
    deltaP: "ΔP = 0.008 kg/cm²",
    descAr: "فلتر فائق الكفاءة متعدد المراحل لتنقية الهواء الجوي من الغبار والرمال والشوائب الدقيقة قبل دخوله إلى ضاغط الهواء K-302 لحماية الريش والتوربين من التآكل.",
    x: 135,
    y: 400,
    w: 60,
    h: 70
  },
  "V-308": {
    tag: "V-308",
    name: "SUCTION AIR SEPARATOR",
    nameAr: "فاصل سحب الهواء الأولي",
    deltaP: "ΔP = 0.012 kg/cm²",
    descAr: "وعاء فاصل عند مدخل الضاغط لمنع أي قطرات ماء أو شوائب من الدخول لريش المرحلة الأولى.",
    x: 215,
    y: 400,
    w: 50,
    h: 75
  },
  "E-305": {
    tag: "E-305",
    name: "1st STAGE AIR COOLER",
    nameAr: "مبرد المرحلة الأولى لهواء العمليات",
    duty: "3.483 × 10⁶ kcal/h",
    deltaP: "ΔPs = 0.25 kg/cm²",
    tempIn: "194.6 °C",
    tempOut: "43.0 °C",
    pressIn: "2.91 kg/cm²A",
    descAr: "مبرد بيني يبرد الهواء الخارج من المرحلة الأولى لضاغط الهواء ويفصل كميات كبيرة من رطوبة الجو في الفاصل V-305 بمعدل تصريف 2,271 كغم/ساعة.",
    x: 410,
    y: 280,
    w: 80,
    h: 55
  },
  "V-305": {
    tag: "V-305",
    name: "1st STAGE AIR SEPARATOR",
    nameAr: "فاصل رطوبة المرحلة الأولى للهواء",
    deltaP: "ΔP = 0.02 kg/cm²",
    descAr: "يفصل كميات كبيرة من رطوبة الجو المتكثفة بعد E-305 بمعدل تصريف 2,271 كغم/ساعة وطرحها للمجاري.",
    x: 425,
    y: 180,
    w: 50,
    h: 80
  },
  "E-306": {
    tag: "E-306",
    name: "2nd STAGE AIR COOLER",
    nameAr: "مبرد المرحلة الثانية لهواء العمليات",
    duty: "2.326 × 10⁶ kcal/h",
    deltaP: "ΔPs = 0.25 kg/cm²",
    tempIn: "185.0 °C",
    tempOut: "43.0 °C",
    pressIn: "6.52 kg/cm²A",
    descAr: "مبرد بيني ثاني للهواء مع فاصل تكثيف V-306 يزيل 721 كغم/ساعة من مياه الرطوبة المتكثفة.",
    x: 520,
    y: 280,
    w: 80,
    h: 55
  },
  "V-306": {
    tag: "V-306",
    name: "2nd STAGE AIR SEPARATOR",
    nameAr: "فاصل رطوبة المرحلة الثانية للهواء",
    deltaP: "ΔP = 0.04 kg/cm²",
    descAr: "يفصل المكثفات المائية الناتجة عن تبريد المرحلة الثانية للهواء بمعدل 721 كغم/ساعة وطرحها للمجاري.",
    x: 535,
    y: 180,
    w: 50,
    h: 80
  },
  "E-307": {
    tag: "E-307",
    name: "3rd STAGE AIR COOLER",
    nameAr: "مبرد المرحلة الثالثة لهواء العمليات",
    duty: "1.739 × 10⁶ kcal/h",
    deltaP: "ΔPs = 0.25 kg/cm²",
    tempIn: "163.9 °C",
    tempOut: "43.0 °C",
    pressIn: "15.38 kg/cm²A",
    descAr: "مبرد بيني ثالث للهواء مع فاصل V-307 لتجفيف الهواء المضغوط قبل دخوله للمرحلة الرابعة والأخيرة.",
    x: 630,
    y: 280,
    w: 80,
    h: 55
  },
  "V-307": {
    tag: "V-307",
    name: "3rd STAGE AIR SEPARATOR",
    nameAr: "فاصل رطوبة المرحلة الثالثة للهواء",
    deltaP: "ΔP = 0.04 kg/cm²",
    descAr: "يفصل قطرات الرطوبة الدقيقة الناتجة بعد E-307 بمعدل 254 كغم/ساعة لضمان جفاف الهواء الداخل للمرحلة النهائية.",
    x: 645,
    y: 180,
    w: 50,
    h: 80
  },

  // ==========================================
  // NATURAL GAS COMPRESSOR K-303 TRAIN
  // ==========================================
  "K-303": {
    tag: "K-303",
    name: "NATURAL GAS COMPRESSOR TRAIN",
    nameAr: "ضاغط الغاز الطبيعي K-303 (تغذية قسم تحويل الغاز والإصلاح ومحارق R-101)",
    pressIn: "19.0 kg/cm²A (Normal from B.L)",
    pressOut: "40.0 kg/cm²G (~41.0 kg/cm²A) / 117 °C",
    tempIn: "40.0 °C",
    tempOut: "117.0 °C",
    descAr: "ضاغط طرد مركزي يدار بتوربين بخاري K-303-TURB. يستلم الغاز الطبيعي من حدود البطارية (Battery Limit) عبر فاصل تصريف السوائل V-111 لحجز أي قطرات سائلة، ويضغطه من 19 كغم/سم² إلى 40 kg/cm²G (حوالي 41 كغم/سم² مطلق) ليدفعه إلى قسم تحويل الغاز (التسخين الأولي، إزالة الكبريت ومحارق R-101). يُضبط ضغط الطرد بالتحكم بسرعة التوربين، وتتحقق الحماية من الارتجاف (Anti-Surge) عبر تدوير الغاز من الطرد إلى السحب بعد تبريده في مبرد التدوير E-308.",
    x: 1050,
    y: 470,
    w: 300,
    h: 200
  },
  "K-303-TURB": {
    tag: "K-303 TURBINE",
    name: "STEAM TURBINE DRIVER (K-303T)",
    nameAr: "التوربين البخاري الدافع لضاغط الغاز الطبيعي ومتحكم السرعة",
    pressIn: "39.0 kg/cm²A (S-39)",
    pressOut: "3.5 kg/cm²A (S-3)",
    descAr: "توربين بخاري يقود ضاغط الغاز الطبيعي K-303، ويتحكم بضغط الطرد (40 kg/cm²G) عن طريق تنظيم سرعة دوران العمود بدقة لتلبية احتياجات قسم تحويل الغاز.",
    x: 1040,
    y: 535,
    w: 75,
    h: 95
  },
  "V-111": {
    tag: "V-111",
    name: "NATURAL GAS DRAIN SEPARATOR",
    nameAr: "فاصل قطرات ومكثفات الغاز الطبيعي",
    deltaP: "ΔP = 0.03 kg/cm²",
    pressIn: "19.0 kg/cm²A",
    descAr: "وعاء فاصل عمودي عند مدخل ضاغط الغاز الطبيعي K-303 لفصل أي سوائل هيدروكربونية ثقيلة أو مياه متجمعة في شبكة الغاز وتصريفها لمنع دخول أي سائل لريش الضاغط.",
    x: 1150,
    y: 220,
    w: 55,
    h: 95
  },
  "E-308": {
    tag: "E-308",
    name: "NATURAL GAS BY-PASS COOLER",
    nameAr: "مبرد خط التدوير الجانبي لضاغط الغاز الطبيعي (Anti-Surge)",
    duty: "0.693 × 10⁶ kcal/h",
    deltaP: "ΔPt = 0.50 kg/cm²",
    tempIn: "117.0 °C",
    tempOut: "43.0 °C",
    pressIn: "41.0 kg/cm²A",
    descAr: "مبادل تبريد على خط التدوير الراجع (Recycle By-pass) لمنع ارتفاع حرارة الغاز أثناء تشغيل الضاغط في حالات انخفاض الحمل أو الحماية من الارتجاف (Anti-Surge).",
    x: 1260,
    y: 320,
    w: 80,
    h: 55
  }
};

/**
 * render_k301_svg.ts
 * Dedicated Vector Blueprint Renderer for DWG NO. 6112P 100-301-00
 * Ammonia Unit - Synthesis Gas Compressor K-301 & Circulator Train (Standalone Section)
 */

import { renderShellAndTubeSVG } from './render_shell_and_tube';

export function renderK301SVG(showParticles: boolean): string {
  const isAnim = showParticles ? 'pfd-pipe-anim' : '';

  // Intercoolers for K-301
  const e301Svg = renderShellAndTubeSVG({
    tag: 'E-301',
    nameAr: 'مبرد غاز التغذية لسحب المرحلة الأولى',
    temaType: 'AES / Raw Gas Cooler',
    tagColor: '#0284c7',
    x: 170,
    y: 650,
    width: 110,
    height: 52,
    tubeSide: {
      fluidAr: 'غاز التخليق الخام (H2+N2)',
      tempIn: '129.3°C',
      tempOut: '43.0°C',
      color: '#0284c7',
      inPos: 'axial-left',
      outPos: 'axial-right'
    },
    shellSide: {
      fluidAr: 'مياه التبريد CW',
      tempIn: '32°C',
      tempOut: '40°C',
      color: '#00c8ef',
      inPos: 'bottom',
      outPos: 'top'
    }
  });

  const e302Svg = renderShellAndTubeSVG({
    tag: 'E-302',
    nameAr: 'مبرد المرحلة الأولى البيني',
    temaType: 'AES / Intercooler 1',
    tagColor: '#0284c7',
    x: 520,
    y: 190,
    width: 110,
    height: 52,
    tubeSide: {
      fluidAr: 'غاز مضغوط مرحلة 1',
      tempIn: '135.0°C',
      tempOut: '43.0°C',
      color: '#0284c7',
      inPos: 'axial-left',
      outPos: 'axial-right'
    },
    shellSide: {
      fluidAr: 'مياه التبريد CW',
      tempIn: '32°C',
      tempOut: '42°C',
      color: '#00c8ef',
      inPos: 'bottom',
      outPos: 'top'
    }
  });

  const e303Svg = renderShellAndTubeSVG({
    tag: 'E-303',
    nameAr: 'مبرد المرحلة الثانية البيني',
    temaType: 'AES / Intercooler 2',
    tagColor: '#0284c7',
    x: 690,
    y: 650,
    width: 110,
    height: 52,
    tubeSide: {
      fluidAr: 'غاز مضغوط مرحلة 2',
      tempIn: '142.0°C',
      tempOut: '43.0°C',
      color: '#0284c7',
      inPos: 'axial-left',
      outPos: 'axial-right'
    },
    shellSide: {
      fluidAr: 'مياه التبريد CW',
      tempIn: '32°C',
      tempOut: '42°C',
      color: '#00c8ef',
      inPos: 'bottom',
      outPos: 'top'
    }
  });

  const e304Svg = renderShellAndTubeSVG({
    tag: 'E-304',
    nameAr: 'مبرد المرحلة الثالثة عالي الضغط',
    temaType: 'AES / HP Cooler 3',
    tagColor: '#0284c7',
    x: 880,
    y: 650,
    width: 110,
    height: 52,
    tubeSide: {
      fluidAr: 'غاز مضغوط مرحلة 3 HP',
      tempIn: '138.0°C',
      tempOut: '43.0°C',
      color: '#0284c7',
      inPos: 'axial-left',
      outPos: 'axial-right'
    },
    shellSide: {
      fluidAr: 'مياه التبريد CW',
      tempIn: '32°C',
      tempOut: '42°C',
      color: '#00c8ef',
      inPos: 'bottom',
      outPos: 'top'
    }
  });

  const e315Svg = renderShellAndTubeSVG({
    tag: 'E-315',
    nameAr: 'مبرد غاز التدوير الراجع',
    temaType: 'BEU / Recycle Cooler',
    tagColor: '#7c3aed',
    x: 770,
    y: 80,
    width: 110,
    height: 52,
    tubeSide: {
      fluidAr: 'غاز التدوير الراجع (Recycle)',
      tempIn: '55.0°C',
      tempOut: '43.0°C',
      color: '#7c3aed',
      inPos: 'axial-right',
      outPos: 'axial-left'
    },
    shellSide: {
      fluidAr: 'مياه التبريد CW',
      tempIn: '32°C',
      tempOut: '38°C',
      color: '#00c8ef',
      inPos: 'bottom',
      outPos: 'top'
    }
  });

  return `
    <!-- BLUEPRINT DRAWING 6112P-100-301-00 GRAPHICS -->
    <g id="pfd-k301-layers">
      
      <!-- ========================================== -->
      <!-- COMPACT PROCESS SYMBOLS LEGEND (Bottom Right) -->
      <!-- ========================================== -->
      <g transform="translate(1620, 940)">
        <rect width="260" height="120" fill="rgba(248,250,252,0.92)" stroke="#334155" stroke-width="1.2" rx="6"/>
        <text x="12" y="20" fill="#0f172a" font-size="11" font-weight="800" font-family="'Cairo', sans-serif">دليل الرموز والمؤشرات (Legend)</text>
        <line x1="8" y1="28" x2="252" y2="28" stroke="#cbd5e1" stroke-width="1"/>
        <g transform="translate(14, 40)">
          <polygon points="0,7 7,0 14,7 7,14" fill="#0284c7" stroke="#0f172a" stroke-width="1"/>
          <text x="22" y="11" fill="#0f172a" font-size="10" font-weight="700">Stream No. (رقم المسار)</text>
          <circle cx="7" cy="28" r="7" fill="#e0f2fe" stroke="#0284c7" stroke-width="1"/>
          <text x="22" y="32" fill="#0f172a" font-size="10" font-weight="700">Press. kg/cm²A (الضغط)</text>
          <rect x="0" y="44" width="16" height="12" rx="3" fill="#fef3c7" stroke="#d97706" stroke-width="1"/>
          <text x="22" y="54" fill="#0f172a" font-size="10" font-weight="700">Temp. °C (درجة الحرارة)</text>
          <rect x="0" y="62" width="16" height="12" fill="#dcfce7" stroke="#16a34a" stroke-width="1"/>
          <text x="22" y="72" fill="#0f172a" font-size="10" font-weight="700">Flow kg/h (معدل التدفق)</text>
        </g>
      </g>

      <!-- ========================================== -->
      <!-- PIPING LINES LAYER -->
      <!-- ========================================== -->
      <g id="pfd-k301-piping">
        
        <!-- Stream 1: Inflow from Gas Reform E-114 -> E-301 -> V-301 -->
        <path d="M 60 770 L 225 770 L 225 704" fill="none" stroke="#0284c7" stroke-width="4" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>
        <path d="M 225 650 L 225 600 L 355 600 L 355 618" fill="none" stroke="#0284c7" stroke-width="3.5" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>
        
        <!-- Stream 2: V-301 overhead -> K-301 Case 1 Suction (25.5 kg/cm²) -->
        <path d="M 355 560 L 355 490 L 490 490 L 490 460" fill="none" stroke="#0284c7" stroke-width="4" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>

        <!-- K-301 Case 1 Discharge -> E-302 -> V-302 -> K-301 Case 2 Suction -->
        <path d="M 505 380 L 505 270 L 575 270 L 575 244" fill="none" stroke="#0284c7" stroke-width="3.5" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>
        <path d="M 575 190 L 575 160 L 472 160 L 472 238" fill="none" stroke="#0284c7" stroke-width="3.5" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>
        <path d="M 472 190 L 472 140 L 785 140 L 785 378" fill="none" stroke="#0284c7" stroke-width="3.5" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>

        <!-- K-301 Case 2 Discharge -> E-303 -> V-303 -> K-301 Case 3 Suction -->
        <path d="M 800 460 L 800 580 L 745 580 L 745 648" fill="none" stroke="#0284c7" stroke-width="3.5" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>
        <path d="M 745 704 L 745 740 L 612 740 L 612 702" fill="none" stroke="#0284c7" stroke-width="3.5" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>
        <path d="M 612 650 L 612 550 L 920 550 L 920 460" fill="none" stroke="#0284c7" stroke-width="3.5" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>

        <!-- K-301 Case 3 Discharge -> E-304 -> V-304 -> 4th Stage -> Stream 3 To NH3 Synthesis Loop -->
        <path d="M 940 460 L 940 580 L 935 580 L 935 648" fill="none" stroke="#0284c7" stroke-width="4" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>
        <path d="M 935 704 L 935 740 L 952 740 L 952 702" fill="none" stroke="#0284c7" stroke-width="4" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>
        <path d="M 952 650 L 952 560 L 1030 560 L 1030 460" fill="none" stroke="#0284c7" stroke-width="4" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>
        <!-- Final HP Discharge Line to Synthesis Loop (240.5 kg/cm²) -->
        <path d="M 1030 380 L 1030 300 L 1260 300 L 1260 770 L 1340 770" fill="none" stroke="#0284c7" stroke-width="4.5" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>

        <!-- RECYCLE LOOP (Stream 4 & Stream 5): Syn Loop Recycle to K-301 Case 3 Circulator Wheel -->
        <!-- Stream 4 from Synth Sect. (220 kg/cm²) -> Circulator Inflow -->
        <path d="M 60 90 L 970 90 L 970 378" fill="none" stroke="#8b5cf6" stroke-width="4" marker-end="url(#pfdArrowPurple)" class="${isAnim}"/>
        <!-- Circulator Discharge -> E-315 -> V-310 -> Stream 5 to Synth Sect. (245 kg/cm²) -->
        <path d="M 985 380 L 985 170 L 825 170 L 825 134" fill="none" stroke="#8b5cf6" stroke-width="4" marker-end="url(#pfdArrowPurple)" class="${isAnim}"/>
        <path d="M 770 106 L 725 106 L 725 132" fill="none" stroke="#8b5cf6" stroke-width="4" marker-end="url(#pfdArrowPurple)" class="${isAnim}"/>
        <path d="M 692 80 L 692 50 L 1240 50 L 1240 90 L 1340 90" fill="none" stroke="#8b5cf6" stroke-width="4.5" marker-end="url(#pfdArrowPurple)" class="${isAnim}"/>

        <!-- Stream 6: Balancing Line from Syn Gas suction -->
        <path d="M 355 490 L 300 490 L 300 340 L 1150 340 L 1150 490 L 1220 490" fill="none" stroke="#0284c7" stroke-width="2.5" stroke-dasharray="4,3" marker-end="url(#pfdArrowBlue)" class="${isAnim}"/>

        <!-- Steam Turbine Steam Lines (HP Steam In & Exhaust Out) for K-301T -->
        <path d="M 645 280 L 645 408" fill="none" stroke="#ef4444" stroke-width="3.5" marker-end="url(#pfdArrowRed)"/>
        <path d="M 645 510 L 645 610" fill="none" stroke="#475569" stroke-width="3" marker-end="url(#pfdArrowSlate)"/>

        <!-- Drains for K-301 Separators (V-301, V-302, V-303, V-304, V-310) -->
        <path d="M 355 670 L 355 720 L 290 720" fill="none" stroke="#10b981" stroke-width="2.5" marker-end="url(#pfdArrowGreen)"/>
        <path d="M 472 290 L 472 330 L 410 330" fill="none" stroke="#10b981" stroke-width="2.5" marker-end="url(#pfdArrowGreen)"/>
        <path d="M 612 750 L 612 790 L 550 790" fill="none" stroke="#10b981" stroke-width="2.5" marker-end="url(#pfdArrowGreen)"/>
        <path d="M 952 750 L 952 790 L 890 790" fill="none" stroke="#10b981" stroke-width="2.5" marker-end="url(#pfdArrowGreen)"/>
        <path d="M 692 175 L 692 210 L 640 210" fill="none" stroke="#10b981" stroke-width="2.5" marker-end="url(#pfdArrowGreen)"/>

        <!-- Anti-Surge Recycle Lines (FV-301, FV-302, FV-303) -->
        <path d="M 505 270 L 400 270 L 400 480" fill="none" stroke="#f59e0b" stroke-width="2" stroke-dasharray="3,3"/>
        <path d="M 800 580 L 800 620 L 520 620 L 520 160" fill="none" stroke="#f59e0b" stroke-width="2" stroke-dasharray="3,3"/>
      </g>

      <!-- ========================================== -->
      <!-- DCS CONTROLLER LOOPS & INSTRUMENTATION -->
      <!-- ========================================== -->
      <g id="pfd-k301-dcs-controls">
        <!-- PIC-301 (Syn Gas Suction Pressure 25.5 kg/cm²A) -->
        <g class="pfd-ctrl-badge" data-ctrl="PIC-301" transform="translate(355, 450)" cursor="pointer">
          <circle cx="0" cy="0" r="16" fill="#ffffff" stroke="#0284c7" stroke-width="2"/>
          <line x1="-16" y1="0" x2="16" y2="0" stroke="#0284c7" stroke-width="1.2"/>
          <text x="0" y="-4" fill="#0f172a" font-size="8.5" font-weight="bold" text-anchor="middle">PIC</text>
          <text x="0" y="10" fill="#0f172a" font-size="8.5" font-weight="bold" text-anchor="middle">301</text>
        </g>
        <line x1="355" y1="466" x2="355" y2="490" stroke="#0284c7" stroke-width="1.2" stroke-dasharray="3,2"/>

        <!-- SIC-301 (Steam Turbine K-301T Speed Controller) -->
        <g class="pfd-ctrl-badge" data-ctrl="SIC-301" transform="translate(645, 360)" cursor="pointer">
          <circle cx="0" cy="0" r="16" fill="#ffffff" stroke="#ef4444" stroke-width="2"/>
          <line x1="-16" y1="0" x2="16" y2="0" stroke="#ef4444" stroke-width="1.2"/>
          <text x="0" y="-4" fill="#0f172a" font-size="8.5" font-weight="bold" text-anchor="middle">SIC</text>
          <text x="0" y="10" fill="#0f172a" font-size="8.5" font-weight="bold" text-anchor="middle">301</text>
        </g>
        <line x1="645" y1="376" x2="645" y2="410" stroke="#ef4444" stroke-width="1.2" stroke-dasharray="3,2"/>
      </g>

      <!-- ========================================== -->
      <!-- EQUIPMENT GRAPHICS LAYER -->
      <!-- ========================================== -->
      <g id="pfd-k301-equipment">

        <!-- K-301 Base Skirt Foundation -->
        <rect x="400" y="525" width="650" height="20" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="2" rx="4"/>
        <text x="725" y="565" fill="#0284c7" font-size="14" font-weight="900" font-family="'Cairo', sans-serif" text-anchor="middle">قطار ضاغط غاز التخليق K-301 والتوربين الدافع K-301T (٣ أكياس: LP و MP و HP عبر ٤ مراحل كبس + عجلة التدوير)</text>
        <text x="725" y="585" fill="#475569" font-size="11" font-weight="700" text-anchor="middle">3 CASINGS (LP, MP, HP) • 4 COMPRESSION STAGES • 18.5 MW STEAM TURBINE DRIVER • CIRCULATOR WHEEL</text>

        <!-- K-301 Casing 1 (Stage 1 / LP) -->
        <g class="pfd-eq-item" data-tag="K-301-C1" transform="translate(440, 380)">
          <rect x="0" y="0" width="90" height="135" rx="10" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <circle cx="45" cy="67" r="32" fill="url(#pfdSteelHorizGrad)" stroke="#0284c7" stroke-width="2"/>
          <line x1="45" y1="35" x2="45" y2="99" stroke="#0f172a" stroke-width="2"/>
          <line x1="13" y1="67" x2="77" y2="67" stroke="#0f172a" stroke-width="2"/>
          <!-- Drive Shaft Coupling to Turbine -->
          <rect x="88" y="60" width="55" height="15" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.2"/>
          <!-- Clarity Plaque -->
          <g transform="translate(-10, -55)">
            <rect x="0" y="0" width="110" height="46" rx="6" fill="#ffffff" stroke="#0284c7" stroke-width="2"/>
            <text x="55" y="16" fill="#0284c7" font-size="13" font-weight="900" text-anchor="middle">K-301 LP</text>
            <text x="55" y="30" fill="#0f172a" font-size="9.5" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">Case 1 (المرحلة 1)</text>
            <text x="55" y="41" fill="#0284c7" font-size="8.5" font-weight="bold" text-anchor="middle">25.5 IN → 74.5 kg/cm²</text>
          </g>
        </g>

        <!-- K-301 Turbine Driver (K-301T) -->
        <g class="pfd-eq-item" data-tag="K-301-TURB" transform="translate(600, 410)">
          <polygon points="0,0 90,15 90,85 0,100" fill="url(#pfdTurbineGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <!-- Rotor Lines -->
          <line x1="25" y1="8" x2="25" y2="92" stroke="#ffffff" stroke-width="1.5" opacity="0.6"/>
          <line x1="45" y1="12" x2="45" y2="88" stroke="#ffffff" stroke-width="1.5" opacity="0.6"/>
          <line x1="65" y1="14" x2="65" y2="86" stroke="#ffffff" stroke-width="1.5" opacity="0.6"/>
          <!-- Drive Shaft Coupling to MP Casing -->
          <rect x="88" y="42" width="45" height="15" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.2"/>
          <!-- Clarity Plaque -->
          <g transform="translate(-10, -65)">
            <rect x="0" y="0" width="110" height="46" rx="6" fill="#ffffff" stroke="#ef4444" stroke-width="2"/>
            <text x="55" y="16" fill="#ef4444" font-size="13" font-weight="900" text-anchor="middle">K-301T</text>
            <text x="55" y="30" fill="#0f172a" font-size="9.5" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">Steam Turbine</text>
            <text x="55" y="41" fill="#ef4444" font-size="8.5" font-weight="bold" text-anchor="middle">18.5 MW • 10,000 RPM</text>
          </g>
        </g>

        <!-- K-301 Casing 2 (Stage 2 / MP) -->
        <g class="pfd-eq-item" data-tag="K-301-C2" transform="translate(730, 380)">
          <rect x="0" y="0" width="90" height="135" rx="10" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <circle cx="45" cy="67" r="32" fill="url(#pfdSteelHorizGrad)" stroke="#0284c7" stroke-width="2"/>
          <line x1="45" y1="35" x2="45" y2="99" stroke="#0f172a" stroke-width="2"/>
          <line x1="13" y1="67" x2="77" y2="67" stroke="#0f172a" stroke-width="2"/>
          <!-- Drive Shaft Coupling to HP Casing -->
          <rect x="88" y="60" width="65" height="15" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.2"/>
          <!-- Clarity Plaque -->
          <g transform="translate(-10, -55)">
            <rect x="0" y="0" width="110" height="46" rx="6" fill="#ffffff" stroke="#0284c7" stroke-width="2"/>
            <text x="55" y="16" fill="#0284c7" font-size="13" font-weight="900" text-anchor="middle">K-301 MP</text>
            <text x="55" y="30" fill="#0f172a" font-size="9.5" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">Case 2 (المرحلة 2)</text>
            <text x="55" y="41" fill="#0284c7" font-size="8.5" font-weight="bold" text-anchor="middle">73.7 → 134.4 kg/cm²</text>
          </g>
        </g>

        <!-- K-301 Casing 3 (Stages 3 & 4 + Circulator / HP) -->
        <g class="pfd-eq-item" data-tag="K-301-C3" transform="translate(880, 380)">
          <rect x="0" y="0" width="130" height="135" rx="10" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <!-- Stage 3/4 Impeller -->
          <circle cx="45" cy="67" r="28" fill="url(#pfdSteelHorizGrad)" stroke="#0284c7" stroke-width="2"/>
          <!-- Circulator Impeller -->
          <circle cx="95" cy="67" r="26" fill="url(#pfdSteelHorizGrad)" stroke="#7c3aed" stroke-width="2"/>
          <line x1="45" y1="39" x2="45" y2="95" stroke="#0f172a" stroke-width="2"/>
          <line x1="95" y1="41" x2="95" y2="93" stroke="#0f172a" stroke-width="2"/>
          <!-- Clarity Plaque -->
          <g transform="translate(-10, -55)">
            <rect x="0" y="0" width="150" height="46" rx="6" fill="#ffffff" stroke="#7c3aed" stroke-width="2"/>
            <text x="75" y="16" fill="#7c3aed" font-size="13" font-weight="900" text-anchor="middle">K-301 HP & CIRC.</text>
            <text x="75" y="30" fill="#0f172a" font-size="9.5" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">Case 3 (مرحلة 3+4 وتدوير)</text>
            <text x="75" y="41" fill="#7c3aed" font-size="8.5" font-weight="bold" text-anchor="middle">240.5 kg/cm² (Disch) | 245 kg/cm²</text>
          </g>
        </g>

        <!-- Knockout Drum V-301 -->
        <g class="pfd-eq-item" data-tag="V-301" transform="translate(320, 560)">
          <rect x="0" y="15" width="70" height="85" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <ellipse cx="35" cy="15" rx="35" ry="14" fill="url(#pfdSteelHorizGrad)" stroke="#0f172a" stroke-width="2"/>
          <ellipse cx="35" cy="100" rx="35" ry="14" fill="url(#pfdSteelHorizGrad)" stroke="#0f172a" stroke-width="2"/>
          <!-- Demister Pad -->
          <line x1="5" y1="38" x2="65" y2="38" stroke="#38bdf8" stroke-width="4" stroke-dasharray="3,2"/>
          <g transform="translate(-15, -40)">
            <rect x="0" y="0" width="100" height="34" rx="4" fill="#ffffff" stroke="#0284c7" stroke-width="1.8"/>
            <text x="50" y="14" fill="#0284c7" font-size="11" font-weight="900" text-anchor="middle">V-301</text>
            <text x="50" y="27" fill="#0f172a" font-size="8" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">فاصل سحب مرحلة 1</text>
          </g>
        </g>

        <!-- Knockout Drum V-302 -->
        <g class="pfd-eq-item" data-tag="V-302" transform="translate(440, 190)">
          <rect x="0" y="15" width="65" height="75" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <ellipse cx="32.5" cy="15" rx="32.5" ry="12" fill="url(#pfdSteelHorizGrad)" stroke="#0f172a" stroke-width="2"/>
          <ellipse cx="32.5" cy="90" rx="32.5" ry="12" fill="url(#pfdSteelHorizGrad)" stroke="#0f172a" stroke-width="2"/>
          <line x1="5" y1="36" x2="60" y2="36" stroke="#38bdf8" stroke-width="4" stroke-dasharray="3,2"/>
          <g transform="translate(-15, -38)">
            <rect x="0" y="0" width="95" height="34" rx="4" fill="#ffffff" stroke="#0284c7" stroke-width="1.8"/>
            <text x="47.5" y="14" fill="#0284c7" font-size="11" font-weight="900" text-anchor="middle">V-302</text>
            <text x="47.5" y="27" fill="#0f172a" font-size="8" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">فاصل سحب مرحلة 2</text>
          </g>
        </g>

        <!-- Knockout Drum V-303 -->
        <g class="pfd-eq-item" data-tag="V-303" transform="translate(580, 650)">
          <rect x="0" y="15" width="65" height="75" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <ellipse cx="32.5" cy="15" rx="32.5" ry="12" fill="url(#pfdSteelHorizGrad)" stroke="#0f172a" stroke-width="2"/>
          <ellipse cx="32.5" cy="90" rx="32.5" ry="12" fill="url(#pfdSteelHorizGrad)" stroke="#0f172a" stroke-width="2"/>
          <line x1="5" y1="36" x2="60" y2="36" stroke="#38bdf8" stroke-width="4" stroke-dasharray="3,2"/>
          <g transform="translate(-15, -38)">
            <rect x="0" y="0" width="95" height="34" rx="4" fill="#ffffff" stroke="#0284c7" stroke-width="1.8"/>
            <text x="47.5" y="14" fill="#0284c7" font-size="11" font-weight="900" text-anchor="middle">V-303</text>
            <text x="47.5" y="27" fill="#0f172a" font-size="8" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">فاصل سحب مرحلة 3</text>
          </g>
        </g>

        <!-- Knockout Drum V-304 -->
        <g class="pfd-eq-item" data-tag="V-304" transform="translate(920, 650)">
          <rect x="0" y="15" width="65" height="75" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <ellipse cx="32.5" cy="15" rx="32.5" ry="12" fill="url(#pfdSteelHorizGrad)" stroke="#0f172a" stroke-width="2"/>
          <ellipse cx="32.5" cy="90" rx="32.5" ry="12" fill="url(#pfdSteelHorizGrad)" stroke="#0f172a" stroke-width="2"/>
          <line x1="5" y1="36" x2="60" y2="36" stroke="#38bdf8" stroke-width="4" stroke-dasharray="3,2"/>
          <g transform="translate(-15, -38)">
            <rect x="0" y="0" width="95" height="34" rx="4" fill="#ffffff" stroke="#0284c7" stroke-width="1.8"/>
            <text x="47.5" y="14" fill="#0284c7" font-size="11" font-weight="900" text-anchor="middle">V-304</text>
            <text x="47.5" y="27" fill="#0f172a" font-size="8" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">فاصل سحب مرحلة 4</text>
          </g>
        </g>

        <!-- Recycle Separator V-310 -->
        <g class="pfd-eq-item" data-tag="V-310" transform="translate(660, 80)">
          <rect x="0" y="15" width="65" height="70" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <ellipse cx="32.5" cy="15" rx="32.5" ry="12" fill="url(#pfdSteelHorizGrad)" stroke="#0f172a" stroke-width="2"/>
          <ellipse cx="32.5" cy="85" rx="32.5" ry="12" fill="url(#pfdSteelHorizGrad)" stroke="#0f172a" stroke-width="2"/>
          <g transform="translate(-15, -38)">
            <rect x="0" y="0" width="95" height="34" rx="4" fill="#ffffff" stroke="#7c3aed" stroke-width="1.8"/>
            <text x="47.5" y="14" fill="#7c3aed" font-size="11" font-weight="900" text-anchor="middle">V-310</text>
            <text x="47.5" y="27" fill="#0f172a" font-size="8" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">فاصل غاز التدوير</text>
          </g>
        </g>

        <!-- Intercoolers SVG Injection -->
        ${e301Svg}
        ${e302Svg}
        ${e303Svg}
        ${e304Svg}
        ${e315Svg}

        <!-- Stream Indicators and Data Plaques -->
        <!-- Stream 1 -->
        <g class="pfd-stream-flag" data-stream="1" transform="translate(80, 755)">
          <polygon points="0,9 9,0 18,9 9,18" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="9" y="13" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">1</text>
          <g transform="translate(-50, 22)">
            <rect width="125" height="26" fill="#f8fafc" stroke="#0284c7" stroke-width="1.5" rx="3"/>
            <text x="6" y="12" fill="#0284c7" font-size="8.5" font-weight="bold">غاز التخليق الخام (E-114)</text>
            <text x="6" y="22" fill="#334155" font-size="7.5" font-weight="bold">26.8 kg/cm² | 129.3°C</text>
          </g>
        </g>

        <!-- Stream 2 -->
        <g class="pfd-stream-flag" data-stream="2" transform="translate(420, 475)">
          <polygon points="0,9 9,0 18,9 9,18" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="9" y="13" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">2</text>
          <g transform="translate(-40, -32)">
            <rect width="115" height="26" fill="#f8fafc" stroke="#0284c7" stroke-width="1.5" rx="3"/>
            <text x="6" y="12" fill="#0284c7" font-size="8.5" font-weight="bold">سحب الضاغط LP</text>
            <text x="6" y="22" fill="#334155" font-size="7.5" font-weight="bold">25.5 IN | 43.0°C | 48.0 t/h</text>
          </g>
        </g>

        <!-- Stream 3 -->
        <g class="pfd-stream-flag" data-stream="3" transform="translate(1310, 755)">
          <polygon points="0,9 9,0 18,9 9,18" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="9" y="13" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">3</text>
          <g transform="translate(-40, -32)">
            <rect width="130" height="26" fill="#f8fafc" stroke="#0284c7" stroke-width="1.5" rx="3"/>
            <text x="6" y="12" fill="#0284c7" font-size="8.5" font-weight="bold">طرد عالي الضغط إلى R-401</text>
            <text x="6" y="22" fill="#334155" font-size="7.5" font-weight="bold">240.5 kg/cm² | 43.0°C</text>
          </g>
        </g>

        <!-- Stream 4 -->
        <g class="pfd-stream-flag" data-stream="4" transform="translate(80, 75)">
          <polygon points="0,9 9,0 18,9 9,18" fill="#7c3aed" stroke="#0f172a" stroke-width="1.5"/>
          <text x="9" y="13" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">4</text>
          <g transform="translate(-45, 22)">
            <rect width="135" height="26" fill="#f8fafc" stroke="#7c3aed" stroke-width="1.5" rx="3"/>
            <text x="6" y="12" fill="#7c3aed" font-size="8.5" font-weight="bold">غاز التدوير الراجع (Loop)</text>
            <text x="6" y="22" fill="#334155" font-size="7.5" font-weight="bold">220.0 kg/cm² | 205.1 t/h</text>
          </g>
        </g>

        <!-- Stream 5 -->
        <g class="pfd-stream-flag" data-stream="5" transform="translate(1310, 75)">
          <polygon points="0,9 9,0 18,9 9,18" fill="#7c3aed" stroke="#0f172a" stroke-width="1.5"/>
          <text x="9" y="13" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">5</text>
          <g transform="translate(-40, -32)">
            <rect width="135" height="26" fill="#f8fafc" stroke="#7c3aed" stroke-width="1.5" rx="3"/>
            <text x="6" y="12" fill="#7c3aed" font-size="8.5" font-weight="bold">غاز التدوير المضغوط (Loop)</text>
            <text x="6" y="22" fill="#334155" font-size="7.5" font-weight="bold">245.0 kg/cm² | 43.0°C</text>
          </g>
        </g>

        <!-- Stream 6 -->
        <g class="pfd-stream-flag" data-stream="6" transform="translate(1190, 475)">
          <polygon points="0,9 9,0 18,9 9,18" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="9" y="13" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">6</text>
          <g transform="translate(-40, 22)">
            <rect width="115" height="26" fill="#f8fafc" stroke="#0284c7" stroke-width="1.5" rx="3"/>
            <text x="6" y="12" fill="#0284c7" font-size="8.5" font-weight="bold">خط موازنة سحب الضاغط</text>
            <text x="6" y="22" fill="#334155" font-size="7.5" font-weight="bold">26.0 kg/cm² | 568 kg/h</text>
          </g>
        </g>
      </g>
    </g>
  `;
}

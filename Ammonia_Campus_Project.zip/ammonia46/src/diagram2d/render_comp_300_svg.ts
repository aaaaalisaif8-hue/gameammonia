/**
 * render_comp_300_svg.ts
 * Vector Blueprint Renderer for DWG NO. 6112P 100-300-00
 * Ammonia Unit - Compression Section (EXCLUSIVELY K-302 & K-303)
 * Synthesis Gas Compressor K-301 is strictly isolated in DWG NO. 6112P 100-301-00
 */

import { renderShellAndTubeSVG } from './render_shell_and_tube';

export function renderCompression300SVG(showParticles: boolean): string {
  const isAnim = showParticles ? 'pfd-pipe-anim' : '';

  // Intercoolers for Process Air Compressor K-302
  const e305Svg = renderShellAndTubeSVG({
    tag: 'E-305',
    nameAr: 'مبرد هواء 1',
    temaType: 'AEL / Air Intercooler 1',
    tagColor: '#0284c7',
    x: 420,
    y: 280,
    width: 90,
    height: 48,
    tubeSide: {
      fluidAr: 'هواء مضغوط مرحلة 1',
      tempIn: '194°C',
      tempOut: '43°C',
      color: '#00c8ef',
      inPos: 'axial-left',
      outPos: 'axial-right'
    },
    shellSide: {
      fluidAr: 'مياه التبريد CW',
      tempIn: '32°C',
      tempOut: '40°C',
      color: '#0284c7',
      inPos: 'bottom',
      outPos: 'top'
    }
  });

  const e306Svg = renderShellAndTubeSVG({
    tag: 'E-306',
    nameAr: 'مبرد هواء 2',
    temaType: 'AEL / Air Intercooler 2',
    tagColor: '#0284c7',
    x: 560,
    y: 280,
    width: 90,
    height: 48,
    tubeSide: {
      fluidAr: 'هواء مضغوط مرحلة 2',
      tempIn: '185°C',
      tempOut: '43°C',
      color: '#00c8ef',
      inPos: 'axial-left',
      outPos: 'axial-right'
    },
    shellSide: {
      fluidAr: 'مياه التبريد CW',
      tempIn: '32°C',
      tempOut: '40°C',
      color: '#0284c7',
      inPos: 'bottom',
      outPos: 'top'
    }
  });

  const e307Svg = renderShellAndTubeSVG({
    tag: 'E-307',
    nameAr: 'مبرد هواء 3',
    temaType: 'AEL / Air Intercooler 3',
    tagColor: '#0284c7',
    x: 700,
    y: 280,
    width: 90,
    height: 48,
    tubeSide: {
      fluidAr: 'هواء مضغوط مرحلة 3',
      tempIn: '164°C',
      tempOut: '43°C',
      color: '#00c8ef',
      inPos: 'axial-left',
      outPos: 'axial-right'
    },
    shellSide: {
      fluidAr: 'مياه التبريد CW',
      tempIn: '32°C',
      tempOut: '40°C',
      color: '#0284c7',
      inPos: 'bottom',
      outPos: 'top'
    }
  });

  // By-pass Cooler for Natural Gas Compressor K-303
  const e308Svg = renderShellAndTubeSVG({
    tag: 'E-308',
    nameAr: 'مبرد تدوير الغاز الطبيعي',
    temaType: 'AES / Gas By-pass Cooler',
    tagColor: '#d97706',
    x: 1390,
    y: 280,
    width: 95,
    height: 48,
    tubeSide: {
      fluidAr: 'غاز طبيعي By-pass',
      tempIn: '117°C',
      tempOut: '43°C',
      color: '#f97316',
      inPos: 'axial-left',
      outPos: 'axial-right'
    },
    shellSide: {
      fluidAr: 'مياه التبريد CW',
      tempIn: '32°C',
      tempOut: '40°C',
      color: '#0284c7',
      inPos: 'bottom',
      outPos: 'top'
    }
  });

  return `
    <!-- BLUEPRINT DRAWING 6112P-100-300-00 (K-302 & K-303 EXCLUSIVELY) -->
    <g id="pfd-comp-300-layers">
      
      <!-- ========================================== -->
      <!-- COMPACT PROCESS SYMBOLS LEGEND (Bottom Right) -->
      <!-- ========================================== -->
      <g transform="translate(1620, 940)">
        <rect width="260" height="120" fill="rgba(248,250,252,0.92)" stroke="#334155" stroke-width="1.2" rx="6"/>
        <text x="12" y="20" fill="#0f172a" font-size="11" font-weight="800" font-family="'Cairo', sans-serif">دليل الرموز والمؤشرات (Legend)</text>
        <line x1="8" y1="28" x2="252" y2="28" stroke="#cbd5e1" stroke-width="1"/>
        <g transform="translate(14, 40)">
          <polygon points="0,7 7,0 14,7 7,14" fill="#0284c7" stroke="#0f172a" stroke-width="1"/>
          <text x="22" y="11" fill="#0f172a" font-size="10" font-weight="700">Stream No. (رقم المسار)</text>
          <circle cx="7" cy="28" r="7" fill="#e0f2fe" stroke="#0284c7" stroke-width="1"/>
          <text x="22" y="32" fill="#0f172a" font-size="10" font-weight="700">Press. kg/cm²A (الضغط)</text>
          <rect x="0" y="44" width="16" height="12" rx="3" fill="#fef3c7" stroke="#d97706" stroke-width="1"/>
          <text x="22" y="54" fill="#0f172a" font-size="10" font-weight="700">Temp. °C (درجة الحرارة)</text>
        </g>
      </g>

      <!-- ========================================== -->
      <!-- PIPING LINES LAYER -->
      <!-- ========================================== -->
      <g id="pfd-comp-piping">
        
        <!-- ========================================================= -->
        <!-- 1. PROCESS AIR COMPRESSOR K-302 PIPING -->
        <!-- ========================================================= -->

        <!-- Atmospheric Intake: H-301 -> F-301 -> V-308 -> K-302 Case 1 Stage 1 -->
        <path d="M 60 435 L 130 435" fill="none" stroke="#00c8ef" stroke-width="3.5" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>
        <path d="M 195 435 L 225 435" fill="none" stroke="#00c8ef" stroke-width="3.5" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>
        <path d="M 270 435 L 370 435 L 370 465" fill="none" stroke="#00c8ef" stroke-width="3.5" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>

        <!-- K-302 Case 1 (Stage 1 Disch) -> E-305 -> V-305 -> Stage 2 Suction -->
        <path d="M 400 470 L 400 370 L 440 370 L 440 332" fill="none" stroke="#00c8ef" stroke-width="3" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>
        <path d="M 490 280 L 490 240 L 450 240 L 450 258" fill="none" stroke="#00c8ef" stroke-width="3" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>
        <path d="M 450 180 L 450 150 L 445 150 L 445 465" fill="none" stroke="#00c8ef" stroke-width="3" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>

        <!-- K-302 Case 1 (Stage 2 Disch) -> E-306 -> V-306 -> K-302 Case 2 (Stage 3 Suction) -->
        <path d="M 470 565 L 470 610 L 580 610 L 580 332" fill="none" stroke="#00c8ef" stroke-width="3" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>
        <path d="M 630 280 L 630 240 L 560 240 L 560 258" fill="none" stroke="#00c8ef" stroke-width="3" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>
        <path d="M 560 180 L 560 150 L 575 150 L 575 465" fill="none" stroke="#00c8ef" stroke-width="3" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>

        <!-- K-302 Case 2 (Stage 3 Disch) -> E-307 -> V-307 -> Stage 4 Suction -->
        <path d="M 600 470 L 600 370 L 720 370 L 720 332" fill="none" stroke="#00c8ef" stroke-width="3" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>
        <path d="M 770 280 L 770 240 L 670 240 L 670 258" fill="none" stroke="#00c8ef" stroke-width="3" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>
        <path d="M 670 180 L 670 150 L 650 150 L 650 465" fill="none" stroke="#00c8ef" stroke-width="3" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>

        <!-- Pre-Stage 4 Extractions (Urea, Catacarb, Inst Air) -->
        <path d="M 650 200 L 780 200 L 780 220" fill="none" stroke="#00c8ef" stroke-width="2.5" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>
        <path d="M 780 220 L 780 260 L 830 260" fill="none" stroke="#00c8ef" stroke-width="2" marker-end="url(#pfdArrowCyan)"/>
        <path d="M 780 220 L 780 295 L 830 295" fill="none" stroke="#00c8ef" stroke-width="2" marker-end="url(#pfdArrowCyan)"/>
        <path d="M 780 220 L 780 330 L 830 330" fill="none" stroke="#00c8ef" stroke-width="2" marker-end="url(#pfdArrowCyan)"/>

        <!-- K-302 Case 2 (Stage 4 Final Disch) -> Stream 7 (Process Air to Gas Reform) -->
        <path d="M 660 565 L 660 670 L 880 670" fill="none" stroke="#00c8ef" stroke-width="4.5" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>
        <path d="M 880 670 L 880 750 L 980 750" fill="none" stroke="#00c8ef" stroke-width="4.5" marker-end="url(#pfdArrowCyan)" class="${isAnim}"/>

        <!-- Anti-Surge Atmospheric Blow-Off Line -->
        <path d="M 880 670 L 880 610 L 930 610" fill="none" stroke="#dc2626" stroke-width="2.5" stroke-dasharray="4,2" marker-end="url(#pfdArrowRed)"/>

        <!-- Drains for K-302 Separators to Sewer -->
        <path d="M 450 260 L 420 260 L 420 330 L 370 330" fill="none" stroke="#10b981" stroke-width="2" marker-end="url(#pfdArrowGreen)"/>
        <path d="M 560 260 L 530 260 L 530 330 L 490 330" fill="none" stroke="#10b981" stroke-width="2" marker-end="url(#pfdArrowGreen)"/>
        <path d="M 670 260 L 640 260 L 640 330 L 600 330" fill="none" stroke="#10b981" stroke-width="2" marker-end="url(#pfdArrowGreen)"/>

        <!-- Steam Turbine K-302T Supply (S-39) & Exhaust (S-3) -->
        <path d="M 270 460 L 270 515" fill="none" stroke="#ef4444" stroke-width="2.5" marker-end="url(#pfdArrowRed)"/>
        <path d="M 270 590 L 270 645" fill="none" stroke="#475569" stroke-width="2.5" marker-end="url(#pfdArrowSlate)"/>

        <!-- ========================================================= -->
        <!-- 2. NATURAL GAS COMPRESSOR K-303 PIPING -->
        <!-- ========================================================= -->

        <!-- Stream 8 from Battery Limit (V-115 B.L) -> V-111 Suction Separator -->
        <path d="M 1060 140 L 1175 140 L 1175 215" fill="none" stroke="#f97316" stroke-width="3.5" marker-end="url(#pfdArrowOrange)" class="${isAnim}"/>

        <!-- V-111 overhead -> K-303 Compressor Suction -->
        <path d="M 1175 315 L 1175 480 L 1260 480 L 1260 495" fill="none" stroke="#f97316" stroke-width="3.5" marker-end="url(#pfdArrowOrange)" class="${isAnim}"/>

        <!-- V-111 Drain to Liquid Hydrocarbon recovery -->
        <path d="M 1175 315 L 1130 315 L 1130 350 L 1090 350" fill="none" stroke="#10b981" stroke-width="2" marker-end="url(#pfdArrowGreen)"/>

        <!-- K-303 Discharge -> Stream 9 To Gas Reform Section -->
        <path d="M 1320 500 L 1320 440 L 1490 440 L 1490 750 L 1580 750" fill="none" stroke="#f97316" stroke-width="4.5" marker-end="url(#pfdArrowOrange)" class="${isAnim}"/>

        <!-- Anti-Surge & Recycle By-Pass Loop -> E-308 -> V-111 -->
        <path d="M 1320 440 L 1390 440 L 1390 332" fill="none" stroke="#f97316" stroke-width="2.8" marker-end="url(#pfdArrowOrange)" class="${isAnim}"/>
        <path d="M 1460 280 L 1460 200 L 1178 200" fill="none" stroke="#f97316" stroke-width="2.8" marker-end="url(#pfdArrowOrange)" class="${isAnim}"/>

        <!-- Steam Turbine K-303T Steam Lines (S-39 Steam & S-3 Exhaust) -->
        <path d="M 1080 470 L 1080 530" fill="none" stroke="#ef4444" stroke-width="2.5" marker-end="url(#pfdArrowRed)"/>
        <path d="M 1080 605 L 1080 660" fill="none" stroke="#475569" stroke-width="2.5" marker-end="url(#pfdArrowSlate)"/>
      </g>

      <!-- ========================================== -->
      <!-- DCS CONTROLLER LOOPS & INSTRUMENTATION -->
      <!-- ========================================== -->
      <g id="pfd-comp-dcs-controls">
        <!-- PIC-302 (Process Air Compressor Discharge 34 kg/cm²G) -->
        <g class="pfd-ctrl-badge" data-ctrl="PIC-302" transform="translate(880, 610)" cursor="pointer">
          <circle cx="0" cy="0" r="16" fill="#ffffff" stroke="#00c8ef" stroke-width="2"/>
          <line x1="-16" y1="0" x2="16" y2="0" stroke="#00c8ef" stroke-width="1.2"/>
          <text x="0" y="-4" fill="#0f172a" font-size="8" font-weight="bold" text-anchor="middle">PIC</text>
          <text x="0" y="10" fill="#0f172a" font-size="8" font-weight="bold" text-anchor="middle">302</text>
        </g>
        <line x1="880" y1="626" x2="880" y2="670" stroke="#00c8ef" stroke-width="1.2" stroke-dasharray="3,2"/>

        <!-- PIC-303 (Natural Gas Compressor Discharge 40 kg/cm²G) -->
        <g class="pfd-ctrl-badge" data-ctrl="PIC-303" transform="translate(1490, 390)" cursor="pointer">
          <circle cx="0" cy="0" r="16" fill="#ffffff" stroke="#f97316" stroke-width="2"/>
          <line x1="-16" y1="0" x2="16" y2="0" stroke="#f97316" stroke-width="1.2"/>
          <text x="0" y="-4" fill="#0f172a" font-size="8" font-weight="bold" text-anchor="middle">PIC</text>
          <text x="0" y="10" fill="#0f172a" font-size="8" font-weight="bold" text-anchor="middle">303</text>
        </g>
        <line x1="1490" y1="406" x2="1490" y2="440" stroke="#f97316" stroke-width="1.2" stroke-dasharray="3,2"/>
      </g>

      <!-- ========================================== -->
      <!-- EQUIPMENT GRAPHICS LAYER -->
      <!-- ========================================== -->
      <g id="pfd-comp-equipment">

        <!-- ========================================================= -->
        <!-- 1. K-302: PROCESS AIR COMPRESSOR TRAIN -->
        <!-- ========================================================= -->
        <!-- Concrete Foundation Skirt -->
        <rect x="210" y="580" width="560" height="18" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.8" rx="4"/>
        <text x="490" y="614" fill="#0284c7" font-size="13" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">K-302: قطار ضاغط هواء العمليات (جسمان • 4 مراحل • توربين بخاري K-302T)</text>
        <text x="490" y="630" fill="#475569" font-size="9.5" font-weight="700" text-anchor="middle">PROCESS AIR COMPRESSOR TRAIN • 50,590 kg/h • 34 kg/cm²G TO R-102</text>

        <!-- Air Intake Stack H-301 -->
        <g class="pfd-eq-item" data-tag="H-301" transform="translate(45, 380)">
          <polygon points="12,0 42,0 54,24 0,24" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
          <rect x="12" y="24" width="30" height="75" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
          <g transform="translate(-25, -44)">
            <rect x="0" y="0" width="105" height="38" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="1.6"/>
            <text x="52" y="15" fill="#0284c7" font-size="12.5" font-weight="bold" text-anchor="middle">H-301</text>
            <text x="52" y="28" fill="#0f172a" font-size="9" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">مدخنة سحب الهواء</text>
          </g>
        </g>

        <!-- Air Filter F-301 -->
        <g class="pfd-eq-item" data-tag="F-301" transform="translate(135, 395)">
          <rect x="0" y="0" width="60" height="70" rx="5" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
          <path d="M 6 0 L 54 70 M 54 0 L 6 70" fill="none" stroke="#0284c7" stroke-dasharray="3,3"/>
          <g transform="translate(-20, -44)">
            <rect x="0" y="0" width="100" height="38" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="1.6"/>
            <text x="50" y="15" fill="#0284c7" font-size="12.5" font-weight="bold" text-anchor="middle">F-301</text>
            <text x="50" y="28" fill="#0f172a" font-size="9" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">فلتر هواء العمليات</text>
          </g>
        </g>

        <!-- Suction Air Separator V-308 -->
        <g class="pfd-eq-item" data-tag="V-308" transform="translate(225, 395)">
          <path d="M 0 15 C 0 0, 45 0, 45 15 L 45 50 C 45 65, 0 65, 0 50 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
          <g transform="translate(-25, -44)">
            <rect x="0" y="0" width="95" height="38" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="1.6"/>
            <text x="47" y="15" fill="#0284c7" font-size="12.5" font-weight="bold" text-anchor="middle">V-308</text>
            <text x="47" y="28" fill="#0f172a" font-size="9" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">فاصل سحب الهواء</text>
          </g>
        </g>

        <!-- K-302 Steam Turbine Driver K-302T -->
        <g class="pfd-eq-item" data-tag="K-302-TURB" transform="translate(230, 505)">
          <polygon points="5,5 65,15 65,80 5,90" fill="url(#pfdTurbineGrad)" stroke="#0f172a" stroke-width="2"/>
          <rect x="64" y="42" width="30" height="12" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1"/>
          <g transform="translate(-15, -46)">
            <rect x="0" y="0" width="105" height="38" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="52" y="15" fill="#dc2626" font-size="12" font-weight="900" text-anchor="middle">K-302T</text>
            <text x="52" y="27" fill="#0f172a" font-size="8.5" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">التوربين البخاري الدافع</text>
          </g>
        </g>

        <!-- K-302 Case 1 (Stages 1 & 2) -->
        <g class="pfd-eq-item" data-tag="K-302-C1" transform="translate(345, 475)">
          <rect x="0" y="0" width="135" height="105" rx="8" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <circle cx="42" cy="52" r="28" fill="url(#pfdSteelHorizGrad)" stroke="#0284c7" stroke-width="1.8"/>
          <circle cx="95" cy="52" r="28" fill="url(#pfdSteelHorizGrad)" stroke="#0284c7" stroke-width="1.8"/>
          <rect x="134" y="47" width="35" height="12" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1"/>
          <g transform="translate(10, -45)">
            <rect x="0" y="0" width="115" height="38" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="57" y="15" fill="#0284c7" font-size="12" font-weight="900" text-anchor="middle">K-302 CASE 1</text>
            <text x="57" y="28" fill="#0f172a" font-size="9" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">المرحلة 1 و 2</text>
          </g>
        </g>

        <!-- K-302 Case 2 (Stages 3 & 4) -->
        <g class="pfd-eq-item" data-tag="K-302-C2" transform="translate(535, 475)">
          <rect x="0" y="0" width="135" height="105" rx="8" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <circle cx="42" cy="52" r="26" fill="url(#pfdSteelHorizGrad)" stroke="#0284c7" stroke-width="1.8"/>
          <circle cx="95" cy="52" r="26" fill="url(#pfdSteelHorizGrad)" stroke="#0284c7" stroke-width="1.8"/>
          <g transform="translate(10, -45)">
            <rect x="0" y="0" width="115" height="38" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="57" y="15" fill="#0284c7" font-size="12" font-weight="900" text-anchor="middle">K-302 CASE 2</text>
            <text x="57" y="28" fill="#0f172a" font-size="9" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">المرحلة 3 و 4</text>
          </g>
        </g>

        <!-- K-302 Intercoolers & Separators -->
        ${e305Svg}
        <g class="pfd-eq-item" data-tag="V-305" transform="translate(425, 175)">
          <path d="M 0 12 C 0 0, 45 0, 45 12 L 45 48 C 45 60, 0 60, 0 48 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
          <g transform="translate(-25, -42)">
            <rect x="0" y="0" width="95" height="36" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="1.6"/>
            <text x="47" y="15" fill="#0284c7" font-size="12.5" font-weight="bold" text-anchor="middle">V-305</text>
            <text x="47" y="28" fill="#0f172a" font-size="9" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">فاصل هواء 1</text>
          </g>
        </g>

        ${e306Svg}
        <g class="pfd-eq-item" data-tag="V-306" transform="translate(535, 175)">
          <path d="M 0 12 C 0 0, 45 0, 45 12 L 45 48 C 45 60, 0 60, 0 48 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
          <g transform="translate(-25, -42)">
            <rect x="0" y="0" width="95" height="36" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="1.6"/>
            <text x="47" y="15" fill="#0284c7" font-size="12.5" font-weight="bold" text-anchor="middle">V-306</text>
            <text x="47" y="28" fill="#0f172a" font-size="9" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">فاصل هواء 2</text>
          </g>
        </g>

        ${e307Svg}
        <g class="pfd-eq-item" data-tag="V-307" transform="translate(645, 175)">
          <path d="M 0 12 C 0 0, 45 0, 45 12 L 45 48 C 45 60, 0 60, 0 48 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
          <g transform="translate(-25, -42)">
            <rect x="0" y="0" width="95" height="36" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="1.6"/>
            <text x="47" y="15" fill="#0284c7" font-size="12.5" font-weight="bold" text-anchor="middle">V-307</text>
            <text x="47" y="28" fill="#0f172a" font-size="9" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">فاصل هواء 3</text>
          </g>
        </g>

        <!-- K-302 Side Extractions Callout Box -->
        <g transform="translate(830, 240)">
          <rect x="0" y="0" width="200" height="110" rx="6" fill="#f0f9ff" stroke="#0284c7" stroke-width="1.8"/>
          <text x="100" y="18" fill="#0369a1" font-size="9.5" font-weight="bold" text-anchor="middle">سحوبات هواء قبل مرحلة 4:</text>
          <line x1="10" y1="26" x2="190" y2="26" stroke="#bae6fd" stroke-width="1"/>
          <text x="15" y="44" fill="#0f172a" font-size="8.5" font-weight="bold">1) وحدة اليوريا (خمولة التآكل)</text>
          <text x="15" y="62" fill="#0f172a" font-size="8.5" font-weight="bold">2) أكسدة محلول الكاتاكارب (V5+)</text>
          <text x="15" y="80" fill="#0f172a" font-size="8.5" font-weight="bold">3) مجفف هواء الأجهزة (Inst Air)</text>
          <text x="100" y="100" fill="#dc2626" font-size="8" font-weight="bold" text-anchor="middle">تفريغ الارتجاف: صمام للجو (Atmosphere)</text>
        </g>

        <!-- ========================================================= -->
        <!-- 2. K-303: NATURAL GAS COMPRESSOR TRAIN -->
        <!-- ========================================================= -->
        <!-- Concrete Foundation Skirt -->
        <rect x="1030" y="585" width="360" height="18" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.8" rx="4"/>
        <text x="1210" y="618" fill="#d97706" font-size="13" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">K-303: ضاغط الغاز الطبيعي (تغذية المصلح الأولي R-101)</text>
        <text x="1210" y="634" fill="#475569" font-size="9.5" font-weight="700" text-anchor="middle">NATURAL GAS COMPRESSOR TRAIN • 19.0 → 40.0 kg/cm²G • STEAM TURBINE K-303T</text>

        <!-- V-111: Natural Gas Drain Separator -->
        <g class="pfd-eq-item" data-tag="V-111" transform="translate(1145, 215)">
          <path d="M 0 16 C 0 0, 55 0, 55 16 L 55 65 C 55 80, 0 80, 0 65 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
          <line x1="5" y1="48" x2="50" y2="48" stroke="#d97706" stroke-dasharray="2,2"/>
          <g transform="translate(-25, -44)">
            <rect x="0" y="0" width="105" height="38" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="1.6"/>
            <text x="52" y="15" fill="#d97706" font-size="12.5" font-weight="bold" text-anchor="middle">V-111</text>
            <text x="52" y="28" fill="#0f172a" font-size="9" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">فاصل الغاز الطبيعي</text>
          </g>
        </g>

        <!-- K-303 Steam Turbine Driver K-303T -->
        <g class="pfd-eq-item" data-tag="K-303-TURB" transform="translate(1040, 520)">
          <polygon points="5,5 60,14 60,75 5,85" fill="url(#pfdTurbineGrad)" stroke="#0f172a" stroke-width="2"/>
          <rect x="59" y="38" width="30" height="12" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1"/>
          <g transform="translate(-15, -46)">
            <rect x="0" y="0" width="100" height="38" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="50" y="15" fill="#dc2626" font-size="12" font-weight="900" text-anchor="middle">K-303T</text>
            <text x="50" y="27" fill="#0f172a" font-size="8.5" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">توربين ضاغط الغاز</text>
          </g>
        </g>

        <!-- K-303 Compressor Casing -->
        <g class="pfd-eq-item" data-tag="K-303" transform="translate(1160, 485)">
          <rect x="0" y="0" width="125" height="100" rx="8" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <circle cx="62" cy="50" r="32" fill="url(#pfdSteelHorizGrad)" stroke="#d97706" stroke-width="1.8"/>
          <line x1="62" y1="18" x2="62" y2="82" stroke="#0f172a" stroke-width="2"/>
          <line x1="30" y1="50" x2="94" y2="50" stroke="#0f172a" stroke-width="2"/>
          <g transform="translate(12, -45)">
            <rect x="0" y="0" width="100" height="38" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="50" y="15" fill="#d97706" font-size="13" font-weight="900" text-anchor="middle">K-303</text>
            <text x="50" y="28" fill="#0f172a" font-size="9" font-weight="bold" font-family="'Cairo', sans-serif" text-anchor="middle">ضاغط الغاز الطبيعي</text>
          </g>
          <text x="62" y="118" fill="#475569" font-size="9" font-weight="bold" text-anchor="middle">19.0 → 41.0 kg/cm²A</text>
        </g>

        <!-- E-308 By-Pass Cooler -->
        ${e308Svg}
      </g>

      <!-- ========================================== -->
      <!-- STREAM TAG BADGES LAYER (7, 8, 9) -->
      <!-- ========================================== -->
      <g id="pfd-comp-stream-badges">
        <!-- Stream 7: Process Air to Gas Reform (R-102) -->
        <g class="pfd-stream-badge" data-stream="7" transform="translate(980, 750)" cursor="pointer">
          <polygon points="0,0 35,0 45,15 35,30 0,30" fill="#0284c7" stroke="#0f172a" stroke-width="1.8"/>
          <text x="18" y="20" fill="#ffffff" font-size="12" font-weight="bold" text-anchor="middle">7</text>
          <!-- Tooltip Callout -->
          <g transform="translate(55, -20)">
            <rect width="180" height="52" rx="4" fill="#ffffff" stroke="#0284c7" stroke-width="1.5"/>
            <text x="8" y="16" fill="#0284c7" font-size="10" font-weight="bold">Stream 7: Process Air</text>
            <text x="8" y="32" fill="#0f172a" font-size="9">P = 35.0 kg/cm²A • T = 167 °C</text>
            <text x="8" y="46" fill="#16a34a" font-size="9" font-weight="bold">Flow = 50,590 kg/h (to R-102)</text>
          </g>
        </g>

        <!-- Stream 8: Raw Natural Gas from B.L -->
        <g class="pfd-stream-badge" data-stream="8" transform="translate(1010, 140)" cursor="pointer">
          <polygon points="0,0 35,0 45,15 35,30 0,30" fill="#f97316" stroke="#0f172a" stroke-width="1.8"/>
          <text x="18" y="20" fill="#ffffff" font-size="12" font-weight="bold" text-anchor="middle">8</text>
          <!-- Tooltip Callout -->
          <g transform="translate(55, -20)">
            <rect width="180" height="52" rx="4" fill="#ffffff" stroke="#f97316" stroke-width="1.5"/>
            <text x="8" y="16" fill="#f97316" font-size="10" font-weight="bold">Stream 8: Raw Natural Gas</text>
            <text x="8" y="32" fill="#0f172a" font-size="9">P = 19.0 kg/cm²A • T = 40 °C</text>
            <text x="8" y="46" fill="#16a34a" font-size="9" font-weight="bold">Flow = 27,725 kg/h (from B.L)</text>
          </g>
        </g>

        <!-- Stream 9: High Pressure Natural Gas to Reforming -->
        <g class="pfd-stream-badge" data-stream="9" transform="translate(1580, 750)" cursor="pointer">
          <polygon points="0,0 35,0 45,15 35,30 0,30" fill="#f97316" stroke="#0f172a" stroke-width="1.8"/>
          <text x="18" y="20" fill="#ffffff" font-size="12" font-weight="bold" text-anchor="middle">9</text>
          <!-- Tooltip Callout -->
          <g transform="translate(-195, -20)">
            <rect width="185" height="52" rx="4" fill="#ffffff" stroke="#f97316" stroke-width="1.5"/>
            <text x="8" y="16" fill="#f97316" font-size="10" font-weight="bold">Stream 9: Compressed NG</text>
            <text x="8" y="32" fill="#0f172a" font-size="9">P = 41.0 kg/cm²A • T = 117 °C</text>
            <text x="8" y="46" fill="#16a34a" font-size="9" font-weight="bold">To Desulfurization & Reforming</text>
          </g>
        </g>
      </g>
    </g>
  `;
}

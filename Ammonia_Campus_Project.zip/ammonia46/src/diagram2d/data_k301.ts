/**
 * data_k301.ts
 * Dedicated Process Flow Diagram Data for Syngas Compressor K-301 & Circulator Train
 * Blueprint: DWG NO. 6112P 100-301-00 (Isolated Standalone Section)
 * Project: IRAQ NO. 3 PROJECT / M.O.I. IRAQ - FERTILIZER PROJECT, KHOR AL-ZUBAIR PHASE-1
 * AMMONIA UNIT - SYNGAS COMPRESSION (K-301 LP, MP, HP, K-301T, Circulator & Coolers)
 */

import { PFDStreamData, PFDEquipment, PFDSheetInfo } from './types';

export const SHEET_K301_INFO: PFDSheetInfo = {
  id: 'k301_300',
  dwgNo: 'DWG NO. 6112P 100-301-00',
  title: 'AMMONIA UNIT - SYNTHESIS GAS COMPRESSOR K-301 & CIRCULATOR - PROCESS FLOW DIAGRAM',
  titleAr: 'قسم ضاغط غاز التخليق K-301 والتوربين البخاري ومبرداته وعجلة التدوير (مخطط معزول مستقل)',
  orderNo: '563030-012',
  date: '9.19.\'75',
  customer: 'FERTILIZER & AMMONIA COMPLEX - UNIT 300 (K-301)',
  filters: [
    { id: 'all', label: 'All Train', labelAr: 'المخطط الكامل K-301' },
    { id: 'lp_mp', label: 'LP & MP Stages', labelAr: 'مراحل الضغط المنخفض والمتوسط' },
    { id: 'hp_rec', label: 'HP & Recycle', labelAr: 'مراحل الضغط العالي والتدوير' },
    { id: 'coolers', label: 'Intercoolers & Drums', labelAr: 'المبردات والفواصل E-301..E-304' },
    { id: 'turbine', label: 'Turbine K-301T', labelAr: 'التوربين البخاري K-301T' }
  ]
};

export const STREAMS_K301: Record<number, PFDStreamData> = {
  1: {
    id: 1,
    name: "SYNTHESIS GAS FROM GAS REFORM",
    nameAr: "غاز التخليق التعويضي القادم من قسم الإصلاح والميثانايتر (خروج E-114)",
    pressure: "26.8",
    temperature: "129.3",
    flowKgH: "50,680 (Wet) / 48,280 (Dry)",
    dryGasMolH: "5,543.24",
    wetGasMolH: "5,676.35",
    h2oMolH: "132.88",
    dryGasTh: "48.280",
    wetGasTh: "50.680",
    dryMw: "8.709",
    wetMw: "8.927",
    comp: {
      h2: "74.06 % (4,105.52 mol/h)",
      n2: "24.69 % (1,368.47 mol/h)",
      ar: "0.40 % (22.10 mol/h)",
      ch4: "0.85 % (47.15 mol/h)",
      nh3: "0.00 %",
      co: "0.00 %",
      co2: "0.00 %"
    }
  },
  2: {
    id: 2,
    name: "MAKE-UP GAS TO COMPRESSOR (SUCTION CASE 1)",
    nameAr: "غاز التخليق التعويضي بعد التبريد وفصل المكثفات (مدخل مرحلة K-301 الأولى)",
    pressure: "26.0 (Normal) / 25.5 IN",
    temperature: "43.0",
    flowKgH: "48,040 (Wet) / 47,710 (Dry)",
    dryGasMolH: "5,478.45",
    wetGasMolH: "5,496.73",
    h2oMolH: "18.28",
    dryGasTh: "47.710",
    wetGasTh: "48.040",
    dryMw: "8.709",
    wetMw: "8.740",
    comp: {
      h2: "74.06 % (4,057.54 mol/h)",
      n2: "24.69 % (1,352.47 mol/h)",
      ar: "0.40 % (21.78 mol/h)",
      ch4: "0.85 % (46.40 mol/h)",
      nh3: "0.00 %"
    }
  },
  3: {
    id: 3,
    name: "MAKE-UP GAS TO SYNTHESIS (HIGH PRESSURE DISCHARGE)",
    nameAr: "غاز التخليق عالي الضغط المتجه لقسم اصطناع الأمونيا (حلقة التفاعل)",
    pressure: "240.5 (Design) / 240.0 (Normal)",
    temperature: "43.0",
    flowKgH: "47,610 (Wet) / 47,570 (Dry)",
    dryGasMolH: "5,462.02",
    wetGasMolH: "5,464.02",
    h2oMolH: "2.00",
    dryGasTh: "47.570",
    wetGasTh: "47.610",
    dryMw: "8.709",
    wetMw: "8.713",
    comp: {
      h2: "74.06 % (4,045.36 mol/h)",
      n2: "24.69 % (1,348.42 mol/h)",
      ar: "0.40 % (21.78 mol/h)",
      ch4: "0.85 % (46.46 mol/h)",
      nh3: "0.00 %"
    }
  },
  4: {
    id: 4,
    name: "RECYCLE GAS FROM SYNTHESIS SECT.",
    nameAr: "الغاز الراجع من حلقة تصنيع الأمونيا إلى عجلة التدوير (Circulator Wheel)",
    pressure: "220.0",
    temperature: "43.0",
    flowKgH: "205,100 (Wet / Dry)",
    dryGasMolH: "18,283.72",
    wetGasMolH: "18,283.72",
    h2oMolH: "0.00",
    dryGasTh: "205.100",
    wetGasTh: "205.100",
    dryMw: "11.22",
    wetMw: "11.22",
    comp: {
      h2: "57.50 % (10,514.16 mol/h)",
      n2: "19.08 % (3,488.08 mol/h)",
      ar: "3.44 % (628.59 mol/h)",
      ch4: "6.65 % (1,215.55 mol/h)",
      nh3: "13.33 % (2,437.34 mol/h)"
    }
  },
  5: {
    id: 5,
    name: "RECYCLE GAS TO SYNTHESIS SECT.",
    nameAr: "الغاز الراجع والمضغوط بعد مبرد E-315 المتجه لحلقة التفاعل والتصنيع",
    pressure: "245.0",
    temperature: "43.0 (After E-315) / 56.1",
    flowKgH: "205,100 (Wet / Dry)",
    dryGasMolH: "18,283.72",
    wetGasMolH: "18,283.72",
    h2oMolH: "0.00",
    dryGasTh: "205.100",
    wetGasTh: "205.100",
    dryMw: "11.22",
    wetMw: "11.22",
    comp: {
      h2: "57.50 % (10,514.16 mol/h)",
      n2: "19.08 % (3,488.08 mol/h)",
      ar: "3.44 % (628.59 mol/h)",
      ch4: "6.65 % (1,215.55 mol/h)",
      nh3: "13.33 % (2,437.34 mol/h)"
    }
  },
  6: {
    id: 6,
    name: "SYNTHESIS GAS FROM SYN. GAS COMP. SUCTION",
    nameAr: "غاز التخليق المسحوب للتوازن من سحب الضاغط",
    pressure: "26.0",
    temperature: "43.0",
    flowKgH: "568.2 (Wet) / 564.3 (Dry)",
    dryGasMolH: "64.79",
    wetGasMolH: "65.01",
    h2oMolH: "0.22",
    dryGasTh: "0.564",
    wetGasTh: "0.568",
    dryMw: "8.709",
    wetMw: "8.740",
    comp: {
      h2: "74.06 % (47.13 mol/h)",
      n2: "24.69 % (16.00 mol/h)",
      ar: "0.40 % (0.26 mol/h)",
      ch4: "0.85 % (0.55 mol/h)",
      nh3: "0.00 %"
    }
  }
};

export const EQUIPMENT_K301: Record<string, PFDEquipment> = {
  "K-301": {
    tag: "K-301",
    name: "SYN. GAS COMPRESSOR (3 CASINGS: LP, MP, HP & 4 STAGES + TURBINE)",
    nameAr: "قطار ضاغط غاز التخليق K-301 (٣ أكياس: LP و MP و HP عبر ٤ مراحل كبس مع التوربين)",
    pressIn: "25.5 IN / 26.0 kg/cm²A",
    pressOut: "240.5 kg/cm²A (Make-up) / 245 kg/cm²A (Circulator)",
    tempIn: "43.0 °C",
    tempOut: "56.1 °C / 148 °C (Discharge Stages)",
    descAr: "قطار ضاغط طرد مركزي متكامل يضم: 1) التوربين البخاري الدافع K-301T، 2) جسم الضغط المنخفض (LP Casing - Case 1 - المرحلة الأولى)، 3) جسم الضغط المتوسط (MP Casing - Case 2 - المرحلة الثانية)، 4) جسم الضغط العالي (HP Casing - Case 3 - المرحلتان 3 و 4 مع عجلة تدوير حلقة التفاعل Circulator). يقوم بضغط غاز التخليق (H2 + N2) من 26 كغم/سم² إلى ضغط تصنيع الأمونيا 240.5 كغم/سم² عبر 4 مراحل تبريد وفصل، وتدوير الغاز الراجع (205.1 طن/ساعة).",
    x: 420,
    y: 340,
    w: 750,
    h: 220
  },
  "K-301-C1": {
    tag: "K-301 LP (CASE 1)",
    name: "SYN. GAS COMPRESSOR - LP CASING (CASE 1 - 1st STAGE)",
    nameAr: "جسم الضغط المنخفض K-301 LP (الجسم الأول Case 1 - المرحلة الأولى L.P)",
    pressIn: "25.5 kg/cm²A",
    pressOut: "55.0 / 74.5 kg/cm²A",
    tempIn: "43.0 °C",
    tempOut: "148.0 °C",
    descAr: "جسم الضغط المنخفض (L.P. Casing / Case 1): مسؤول عن سحب غاز التخليق بعد فاصل V-301 وإنجاز المرحلة الأولى من الكبس (Stage 1) لرفع الضغط من 25.5 إلى 55-74.5 كغم/سم² ثم دفعه إلى المبرد المرحلي E-301/E-302.",
    x: 440,
    y: 380,
    w: 110,
    h: 150
  },
  "K-301-TURB": {
    tag: "K-301T TURBINE",
    name: "STEAM TURBINE DRIVER (K-301T)",
    nameAr: "التوربين البخاري الدافع لقطار الضواغط K-301T",
    pressIn: "105 kg/cm²G (HP Steam 510°C)",
    tempIn: "510 °C",
    descAr: "التوربين البخاري الدافع K-301T: توربين استخراجي وتكثيفي فائق القدرة (18.5 ميغاواط) يدار ببخار الضغط العالي (105 بار) القادم من المراجل، ويدير الأجسام الثلاثة لضاغط غاز التخليق (LP, MP, HP) عبر عمود دوران موحد بسرعة 10,000 دورة/دقيقة مع استخراج بخار 38 بار.",
    x: 600,
    y: 410,
    w: 90,
    h: 100
  },
  "K-301-C2": {
    tag: "K-301 MP (CASE 2)",
    name: "SYN. GAS COMPRESSOR - MP CASING (CASE 2 - 2nd STAGE)",
    nameAr: "جسم الضغط المتوسط K-301 MP (الجسم الثاني Case 2 - المرحلة الثانية M.P)",
    pressIn: "52.0 / 73.7 kg/cm²A",
    pressOut: "110.0 / 134.4 kg/cm²A",
    tempIn: "43.0 °C",
    tempOut: "132.2 °C",
    descAr: "جسم الضغط المتوسط (M.P. Casing / Case 2): مسؤول عن سحب الغاز المبرد بعد فاصل V-302 وإنجاز المرحلة الثانية من الكبس (Stage 2) لرفع الضغط إلى النطاق المتوسط (110-134.4 كغم/سم²) وتمريره عبر مبرد E-302/E-303 وفاصل السوائل V-303.",
    x: 730,
    y: 380,
    w: 110,
    h: 150
  },
  "K-301-C3": {
    tag: "K-301 HP (CASE 3)",
    name: "SYN. GAS COMPRESSOR - HP CASING (CASE 3 - STAGES 3 & 4 + RECYCLE)",
    nameAr: "جسم الضغط العالي K-301 HP (الجسم الثالث Case 3 - المرحلتان 3 و 4 H.P وعجلة التدوير)",
    pressIn: "105.0 / 127.8 kg/cm²A (Make-up) / 220 kg/cm²A (Recycle)",
    pressOut: "240.5 kg/cm²A",
    tempIn: "43.0 °C",
    tempOut: "56.1 °C / 135 °C",
    descAr: "جسم الضغط العالي (H.P. Casing / Case 3): أعلى الأجسام ضغطاً؛ يضم مرحلتي الكبس الثالثة والرابعة (رفع ضغط غاز التعويض من 105 إلى 160 ثم إلى 240.5 كغم/سم²) مع عجلة التدوير (Circulator Impeller) لتدوير غاز حلقة التفاعل غير المتفاعل بمعدل 205.1 طن/ساعة.",
    x: 880,
    y: 380,
    w: 120,
    h: 150
  },
  "E-301": {
    tag: "E-301",
    name: "1st STAGE SUCTION GAS COOLER",
    nameAr: "مبرد غاز التغذية لسحب المرحلة الأولى E-301",
    duty: "4.85",
    deltaP: "0.8",
    tempIn: "129.3 °C",
    tempOut: "43.0 °C",
    descAr: "مبادل حراري أنبوبي وغلافي (AES) يبرد غاز التخليق القادم من مبرد الميثانايتر E-114 بمياه التبريد من 129.3°C إلى 43°C قبل دخوله لفاصل السحب V-301 لحماية الضاغط من التمدد الحراري ورفع كفاءة الكبس الحجمية.",
    x: 160,
    y: 650,
    w: 110,
    h: 55
  },
  "E-302": {
    tag: "E-302",
    name: "1st STAGE INTERCOOLER",
    nameAr: "مبرد المرحلة الأولى البيني E-302",
    duty: "4.12",
    deltaP: "0.7",
    tempIn: "135.0 °C",
    tempOut: "43.0 °C",
    descAr: "مبرد بيني يخفض حرارة الغاز المضغوط من طرد المرحلة الأولى (135°C) إلى 43°C بمياه التبريد قبل دخوله لفاصل السوائل V-302 وسحب المرحلة الثانية.",
    x: 520,
    y: 190,
    w: 110,
    h: 55
  },
  "E-303": {
    tag: "E-303",
    name: "2nd STAGE INTERCOOLER",
    nameAr: "مبرد المرحلة الثانية البيني E-303",
    duty: "3.75",
    deltaP: "0.6",
    tempIn: "142.0 °C",
    tempOut: "43.0 °C",
    descAr: "مبرد بيني يخفض حرارة الغاز المضغوط من طرد المرحلة الثانية (142°C) إلى 43°C قبل دخوله لفاصل V-303 وسحب المرحلة الثالثة.",
    x: 640,
    y: 650,
    w: 110,
    h: 55
  },
  "E-304": {
    tag: "E-304",
    name: "3rd STAGE INTERCOOLER (HP COOLER)",
    nameAr: "مبرد المرحلة الثالثة عالي الضغط E-304",
    duty: "3.20",
    deltaP: "0.5",
    tempIn: "138.0 °C",
    tempOut: "43.0 °C",
    descAr: "مبرد عالي الضغط يبرد الغاز بعد المرحلة الثالثة من 138°C إلى 43°C قبل دخوله لفاصل V-304 وسحب المرحلة الرابعة النهائية.",
    x: 790,
    y: 650,
    w: 110,
    h: 55
  },
  "E-315": {
    tag: "E-315",
    name: "RECYCLE GAS COOLER",
    nameAr: "مبرد غاز التدوير الراجع E-315",
    duty: "2.85",
    deltaP: "0.4",
    tempIn: "55.0 °C",
    tempOut: "43.0 °C",
    descAr: "مبادل حراري فائق الضغط (BEU) يتحمل ضغط 245 كغم/سم²، يبرد غاز التدوير غير المتفاعل المطرود من عجلة التدوير Circulator بمياه التبريد قبل إعادته لحلقة الأمونيا.",
    x: 750,
    y: 80,
    w: 110,
    h: 55
  },
  "V-301": {
    tag: "V-301",
    name: "1st STAGE SUCTION SEPARATOR",
    nameAr: "فاصل سوائل سحب المرحلة الأولى V-301",
    pressIn: "25.5 kg/cm²A",
    tempIn: "43.0 °C",
    descAr: "وعاء فصل عمودي مزود بمانع رذاذ (Demister Pad) لحجز قطرات الماء المتكثفة بعد المبرد E-301 وتصريفها، لمنع وصول السوائل لريش ضاغط المرحلة الأولى وحمايته من التآكل الميكانيكي.",
    x: 320,
    y: 560,
    w: 70,
    h: 110
  },
  "V-302": {
    tag: "V-302",
    name: "2nd STAGE SUCTION SEPARATOR",
    nameAr: "فاصل سوائل سحب المرحلة الثانية V-302",
    pressIn: "52.0 kg/cm²A",
    tempIn: "43.0 °C",
    descAr: "فاصل سوائل ومكثفات سحب المرحلة الثانية بعد المبرد E-302 لحماية زعانف جسم الضغط المتوسط K-301 MP.",
    x: 440,
    y: 190,
    w: 65,
    h: 100
  },
  "V-303": {
    tag: "V-303",
    name: "3rd STAGE SUCTION SEPARATOR",
    nameAr: "فاصل سوائل سحب المرحلة الثالثة V-303",
    pressIn: "105.0 kg/cm²A",
    tempIn: "43.0 °C",
    descAr: "فاصل سوائل ومكثفات عالي الضغط بعد المبرد E-303 لتأمين غاز جاف نقي لسحب المرحلة الثالثة بجسم الضغط العالي K-301 HP.",
    x: 580,
    y: 650,
    w: 65,
    h: 100
  },
  "V-304": {
    tag: "V-304",
    name: "4th STAGE SUCTION SEPARATOR",
    nameAr: "فاصل سوائل سحب المرحلة الرابعة V-304",
    pressIn: "160.0 kg/cm²A",
    tempIn: "43.0 °C",
    descAr: "فاصل السحب للمرحلة الرابعة والأخيرة؛ يحجز أي قطرات سائلة دقيقة قبل الكبس النهائي إلى ضغط 240.5 كغم/سم².",
    x: 920,
    y: 650,
    w: 65,
    h: 100
  },
  "V-310": {
    tag: "V-310",
    name: "RECYCLE GAS SEPARATOR",
    nameAr: "فاصل غاز التدوير والتعويض V-310",
    pressIn: "245.0 kg/cm²A",
    tempIn: "43.0 °C",
    descAr: "فاصل فائق الضغط يستلم الغاز الراجع المبرد من E-315 ويحقن غاز التعويض الطازج (Make-Up Gas) قبل إرسال الخليط إلى حلقة تصنيع الأمونيا R-401.",
    x: 660,
    y: 80,
    w: 65,
    h: 95
  }
};

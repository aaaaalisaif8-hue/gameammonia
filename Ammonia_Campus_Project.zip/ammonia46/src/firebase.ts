import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut as firebaseSignOut, 
  onAuthStateChanged, 
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc,
  collection,
  getDocs,
  onSnapshot, 
  runTransaction 
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMessage = error instanceof Error ? error.message : String(error);
  const isOffline = errMessage.includes('offline') || (error as any)?.code === 'unavailable';
  const isPermissionDenied = (error as any)?.code === 'permission-denied' || 
    errMessage.toLowerCase().includes('permission');

  const errInfo: FirestoreErrorInfo = {
    error: errMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };

  if (isPermissionDenied) {
    console.error('Firestore Permission Error: ', JSON.stringify(errInfo));
    throw new Error(JSON.stringify(errInfo));
  } else if (isOffline) {
    console.warn('Firestore operating in offline mode: ', errMessage);
  } else {
    console.error('Firestore Error Details: ', JSON.stringify(errInfo));
  }
  return errInfo;
}

// Safe non-blocking Connection check on boot
export async function testFirebaseConnection() {
  try {
    if (db) {
      console.log("Firebase Firestore initialized successfully for database:", firebaseConfig.firestoreDatabaseId);
    }
  } catch (error: any) {
    console.warn("Firestore connection check:", error);
  }
}

// Google Sign In via Popup
export async function loginWithGoogle(): Promise<FirebaseUser | null> {
  try {
    googleProvider.setCustomParameters({ prompt: 'select_account' });
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    if (user) {
      await registerOrUpdateUserProfile(user);
    }
    return user;
  } catch (error) {
    console.error("Error signing in with Google:", error);
    throw error;
  }
}

// Logout
export async function logoutUser() {
  try {
    await firebaseSignOut(auth);
  } catch (error) {
    console.error("Error signing out:", error);
    throw error;
  }
}

// Register or update user profile document + update total user counter
export async function registerOrUpdateUserProfile(user: FirebaseUser) {
  const userDocRef = doc(db, 'users', user.uid);
  const statsDocRef = doc(db, 'stats', 'userCount');
  const nowStr = new Date().toISOString();

  // Cache user locally so offline mode always remembers login
  try {
    localStorage.setItem('nh3_cached_user', JSON.stringify({
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
      photoURL: user.photoURL,
      lastLoginAt: nowStr
    }));
  } catch (_) {}

  try {
    const userSnap = await getDoc(userDocRef);
    if (!userSnap.exists()) {
      // New user registration
      await setDoc(userDocRef, {
        uid: user.uid,
        email: user.email || '',
        displayName: user.displayName || 'مهندس أمونيا متدرب',
        photoURL: user.photoURL || '',
        createdAt: nowStr,
        lastLoginAt: nowStr
      });

      // Increment global user count atomically using transaction or updateDoc
      try {
        await runTransaction(db, async (transaction) => {
          const statsSnap = await transaction.get(statsDocRef);
          if (!statsSnap.exists()) {
            transaction.set(statsDocRef, {
              totalUsers: 1,
              updatedAt: nowStr
            });
          } else {
            const currentCount = statsSnap.data().totalUsers || 0;
            transaction.update(statsDocRef, {
              totalUsers: currentCount + 1,
              updatedAt: nowStr
            });
          }
        });
      } catch (txErr) {
        console.warn("Could not increment user count transaction:", txErr);
      }
    } else {
      // Existing user login update
      await updateDoc(userDocRef, {
        lastLoginAt: nowStr,
        displayName: user.displayName || userSnap.data().displayName || '',
        photoURL: user.photoURL || userSnap.data().photoURL || ''
      });
    }

    // AUTO-SYNC REAL USER INTO DIRECTORY SO ALL OTHER USERS INSTANTLY SEE THEM
    try {
      const dirDocRef = doc(db, 'directory', user.uid);
      const dirSnap = await getDoc(dirDocRef);
      if (!dirSnap.exists()) {
        let userNum = 1;
        try {
          const statsSnap = await getDoc(statsDocRef);
          if (statsSnap.exists()) {
            userNum = Math.max(1, (statsSnap.data().totalUsers || 1));
          }
        } catch (_) {}

        const initialDirUser: DirectoryUserProfile = {
          uid: user.uid,
          displayName: String(user.displayName || 'مهندس متدرب').slice(0, 100),
          university: String(localStorage.getItem('nh3_student_uni') || 'جامعة البصرة - كلية الهندسة').slice(0, 100),
          governorate: String(localStorage.getItem('nh3_student_gov') || 'البصرة').slice(0, 60),
          department: String(localStorage.getItem('nh3_student_dept') || 'هندسة كيمياوية').slice(0, 100),
          photoURL: String(user.photoURL || '').slice(0, 2048),
          joinedAt: nowStr,
          userNumber: userNum
        };
        await setDoc(dirDocRef, initialDirUser);
      } else {
        // Update display name or photo if user updated their Google account
        const existingData = dirSnap.data() as DirectoryUserProfile;
        await setDoc(dirDocRef, {
          displayName: String(user.displayName || existingData.displayName || 'مهندس متدرب').slice(0, 100),
          photoURL: String(user.photoURL || existingData.photoURL || '').slice(0, 2048)
        }, { merge: true });
      }
    } catch (dirErr) {
      console.warn("Could not auto-register user into directory:", dirErr);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
  }
}

// Fetch user count once via getDoc without opening a persistent watch stream
export async function fetchUserCountOnce(): Promise<number> {
  try {
    const statsDocRef = doc(db, 'stats', 'userCount');
    const snapshot = await getDoc(statsDocRef);
    if (snapshot.exists()) {
      const data = snapshot.data();
      return data.totalUsers || 1;
    }
  } catch (error) {
    console.warn("Could not fetch user count from server, using local default:", error);
  }
  return 1;
}

// Real-time Total Users listener (per Firebase skill, only attach when authenticated)
export function listenToUserCount(onCountUpdate: (count: number) => void): () => void {
  const statsDocRef = doc(db, 'stats', 'userCount');
  
  const unsubscribe = onSnapshot(
    statsDocRef,
    (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        onCountUpdate(data.totalUsers || 1);
      } else {
        onCountUpdate(1);
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, 'stats/userCount');
      onCountUpdate(1);
    }
  );

  return unsubscribe;
}

// Auth State Observer
export function observeAuthState(onChange: (user: FirebaseUser | null) => void) {
  return onAuthStateChanged(auth, async (user) => {
    if (user) {
      try {
        await registerOrUpdateUserProfile(user);
      } catch (e) {
        console.warn("Failed updating profile on auth state change:", e);
      }
    }
    onChange(user);
  });
}

// In-memory debounce timers map for exam progress syncing
const progressDebounceTimers: Record<string, any> = {};

/**
 * Save user answers to progress/{uid}_{section} with 1.5s debounce
 * Only executes if user is authenticated. Maps null to -1.
 */
export function saveExamProgressDebounced(
  section: string,
  answers: (number | null)[],
  total: number
) {
  const currentUser = auth.currentUser;
  if (!currentUser) return; // Only sync if user is signed in

  const timerKey = `${currentUser.uid}_${section}`;
  if (progressDebounceTimers[timerKey]) {
    clearTimeout(progressDebounceTimers[timerKey]);
  }

  progressDebounceTimers[timerKey] = setTimeout(async () => {
    try {
      if (!auth.currentUser || auth.currentUser.uid !== currentUser.uid) return;

      const progressId = `${currentUser.uid}_${section}`;
      const progressRef = doc(db, 'progress', progressId);

      // Map null to -1 per specification
      const mappedAnswers = answers.map((a) => (a === null || a === undefined ? -1 : a));

      const studentName =
        currentUser.displayName ||
        localStorage.getItem('nh3_student_name') ||
        'مهندس كيميائي / ميكانيك متدرب';

      const payload = {
        uid: currentUser.uid,
        email: currentUser.email || '',
        userName: String(studentName).slice(0, 256),
        section: section,
        total: Math.min(200, Math.max(0, total)),
        answers: mappedAnswers.slice(0, 200),
        updatedAt: new Date().toISOString(),
      };

      await setDoc(progressRef, payload, { merge: true });
      console.log(`[Exam Sync] Progress for ${section} saved securely to cloud.`);
    } catch (err) {
      console.warn(`[Exam Sync] Could not save progress for ${section}:`, err);
    }
  }, 1500); // 1.5 seconds debounce
}

/**
 * Check if authenticated user is registered in admins/{uid}
 */
export async function checkIsAdmin(uid: string): Promise<boolean> {
  if (!uid) return false;
  try {
    const adminDocRef = doc(db, 'admins', uid);
    const snap = await getDoc(adminDocRef);
    return snap.exists();
  } catch (err) {
    console.warn("Could not check admin status:", err);
    return false;
  }
}

/**
 * Fetch all progress records for Trainer Dashboard (Allowed for Admin)
 */
export async function fetchAllProgressForAdmin(): Promise<any[]> {
  try {
    const progressCol = collection(db, 'progress');
    const snap = await getDocs(progressCol);
    const results: any[] = [];
    snap.forEach((d) => {
      results.push(d.data());
    });
    return results;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'progress');
    return [];
  }
}

/**
 * Allow user to delete their own account profile per security spec & privacy right
 */
export async function deleteCurrentUserAccount(): Promise<void> {
  const currentUser = auth.currentUser;
  if (!currentUser) return;
  try {
    const userDocRef = doc(db, 'users', currentUser.uid);
    await deleteDoc(userDocRef);
    localStorage.removeItem('nh3_cached_user');
    await logoutUser();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `users/${currentUser.uid}`);
  }
}

export interface DirectoryUserProfile {
  uid: string;
  displayName: string;
  university: string;
  governorate: string;
  department: string;
  photoURL?: string;
  joinedAt: string;
  userNumber?: number;
}

/**
 * Save or update the verified engineer profile in the public directory
 */
export async function saveUserDirectoryProfile(profile: {
  displayName: string;
  university: string;
  governorate: string;
  department: string;
  photoURL?: string;
}): Promise<DirectoryUserProfile> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('User must be authenticated to register in directory');
  }

  const dirDocRef = doc(db, 'directory', currentUser.uid);
  const existingSnap = await getDoc(dirDocRef);
  const nowIso = new Date().toISOString();

  let finalRecord: DirectoryUserProfile;

  if (existingSnap.exists()) {
    const prevData = existingSnap.data() as DirectoryUserProfile;
    finalRecord = {
      uid: currentUser.uid,
      displayName: profile.displayName.trim().slice(0, 100),
      university: profile.university.trim().slice(0, 100),
      governorate: profile.governorate.trim().slice(0, 60),
      department: profile.department.trim().slice(0, 100),
      photoURL: profile.photoURL || prevData.photoURL || currentUser.photoURL || '',
      joinedAt: prevData.joinedAt || nowIso,
      userNumber: prevData.userNumber || 1
    };
  } else {
    // Determine user number from count
    let userNum = 1;
    try {
      const statsSnap = await getDoc(doc(db, 'stats', 'userCount'));
      if (statsSnap.exists()) {
        userNum = Math.max(1, (statsSnap.data().totalUsers || 1));
      }
    } catch (_) {}

    finalRecord = {
      uid: currentUser.uid,
      displayName: profile.displayName.trim().slice(0, 100),
      university: profile.university.trim().slice(0, 100),
      governorate: profile.governorate.trim().slice(0, 60),
      department: profile.department.trim().slice(0, 100),
      photoURL: profile.photoURL || currentUser.photoURL || '',
      joinedAt: nowIso,
      userNumber: userNum
    };
  }

  await setDoc(dirDocRef, finalRecord, { merge: true });

  // Save to localStorage for quick retrieval & autofill
  try {
    localStorage.setItem('nh3_student_name', finalRecord.displayName);
    localStorage.setItem('nh3_student_uni', finalRecord.university);
    localStorage.setItem('nh3_student_gov', finalRecord.governorate);
    localStorage.setItem('nh3_student_dept', finalRecord.department);
    localStorage.setItem('nh3_dir_profile', JSON.stringify(finalRecord));
  } catch (_) {}

  return finalRecord;
}

/**
 * Fetch a specific user's directory profile
 */
export async function fetchUserDirectoryProfile(uid: string): Promise<DirectoryUserProfile | null> {
  if (!uid) return null;
  try {
    const dirDocRef = doc(db, 'directory', uid);
    const snap = await getDoc(dirDocRef);
    if (snap.exists()) {
      return snap.data() as DirectoryUserProfile;
    }
  } catch (err) {
    console.warn("Could not fetch user directory profile:", err);
  }
  return null;
}

/**
 * Fetch all registered directory users once
 */
export async function fetchUserDirectoryOnce(): Promise<DirectoryUserProfile[]> {
  try {
    const colRef = collection(db, 'directory');
    const snap = await getDocs(colRef);
    const users: DirectoryUserProfile[] = [];
    snap.forEach((d) => {
      users.push(d.data() as DirectoryUserProfile);
    });
    // Sort by join date descending
    users.sort((a, b) => new Date(b.joinedAt).getTime() - new Date(a.joinedAt).getTime());
    return users;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'directory');
    return [];
  }
}

/**
 * Real-time listener for the User Directory
 */
export function listenToUserDirectory(
  onUpdate: (users: DirectoryUserProfile[]) => void
): () => void {
  const colRef = collection(db, 'directory');
  const unsubscribe = onSnapshot(
    colRef,
    (snap) => {
      const users: DirectoryUserProfile[] = [];
      snap.forEach((d) => {
        users.push(d.data() as DirectoryUserProfile);
      });
      users.sort((a, b) => new Date(b.joinedAt).getTime() - new Date(a.joinedAt).getTime());
      onUpdate(users);
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, 'directory');
      onUpdate([]);
    }
  );
  return unsubscribe;
}


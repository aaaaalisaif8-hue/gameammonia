/**
 * Security and sanitization utilities
 * Escapes characters & < > " ' to prevent Cross-Site Scripting (XSS)
 */
export function escapeHtml(str: string | null | undefined): string {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function sanitizeUrl(url: string | null | undefined, fallback: string = ''): string {
  if (!url) return fallback;
  const trimmed = url.trim();
  if (trimmed.startsWith('https://') || trimmed.startsWith('http://') || trimmed.startsWith('data:image/')) {
    return escapeHtml(trimmed);
  }
  return fallback;
}
